import { Card, Col, Nav, NavItem, NavLink, Row } from 'reactstrap'
import { All, Doing, Done, Href } from '../../../../utils/Constant'
import { useAppDispatch, useAppSelector } from '../../../../ReduxToolkit/Hooks'
import CreateNewProject from './CreateNewProject'
import { setActiveTab } from '../../../../ReduxToolkit/Reducers/ProjectSlice'
import { FeatherIcons } from '../../../../AbstractElements'

const ProjectListHead = () => {
  const {activeTab} = useAppSelector((state)=>state.project)
  const dispatch = useAppDispatch()
  return (
    <Card>
      <Row>
        <Col md="6" className='p-0'>
          <Nav tabs className="border-tab d-flex">
            <NavItem>
              <NavLink className={activeTab === "1" ? "active" : ""} onClick={() => dispatch(setActiveTab("1"))} href={Href}>
                <FeatherIcons iconName='Target' /> {All}
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink className={activeTab === "2" ? "active" : ""} onClick={() => dispatch(setActiveTab("2"))} href={Href}>
                <FeatherIcons iconName='Info' /> {Doing}
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink className={activeTab === "3" ? "active" : ""} onClick={() => dispatch(setActiveTab("3"))} href={Href}> 
                <FeatherIcons iconName='CheckCircle' />{Done}
              </NavLink>
            </NavItem>
          </Nav>
        </Col>
        <CreateNewProject />
      </Row>
    </Card>
  )
}

export default ProjectListHead