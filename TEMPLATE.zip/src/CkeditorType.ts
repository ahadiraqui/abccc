declare module '@ckeditor/ckeditor5-react' 
declare module '@ckeditor/ckeditor5-build-classic';