import { useState } from "react";
// import DatePicker, { DateObject } from 'react-multi-date-picker';
import AgGridTable from "../../../CommonElements/AgGridTable";
import dayjs from "dayjs";

import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { FaEdit } from "react-icons/fa";
// import "./style.css";
import { Btn } from "../../../AbstractElements";
import { Link } from "react-router-dom";
import "./style.scss";
export const AttendenceGrid = () => {
  // const frameworkComponents = {
  //     editCellRenderer: (params: any) =>
  // };
  const columnDefs = [
    {
      headerName: "Sr.No.",
      field: "srNo",
      sortable: true,
      filter: false,
      minWidth: 85,
      width: 85,
      headerClass: "right-align",
      cellClass: ["justify-content-end"]
    },
    {
      headerName: "Date",
      field: "date",
      sortable: true,
      filter: false,
      minWidth: 230,
      width: 230,
      headerClass: "right-align wrap-text",
      cellClass: ["justify-content-end"]
    },
    {
      headerName: "Status",
      field: "status",
      sortable: true,
      filter: false,
      minWidth: 230,
      width: 230
    },
    {
      headerName: "Efforts",
      field: "Efforts",
      sortable: true,
      filter: false,
      minWidth: 250,
      width: 250,
      cellStyle: { whiteSpace: "pre" }
    },
    {
      headerName: "Branch",
      field: "Branch",
      sortable: true,
      filter: false,
      minWidth: 250,
      width: 250,
      cellStyle: { whiteSpace: "pre" }
    },
    {
      headerName: "Field",
      field: "Field",
      sortable: true,
      filter: false,
      minWidth: 250,
      width: 250,
      cellStyle: { whiteSpace: "pre" }
    }

    // {
    //   headerName: "Edit",
    //   field: "Edit",
    //   sortable: false,
    //   filter: false,
    //   minWidth: 66,
    //   width: 66,
    //   cellRenderer: (params:any) => {
    //     return (
    //       <>
    //         <i
    //           className="icon-pencil-alt"
    //           style={{ color: "#5b60ef", fontSize: "15px", cursor: "pointer" }}
    //         ></i>
    //       </>
    //     );
    //   }
    // }
  ];

  const rowData = [
    {
      srNo: 1,
      date: "Mon,1-May-2024",
      status: "Holiday"
      // Efforts: "1. Meeting\n2. Exploration\n3. Lead\n4. Win",
      // Branch: "1. Meeting\n2. Exploration\n3. Lead\n4. Win",
      // Field: "1. Meeting\n2. Exploration\n3. Lead\n4. Win",
    },
    {
      srNo: 2,
      date: "Tue,2-May-2024",
      status: "Working",
      Efforts: "Meeting (3)\nExploration (4)\nLead (3)\nWin (3)",
      Branch: "Meeting (1)\nExploration (1)\nLead (2)\nWin (2)",
      Field: "Meeting (2)\nExploration(3)\nLead(1)\nWin(1)"
    },
    {
      srNo: 3,
      date: "Wed,3-May-2024",
      status: "Working",
      Efforts: "Meeting (2)\nExploration (3)\nLead (1)\nWin (1)",
      Branch: "",
      Field: "Meeting (2)\nExploration(3)\nLead(1)\nWin(1)"
    },
    {
      srNo: 4,
      date: "Thu,4-May-2024",
      status: "Leave"
      // Efforts: "1. Meeting\n2. Exploration\n3. Lead\n4. Win",
      // Branch: "1. Meeting\n2. Exploration\n3. Lead\n4. Win",
      // Field: "1. Meeting\n2. Exploration\n3. Lead\n4. Win",
    },
    {
      srNo: 5,
      date: "Fri,5-May-2024",
      status: "Weekly off"
      // Efforts: "1. Meeting\n2. Exploration\n3. Lead\n4. Win",
      // Branch: "1. Meeting\n2. Exploration\n3. Lead\n4. Win",
      // Field: "1. Meeting\n2. Exploration\n3. Lead\n4. Win",
    }
  ];

  const style = {
    height: "calc(100vh - 140px)",
    width: "100%",
    margin: "0 auto"
  };
  // const getRowHeight = () => 90;
  const getRowHeight = params => {
    const status = params.data ? params.data.status : ""; // Accessing status property from params.data

    if (status === "Working") {
      return 90; // Return 90 if status is 'Working'
    } else {
      return 35; // Return 20 for other statuses or if status is not available
    }
  };

  const [selectedDate, setSelectedDate] = useState(dayjs());

  const handleDateChange = date => {
    setSelectedDate(date);
  };

  const formatDate = date => {
    if (!date) return "";
    return dayjs(date).format("ddd, DD MMM YYYY");
  };
  return (
    <div className="page-body attandence-list">
      <div className="m-block center-block-meeting d-flex justify-content-between mt-4 mb-1 align-items-center pt-1 pt-1">
        <div className="ps-0 col-sm-6">
          <h3 className="screen-title">Attendance</h3>
        </div>
        <div>
          <div className="d-flex gap-3 mt-2">
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                className="custom-date"
                value={selectedDate}
                onChange={handleDateChange}
                renderInput={props => (
                  <input {...props} variant="standard" fullWidth />
                )}
                format="ddd, DD MMM YYYY" // Format for the displayed date
              />
            </LocalizationProvider>
            <div className="text-end">
              <Link
                color="primary"
                className="w-100"
                to={`${process.env.PUBLIC_URL}/add-attendance`}
              >
                <Btn color="primary" block className="w-100">
                  Add
                </Btn>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* <p>AG Grid Table Test</p> */}
      <AgGridTable
        rowData={rowData} className="center-block-meeting-grid"
        columnDefs={columnDefs}
        Style={style}
        getRowHeight={getRowHeight}
        pagination={true}
        paginationPageSize={15}
      />
    </div>
  );
};
