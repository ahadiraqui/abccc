import React, { useEffect, useState } from 'react';
import ReactApexChart from 'react-apexcharts';
import { useAppDispatch, useAppSelector } from '../../../../ReduxToolkit/Hooks';
import { GetDashboardManagementEmployeeTPAFee } from '../../../../ReduxToolkit/Reducers/DashboardAction';

const EmployeeChart = () => {
  const dispatch = useAppDispatch();
  const dashboardAction = useAppSelector((state)=>state.dashboardAction);
  const dashboardManagementEmployeeTPAFeeList = dashboardAction.dashboardManagementEmployeeTPAFeeList;

  const [xaxisData,setXAxisData]=useState([]);
  const [yaxisData,setYAxisData] = useState([]);

  useEffect(()=>{
    dispatch(GetDashboardManagementEmployeeTPAFee());
  },[])

  useEffect(()=>{
    if(dashboardManagementEmployeeTPAFeeList && dashboardManagementEmployeeTPAFeeList?.length>0)
    {
      const xarr = [];
      const yarr = [];

      dashboardManagementEmployeeTPAFeeList?.map((item)=>{
        xarr.push(item?.FullName);
        yarr.push(item?.TPAFee);
      })

      setXAxisData(xarr);
      setYAxisData(yarr);
    }
  },[dashboardManagementEmployeeTPAFeeList])

  console.log("XAXIS",xaxisData);
  console.log("YAXIS",yaxisData);

  // Define colors for both bars and labels
  const barColors = ['#008FFB', '#00E396', '#FEB019', '#FF4560', '#775DD0', 
                     '#546E7A', '#26a69a', '#D10CE8', '#FFD700', '#B22222',
                     '#DC143C', '#32CD32', '#008080', '#4B0082', '#00CED1',
                     '#FF6347', '#00FFFF', '#FFD700', '#40E0D0', '#FF00FF'];

  // Options configuration for ApexCharts
  const options = {
    chart: {
      height: 350,
      type: 'bar',
      toolbar: {
        show: false
      },
      events: {
        click: function(chart, w, e) {
          // Handle chart click events if needed
          console.log(chart, w, e);
        }
      }
    },
    colors: barColors,
    plotOptions: {
      bar: {
        columnWidth: '45%',
        distributed: true,
      }
    },
    dataLabels: {
      enabled: false
    },
    legend: {
      show: false
    },
    xaxis: {
      categories : xaxisData,
      // categories: [
      //   'Aarav Patel', 'Vivaan Sharma', 'Aditya Singh', 'Vihaan Gupta', 'Advik Kumar',
      //   'Sai Reddy', 'Arjun Joshi', 'Reyansh Khan', 'Ishaan Kumar', 'Ayaan Sharma',
      //   'Ananya Gupta', 'Anaya Singh', 'Avni Patel', 'Aaradhya Kumar', 'Saanvi Sharma',
      //   'Neha Reddy', 'Tanvi Joshi', 'Aarohi Khan', 'Pari Gupta', 'Shreya Singh'
      // ],
      labels: {
        style: {
          colors: barColors, // Matching label colors to bar colors
          fontSize: '12px'
        }
      }
    },
    series: [{
      data : yaxisData
      // data: [41, 50, 70, 28, 67, 21, 13, 30, 47, 45, 
      //        45, 23, 78, 60, 25, 28, 36, 21, 60, 30]
    }],
  };

  return (
    <div id="chart">
      <ReactApexChart options={options} series={options.series} type="bar" height={350} />
    </div>
  );
};

export default EmployeeChart;
