// import { randomBytes } from 'crypto';
import React, { useEffect, useState } from 'react';
import ReactApexChart from 'react-apexcharts';
import { useAppDispatch, useAppSelector } from '../../../../ReduxToolkit/Hooks';
import { GetDashboardManagementInsurance } from '../../../../ReduxToolkit/Reducers/DashboardAction';

const DistributedChart = () => {
  const dispatch = useAppDispatch();
  const dashboardAction = useAppSelector((state)=>state.dashboardAction);
  const dashboardManagementInsuranceList = dashboardAction.dashboardManagementInsuranceList;

  const [treeData,setTreeData] = useState([]);

  useEffect(()=>{
    dispatch(GetDashboardManagementInsurance());
  },[]);

  const getRandomColor = ()=>{
    const letters = "0123456789ABCDEF";

    let color = "#";

    for(let i=0;i<6;i++){
      color += letters[Math.floor(Math.random() * 16)];
    }

    return color
  }

  useEffect(()=>{
    if(dashboardManagementInsuranceList )
    { 
      const data = dashboardManagementInsuranceList?.map((item)=>({
        x : item.InsuranceCompanyName,
        y : 30,
        // color : getRandomColor()
      }))

      setTreeData(data);
    }
  },[dashboardManagementInsuranceList])

  const options = {
    series: [
      {
        data : treeData,
        // data: [
        //   { x: 'Nia', y: 100, color: '#3B93A5' },
        //   { x: 'Oic', y: 40, color: '#F7B844' },
        //   { x: 'Uiic', y: 50, color: '#ADD8C7' },
        //   { x: 'Care', y: 55, color: '#EC3C65' },
        //   { x: 'Icici', y: 84, color: '#CDD7B6' },
        //   { x: 'Cigna', y: 31, color: '#C1F666' },
        //   { x: 'Zuno', y: 40, color: '#D43F97' },
        //   { x: 'Balic', y: 30, color: '#1E5D8C' },
        //   { x: 'Itgi', y: 44, color: '#421243' },
        //   { x: 'Magma', y: 48, color: '#7F94B0' },
        //   { x: 'Reliance', y: 28, color: '#EF6537' },
        //   { x: 'Rs', y: 19, color: '#C0ADDB' },
        //   { x: 'Edelweiss', y: 50, color: '#3B93A5' },
        //   { x: 'Cholama', y: 29, color: '#3B93A5' },
        //   { x: 'Maxlife', y: 40, color: '#3B93A5' },
        //   { x: 'Aditya Birla', y: 70, color: '#3B93A5' },
        //   { x: 'Acnt', y: 29, color: '#3B93A5' },
        //   { x: 'Kotak', y: 40, color: '#3B93A5' },
        //   { x: 'PNB', y: 29, color: '#3B93A5' },
        // ],
      },
    ],
    legend: {
      show: false,
    },
    chart: {
      height: 350,
      type: 'treemap',
      toolbar: {
        show: false
      },

    },
    tooltip: {
      enabled: true,
      style: {
        fontSize: '12px',
        fontFamily: 'Helvetica, Arial, sans-serif',
      },
      custom: function({ series, seriesIndex, dataPointIndex, w }) {
        return `<div>${w.config.series[0].data[dataPointIndex].x}</div>`;
      },
    },

 
    plotOptions: {
      treemap: {
        distributed: true,
        enableShades: false,
        // labels: {
        //   show: true,
        //   style: {
        //     fontSize: '200px', // Adjust font size as needed
        //   },
        // },
      },
    },
  };

  return (
    <div id="chart" className="chart-font">
      <ReactApexChart options={options} series={options.series} type="treemap" height={270} />
    </div>
  );
};

export default DistributedChart;
