import React from "react";
import ReactApexChart from "react-apexcharts";

const MonthlyDetails = () => {
  const options = {
    series: [
      {
        name: 'Q1',
        data: [340, 480, 250, 180, 320, 310, 280, 410, 380, 490, 450, 390] // Q1 Budget and Q1 Actual for the first group
      },
      {
        name: 'Q2',
        data: [230, 200, 170, 110, 250, 220, 180, 140, 190, 120, 170, 150] // Q2 Budget and Q2 Actual for the second group
      }
    ],
    chart: {
      type: 'bar',
      height: 350,
      stacked: true,
      toolbar: {
        show: false
      },
    },
    stroke: {
      width: 1,
      colors: ['#fff']
    },
    dataLabels: {
      formatter: function(val) {
        return val
      }
    },
    plotOptions: {
      bar: {
        horizontal: false
      }
    },
    xaxis: {
      categories: [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
      ]
    },
    fill: {
      opacity: 1
    },
    colors: ['#5c61f2', '#00bcd4', '#80f1cb', '#00E396'],
    yaxis: {
      labels: {
        formatter: function(val) {
          return val;
        }
      }
    },
    legend: {
      position: 'top',
      horizontalAlign: 'left'
    }
  };

  return (
    <div>
      <ReactApexChart
        options={options}
        series={options.series}
        type="bar"
        height={300}
      />
    </div>
  );
};

export default MonthlyDetails;
