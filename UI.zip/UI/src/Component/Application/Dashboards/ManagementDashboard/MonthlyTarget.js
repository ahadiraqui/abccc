import React from 'react';
import ReactApexChart from 'react-apexcharts';

const MonthlyTarget = () => {
  // const options = {
  //   series: [70],
  //   chart: {
  //     height: 350,
  //     type: 'radialBar',
  //   },
  //   plotOptions: {
  //     radialBar: {
  //       hollow: {
  //         size: '70%',
  //       },
  //     },
  //   },
  //   labels: ['Achived Target'],
  // };
  const options = {
    series: [65],
    chart: {
      height: 350,
      type: 'radialBar',
    },
    plotOptions: {
      radialBar: {
        hollow: {
          size: '70%',
        },
        track: {
          background: '#f2f2f2', // Background color of the circular track
        },
        dataLabels: {
          name: {
            show: true,
          },
          value: {
            color:'#5c61f2',
            fontWeight:600,
            fontSize: '20px', // Font size of the value label inside the bar
            offsetY: 8, // Offset of the value label from the center
          },
        },
      },
    },
    colors: ['#5c61f2', '#f2f2f2'], // Custom colors for the bars
    fill: {
      type: 'gradient',
      gradient: {
        shade: 'dark',
        type: 'horizontal',
        shadeIntensity: 0.5,
        gradientToColors: ['#5c61f2'],
        inverseColors: true,
        opacityFrom: 1,
        opacityTo: 1,
        stops: [0, 100]
      }
    },
    stroke: {
      lineCap: 'round'
    },
    labels: ['Achieved Target'],
  };

  return (
    <div id="chart">
      <ReactApexChart options={options} series={options.series} type="radialBar" height={350} />
    </div>
  );
};

export default MonthlyTarget;
