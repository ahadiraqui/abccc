import { useEffect } from "react";
import { Col, Row } from "reactstrap";
import AgGridTable from "../../../../../CommonElements/AgGridTable";
import { useAppDispatch, useAppSelector } from "../../../../../ReduxToolkit/Hooks";
import { GetDashboardManagementWins } from "../../../../../ReduxToolkit/Reducers/DashboardAction";
import { formatIndianNumber } from "../../../OpportunityGrid/formatIndianNumber";

const Win = () => {
  const dispatch = useAppDispatch();
  const dashboardAction = useAppSelector((state)=>state.dashboardAction);
  const dashboardManagementWinsList = dashboardAction.dashboardManagementWinsList;

  useEffect(()=>{
    dispatch(GetDashboardManagementWins());
  },[])

  const style = { height: "460px", width: "100%" };
  const getRowHeight = () => 40;

  const columnDefs = [
    {
      headerName: "Corporate",
      field: "CorporateName",
      sortable: false,
      filter: false,
      minWidth: 200,
      width: 200
    },
    {
      headerName: "Premium",
      headerComponentParams: { template: '<span class="outer-span"><span class="amt-col">Premium</span><span class="icon-span">(<i class="fa fa-rupee"></i>)</span>'},
      field: "Premium",
      sortable: false,
      filter: false,
      minWidth: 170,
      width: 170,
      headerClass: "right-align wrap-text text-right-side header-right",
      cellClass: ["justify-content-end"],
      cellRenderer : function(params) {
        if(params?.value >0){
        return formatIndianNumber(params?.value?.toString())
        }
        else{
          return ""
        }
      },
    },
    {
      headerName: "Fee",
      headerComponentParams: { template: '<span class="outer-span"><span class="amt-col">Fee</span><span class="icon-span">(<i class="fa fa-rupee"></i>)</span>'},
      field: "TPAFee",
      sortable: false,
      filter: false,
      minWidth: 170,
      width: 170,
      headerClass: "right-align wrap-text text-right-side header-right",
      cellClass: ["justify-content-end"],
      cellRenderer : function(params) {
        if(params?.value >0){
        return formatIndianNumber(params?.value?.toString())
        }
        else{
          return ""
        }
      },
    }
  ];

  return (
    <AgGridTable
      rowData={dashboardManagementWinsList}
      className="dashboard-grid"
      columnDefs={columnDefs}
      Style={style}
      getRowHeight={getRowHeight}
      pagination={false}
    />
  );
};

export default Win;
