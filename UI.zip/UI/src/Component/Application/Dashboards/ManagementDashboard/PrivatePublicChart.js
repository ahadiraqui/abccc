import React, { useEffect, useState } from 'react';
import ReactApexChart from 'react-apexcharts';
import { useAppDispatch, useAppSelector } from '../../../../ReduxToolkit/Hooks';
import { GetDashboardManagementPublicPrivate } from '../../../../ReduxToolkit/Reducers/DashboardAction';

const PrivatePublicChart = () => {
  const dispatch = useAppDispatch();
  const dashboardAction = useAppSelector((state)=>state.dashboardAction);
  const dashboardManagementPublicPrivateList = dashboardAction.dashboardManagementPublicPrivateList;

  const [percentData,setPercentData] = useState([]);

  useEffect(()=>{
    dispatch(GetDashboardManagementPublicPrivate())
  },[])

  useEffect(()=>{
    if(dashboardManagementPublicPrivateList && dashboardManagementPublicPrivateList?.length>0)
    {
      const arr = [];
      arr.push(dashboardManagementPublicPrivateList[0]?.PublicPercent);
      arr.push(dashboardManagementPublicPrivateList[0]?.PrivatePercent);

      setPercentData(arr);
    }
  },[])

  const options = {
    // series: [45, 55],
    series : percentData,
    chart: {
      width: 380,
      type: 'pie',
    },
    labels: ['Public', 'Private'],
    legend: {
      position: 'bottom',
    },
    responsive: [
      {
        breakpoint: 480,
        options: {
          chart: {
            width: 200,
          },
          legend: {
            position: 'bottom',
          },
        },
      },
    ],
  };

  return (
    <div id="chart" className="pie-font">
      <ReactApexChart options={options} series={options.series} type="pie" width={380} />
    </div>
  );
};

export default PrivatePublicChart;
