import React, { useEffect, useState } from 'react';
import ReactApexChart from 'react-apexcharts';
import { useAppDispatch, useAppSelector } from '../../../../ReduxToolkit/Hooks';
import { GetDashboardManagementBroker } from '../../../../ReduxToolkit/Reducers/DashboardAction';

const BrokerDistributedChart = () => {
  const dispatch = useAppDispatch();
  const dashboardAction = useAppSelector((state)=>state.dashboardAction);
  const dashboardManagementBrokerList = dashboardAction.dashboardManagementBrokerList;

  const [brokerList,setBrokerList] = useState([]);

  useEffect(()=>{
    dispatch(GetDashboardManagementBroker());
  },[])

  const getRandomColor = () => {
    const colorScale = [
      '#33b1ff', '#fa4d56', '#547D57', '#CC92EB', '#9BB69A',
      '#4E938A', '#73E6C7', '#E2A29C', '#C4C3BA', '#C4905F'
    ];
    return colorScale[Math.floor(Math.random() * colorScale.length)];
  };

  useEffect(()=>{
    if(dashboardManagementBrokerList && dashboardManagementBrokerList?.length>0)
    {
      const data = dashboardManagementBrokerList?.map((item)=>({
        x : item?.BrokerName,
        y : 20,
        // color: getRandomColor()
      }))

      setBrokerList(data);
    }
  },[dashboardManagementBrokerList])

  const options = {
    series: [
      {
        data: brokerList.map(item => ({
          x: item.x,
          y: item.y,
          color: getRandomColor(), // Use getRandomColor function to pick random color from colorScale
        })),
        // data : brokerList,
        // data: [
        //   { x: 'Acme', y: 20 },
        //   { x: 'Helios', y: 40},
        //   { x: 'Km', y: 50},
        //   { x: 'First', y: 55},
        //   { x: 'Marsh', y: 84 },
        //   { x: 'Lambach', y: 31 },
        //   { x: 'Strategic', y: 50 },
        //   { x: 'Dossa', y: 30 },
        //   { x: 'Embee', y: 44 },
        //   { x: 'Hindustan', y: 59 },
        //   { x: 'Globesecure', y: 66 },
        //   { x: 'Unison', y: 25 },
        //   { x: 'Choice', y: 50  },
        //   { x: 'Anand', y: 29 },
        //   { x: 'Blue', y: 40 },
        //   { x: 'Royal', y: 30 },
        //   { x: 'Futurance', y: 59 },
        // ],
      },
    ],
    legend: {
      show: false,
    },
    chart: {
      height: 350,
      type: 'treemap',
      toolbar: {
        show: false
      },
    },
    tooltip: {
      enabled: true,
      style: {
        fontSize: '12px',
        fontFamily: 'Helvetica, Arial, sans-serif',
      },
      custom: function({ series, seriesIndex, dataPointIndex, w }) {
        return `<div>${w.config.series[0].data[dataPointIndex].x}</div>`;
      },
    },
    plotOptions: {
      treemap: {
        distributed: true,
        enableShades: false,
        // colorScale: {
        //   ranges: [
        //     {
        //       from: 0,
        //       to: 20,
        //       color: '#33b1ff',
        //     },
        //     {
        //       from: 21,
        //       to: 30,
        //       color: '#fa4d56',
        //     },
        //     {
        //       from: 31,
        //       to: 35,
        //       color: '#547D57',
        //     },
        //     {
        //       from: 35,
        //       to: 42,
        //       color: '#CC92EB',
        //     },
        //     {
        //       from: 42,
        //       to: 50,
        //       color: '#9BB69A',
        //     },
        //     {
        //       from: 50,
        //       to: 55,
        //       color: '#4E938A',
        //     },
        //     {
        //       from: 55,
        //       to: 60,
        //       color: '#73E6C7',
        //     },
        //     {
        //       from: 60,
        //       to: 70,
        //       color: '#E2A29C',
        //     },
        //     {
        //       from: 70,
        //       to: 80,
        //       color: '#C4C3BA',
        //     },
        //     {
        //       from: 80,
        //       to: 90,
        //       color: '#C4905F',
        //     },
        //   ],
        // },
      },
    },
  };

  return (
    <div id="chart" className="chart-font">
      <ReactApexChart options={options} series={options.series} type="treemap" height={270} />
    </div>
  );
};

export default BrokerDistributedChart;
