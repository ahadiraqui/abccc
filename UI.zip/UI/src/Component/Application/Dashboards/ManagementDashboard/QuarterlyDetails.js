import React from 'react';
import ReactApexChart from 'react-apexcharts';

const QuarterlyAreaChart = () => {
  const options = {
    chart: {
      type: 'area',
      height: 350,
      toolbar: {
        show: false,
      },
    },
    xaxis: {
      categories: ['Q1', 'Q2', 'Q3', 'Q4'], // Quarterly categories
    },
    // yaxis: {
    //   title: {
    //     text: 'Revenue (USD)',
    //   },
    // },
    colors: ['#008FFB', '#00E396', '#FEB019', '#FF4560'], // Color options for the areas
    dataLabels: {
      enabled: false,
    },
    stroke: {
      curve: 'smooth',
    },
    series: [
      {
        name: "Revenue Target",
        data: [30, 40, 35, 50], // Example data for each quarter
      },
      {
        name: "Achieved",
        data: [45, 35, 50, 60], // Example data for another series
      },
    ],
    legend: {
      position: 'bottom',
    },
    tooltip: {
      x: {
        format: 'MMM',
      },
    },
  };

  return (
    <div id="chart" className="chart-font">
      <ReactApexChart options={options} series={options.series} type="area" height={232} />
    </div>
  );
};

export default QuarterlyAreaChart;
