import { useEffect, useState } from 'react';
import React from 'react';
import ReactApexChart from 'react-apexcharts';
import { useAppDispatch, useAppSelector } from '../../../../ReduxToolkit/Hooks';
import { GetDashboardEmployeeYearlyTarget } from '../../../../ReduxToolkit/Reducers/DashboardAction';

const YealryTarget = () => {
  const dispatch = useAppDispatch();
  const dashboardAction = useAppSelector((state)=>state.dashboardAction);
  const dashboardSalesYearlyTarget = dashboardAction.dashboardSalesYearlyTarget;
  const [arr,setArr] = useState([]);

  useEffect(()=>{
    dispatch(GetDashboardEmployeeYearlyTarget());
  },[]);
  
  useEffect(()=>{
    if(dashboardSalesYearlyTarget && Array.isArray(dashboardSalesYearlyTarget) && dashboardSalesYearlyTarget?.length > 0)
    {
      const newarr = [];
      newarr.push(dashboardSalesYearlyTarget[0]?.EmployeeAchievedTargetPercent)
      setArr(newarr);
    }
  },[dashboardSalesYearlyTarget]);
  
  const options = {
    series: arr,
    chart: {
      height: 350,
      type: 'radialBar',
    },
    plotOptions: {
      radialBar: {
        hollow: {
          size: '70%',
        },
        track: {
          background: '#f2f2f2', // Background color of the circular track
        },
        dataLabels: {
          name: {
            show: true,
          },
          value: {
            color:'#26a0fc',
            fontWeight:600,
            fontSize: '20px', // Font size of the value label inside the bar
            offsetY: 8, // Offset of the value label from the center
          },
        },
      },
    },
    colors: ['#26a0fc', '#f2f2f2'], // Custom colors for the bars
    fill: {
      type: 'gradient',
      gradient: {
        shade: 'dark',
        type: 'horizontal',
        shadeIntensity: 0.5,
        gradientToColors: ['#26a0fc'],
        inverseColors: true,
        opacityFrom: 1,
        opacityTo: 1,
        stops: [0, 100]
      }
    },
    stroke: {
      lineCap: 'round'
    },
    labels: ['Achieved Target'],
  };

  return (
    <div id="chart">
      <ReactApexChart options={options} series={options.series} type="radialBar" height={350} />
    </div>
  );
};

export default YealryTarget;
