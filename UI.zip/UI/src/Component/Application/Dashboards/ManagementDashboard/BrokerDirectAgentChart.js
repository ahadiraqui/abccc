import React, { useEffect, useState } from 'react';
import ReactApexChart from 'react-apexcharts';
import { useAppDispatch, useAppSelector } from '../../../../ReduxToolkit/Hooks';
import { GetDashboardManagementBrokerDirectAgent } from '../../../../ReduxToolkit/Reducers/DashboardAction';

const BrokerDirectAgentChart = () => {
  const dispatch = useAppDispatch();
  const dashboardAction = useAppSelector((state)=>state.dashboardAction);
  const dashboardManagementBrokerDirectAgentList = dashboardAction.dashboardManagementBrokerDirectAgentList;

  const [percentData,setPercentData] = useState([]);

  useEffect(()=>{
    dispatch(GetDashboardManagementBrokerDirectAgent());
  },[]);

  useEffect(()=>{
    if(dashboardManagementBrokerDirectAgentList && dashboardManagementBrokerDirectAgentList?.length>0)
    {
      const arr=[];
      arr.push(dashboardManagementBrokerDirectAgentList[0]?.DirectPercent);
      arr.push(dashboardManagementBrokerDirectAgentList[0]?.BrokerPercent);
      arr.push(dashboardManagementBrokerDirectAgentList[0]?.AgentPercent);

      setPercentData(arr);
    }
  },[dashboardManagementBrokerDirectAgentList])

  const options = {
    // series: [44, 55,36],
    series : percentData,
    chart: {
      width: 380,
      type: 'pie',
    },
    labels: ['Direct', 'Broker','Agent'],
    legend: {
      position: 'bottom',
    },
    responsive: [
      {
        breakpoint: 480,
        options: {
          chart: {
            width: 200,
          },
          legend: {
            position: 'bottom',
          },
        },
      },
    ],
  };

  return (
    <div id="chart" className="pie-font">
      <ReactApexChart options={options} series={options.series} type="pie" width={380} />
    </div>
  );
};

export default BrokerDirectAgentChart;
