import { useEffect, useState } from "react";

import { FormGroup, Label, Row, Col, CardBody, Card } from "reactstrap";

import { Btn, H6, H5, H4, SVG } from "../../../../AbstractElements";
import { Link } from "react-router-dom";
import MonthlyTarget from "./MonthlyTarget";

import YealryTarget from "./YealryTarget";

import BranchWiseDetails from "./BranchWiseDetails";

import MonthlyPerformance from "./MonthlyPerformance";
import DistributedChart from "./DistributedChart";
import PrivatePublicChart from "./PrivatePublicChart";
import BrokerDirectAgentChart from "./BrokerDirectAgentChart";
import BrokerDistributedChart from "./BrokerDistributedChart";
import QuarterlyDetails from "./QuarterlyDetails";
import SectorDistributedChart from "./SectorDistributedChart";
import EmployeeChart from "./EmployeeChart";
import Win from "./Tables/Win";
import Lost from "./Tables/Lost";
import { useAppDispatch, useAppSelector } from "../../../../ReduxToolkit/Hooks";
import { GetDashboardEmployeeSalesPipeline } from "../../../../ReduxToolkit/Reducers/DashboardAction";


export const ManagementDashboard = () => {
  const dispatch = useAppDispatch();
  const dashboardAction = useAppSelector((state:any)=>state.dashboardAction);
  const dashboardSalesPipeline = dashboardAction.dashboardSalesPipeline;
  
  const [explorationPipeline,setExplorationPipeline] = useState<any>(null);
  const [leadPipeline,setLeadPipeline] = useState<any>(null);
  const [winPipeline,setWinPipeline] = useState<any>(null);

  useEffect(()=>{
    dispatch(GetDashboardEmployeeSalesPipeline());
  },[])

  useEffect(()=>{
    if(dashboardSalesPipeline && Array.isArray(dashboardSalesPipeline) && dashboardSalesPipeline?.length>0)
    {
      for(let i=0;i<dashboardSalesPipeline?.length;i++)
      {
        if(dashboardSalesPipeline[i]?.CurrentStage === "Exploration")
        {
          setExplorationPipeline(dashboardSalesPipeline[i]);
        }
        else if(dashboardSalesPipeline[i]?.CurrentStage === "Lead")
        {
          setLeadPipeline(dashboardSalesPipeline[i]);
        } 
        else if(dashboardSalesPipeline[i]?.CurrentStage === "Close")
        {
          setWinPipeline(dashboardSalesPipeline[i]);
        }
      }
    }
  },[dashboardSalesPipeline]);

  return (
    <div className="page-body">
      <div className="m-block center-block-meeting  mt-4 mb-1  pt-1 pt-1">
        <div className="ps-0">
          <h3 className="screen-title text-tr-none mb-2">Dashboard</h3>
        </div>
        <Row>
          <Col md="6">
            <Row>
              <Col md="6">
                <Card>
                  <CardBody style={{minHeight:'306px',maxHeight:'306px'}}>
                    <p className="chart-title mb-0">Monthly Target(Not Available)</p>
                    <MonthlyTarget />
                  </CardBody>
                </Card>
              </Col>
              <Col md="6">
                <Card>
                  <CardBody style={{minHeight:'306px',maxHeight:'306px'}}>
                    <p className="chart-title mb-0">Yearly Target</p>
                    <YealryTarget />
                  </CardBody>
                </Card>
              </Col>
            </Row>
          </Col>
          <Col md="6">
            <Card>
              <CardBody>
                <p className="chart-title mb-0">Sales Pipeline</p>
                <Row>
                  <Col md="6" className="opp-card animate-2">
                  <div className="d-flex card-1">
                      <span>
                        <SVG iconId="Revenue" />
                      </span>
                      <div className="flex-shrink-0">
                        <H4>{explorationPipeline?.ExplorationCount > 0 ? explorationPipeline?.ExplorationCount: ""}</H4>
                        <H6>Exploration</H6>
                        <div className="arrow-chart">
                          {/* <SVG iconId="arrow-chart-up" /> */}
                          <H5 className="font-success">{explorationPipeline?.Explorationpremium  ? explorationPipeline?.Explorationpremium: ""}</H5>
                        </div>
                      </div>
                    </div>
                  </Col>
                  <Col md="6" className="opp-card animate-2">
                  <div className="d-flex animate lead card-2 animate-2">
                  <span className="lead-svg">
                        <SVG iconId="Sales" />
                      </span>
                      <div className="flex-shrink-0">
                        <H4>{leadPipeline?.LeadCount > 0 ? leadPipeline?.LeadCount: ""}</H4>
                        <H6>Leads</H6>
                        <div className="arrow-chart">
                          {/* <SVG iconId="arrow-chart-up" /> */}
                          <H5 className="font-success">{leadPipeline?.LeadPremium ? leadPipeline?.LeadPremium: ""}</H5>
                        </div>
                      </div>
                    </div>
                  </Col>
                  <Col md="6"  className="opp-card animate-2">
                  <div className="d-flex card-3 win">
                  <span className="win-svg">
                        <SVG iconId="Customer" />
                      </span>
                      <div className="flex-shrink-0">
                        <H4>{winPipeline?.WinCount > 0 ? winPipeline?.WinCount: ""}</H4>
                        <H6>Wins</H6>
                        <div className="arrow-chart">
                          {/* <SVG iconId="arrow-chart-up" /> */}
                          <H5 className="font-success">{winPipeline?.WinPremium ? winPipeline?.WinPremium: ""}</H5>
                        </div>
                      </div>
                    </div>
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Col>
        </Row>
        <Row>
        <Col md="6">
            <Card>
              <CardBody>
                <p className="chart-title mb-0">Quarterly Details(Not Available)</p>
                <QuarterlyDetails/>
              </CardBody>
            </Card>
          </Col>
          <Col md="6">
            <Card>
              <CardBody>
                <p className="chart-title mb-0">Monthwise Details(Not Available)</p>
                <MonthlyPerformance />
              </CardBody>
            </Card>
          </Col>
        </Row>
        <Row>
            <Col md="12">
              <Card>
                <CardBody>
                  <p className="chart-title mb-0">Branchwise Details(Not Available)</p>
                    <BranchWiseDetails/>
                </CardBody>
              </Card>
            </Col>
          </Row>
          <Row>
            <Col md="8">
              <Card>
                <CardBody>
                  <p className="chart-title mb-0">Insurance</p>
                   <DistributedChart/>
                </CardBody>
              </Card>
            </Col>
            <Col md="4">
            <Card>
                <CardBody>
                  <p className="chart-title mb-0"> Public And Private</p>
                   <PrivatePublicChart/>
                </CardBody>
              </Card>
            </Col>
          </Row>
          <Row>
          <Col md="4">
            <Card>
                <CardBody>
                  <p className="chart-title mb-0">Broker / Direct / Agent</p>
                  <BrokerDirectAgentChart/>
                </CardBody>
              </Card>
            </Col>
            <Col md="8">
              <Card>
                <CardBody>
                  <p className="chart-title mb-0">Broker</p>
                   <BrokerDistributedChart/>
                </CardBody>
              </Card>
            </Col>          
          </Row>
          <Row>
          <Col md="12">
            <Card>
                <CardBody>
                  <p className="chart-title mb-0">Sector</p>
                 <SectorDistributedChart/>
                </CardBody>
              </Card>
            </Col>   
          
          </Row>
          <Row>
          <Col md="12">
            <Card>
                <CardBody>
                  <p className="chart-title mb-0">Employee</p>
                <EmployeeChart/>
                </CardBody>
              </Card>
            </Col>   
          
          </Row>
          <Row>
        <Col md="6">
            <Card>
              <CardBody>
                <p className="chart-title mb-2">Top 10 Wins</p>
                <Win/>
              </CardBody>
            </Card>
          </Col>
          <Col md="6">
            <Card>
              <CardBody>
              <p className="chart-title mb-2">Top 10 Loses</p>
              <Lost/>
              </CardBody>
            </Card>
          </Col>
        </Row>
      
      </div>
  
    </div>
  );
};
