import React, { useEffect, useState } from "react";
import ReactApexChart from "react-apexcharts";
import { ApexOptions } from "apexcharts";
import { useAppDispatch, useAppSelector } from "../../../../ReduxToolkit/Hooks";
import { GetMonthWiseConsolidatedSummary } from "../../../../ReduxToolkit/Reducers/GapReportAction";
import dayjs from "dayjs";

const MonthlyPerformance = () => {
  const dispatch = useAppDispatch();
  const gapReportAction = useAppSelector((state:any)=>state.gapReportAction);
  const mMonthWiseReport = gapReportAction.mMonthWiseReport; 
  const [minValue,setMinValue] = useState(0);
  const [maxValue,setMaxValue] = useState(0);
  const [target,setTarget] = useState([]);
  const [actual,setActual] = useState([]);

  function generateFinancialYearMonths(year:any) {
    const months = [];
    let currentMonth = dayjs(`${year}-04-01`);

    for(let i=0;i<12;i++)
    {
      months.push(currentMonth.format("MMM-YYYY"));
      currentMonth = currentMonth.add(1,"month");
    }

    return months;
  }

  const setValues = () =>{
    const tar:any = [];
    const act :any= [];
    
    for(let i=0;i<mMonthWiseReport?.length;i++)
    {
      tar.push(mMonthWiseReport[i]?.SalesTargetForTheMonth)
      act.push(mMonthWiseReport[i]?.ActualBusiness)
    }

    setTarget(tar);
    setActual(act);
  }

  const getMinMaxValues = () => {
    let minValueSales = mMonthWiseReport[0].SalesTargetForTheMonth;
    let maxValueSales = mMonthWiseReport[0].SalesTargetForTheMonth;

    let minValueActualBusiness = mMonthWiseReport[0].ActualBusiness;
    let maxValueActualBusiness = mMonthWiseReport[0].ActualBusiness;

    for(let i=1;i<mMonthWiseReport.length;i++)
    {
      if(minValueSales>mMonthWiseReport[i]?.SalesTargetForTheMonth)
      {
        minValueSales = mMonthWiseReport[i]?.SalesTargetForTheMonth
      }
      if(maxValueSales < mMonthWiseReport[i]?.SalesTargetForTheMonth)
      {
        maxValueSales = mMonthWiseReport[i]?.SalesTargetForTheMonth
      }
      if(minValueActualBusiness > mMonthWiseReport[i]?.ActualBusiness)
      {
        minValueActualBusiness = mMonthWiseReport[i]?.ActualBusiness
      }
      if(maxValueActualBusiness < mMonthWiseReport[i]?.ActualBusiness)
      {
        minValueActualBusiness = mMonthWiseReport[i]?.ActualBusiness
      }
    }

    minValueSales > minValueActualBusiness ? setMinValue(minValueActualBusiness) : setMinValue(minValueSales);
    maxValueSales > maxValueActualBusiness ? setMaxValue(maxValueSales) : setMaxValue(maxValueActualBusiness);
  }

  const currentYear = dayjs().year();
  const financialYearMonths = generateFinancialYearMonths(currentYear);
  // console.log("financialYearMonths",minValue,maxValue);

  useEffect(()=>{
    dispatch(GetMonthWiseConsolidatedSummary());
  },[]);

  useEffect(()=>{
    if(mMonthWiseReport && mMonthWiseReport?.length > 0)
    {
      getMinMaxValues();
      setValues();
    }
  },[mMonthWiseReport])
  
  const areaSaplingChart: ApexOptions = {
    chart: {
      height: 250,
      type: "area",
      toolbar: {
        show: false
      }
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      width: 3,
      curve: "smooth"
    },
    series: [
      {
        name: "Revenue Target",
        // data: [30, 29.5, 29.7, 30.7, 31.8, 32.8, 32.5, 33, 32.5, 32,30.5,41]
        data: target
      },
      {
        name: "Achieved",
        // data: [35, 28, 20, 22, 25, 35, 30, 35, 34, 35, 20, 60]
        data : actual
      }
    ],
    xaxis: {
      type: "category",
      categories : financialYearMonths
    },
    markers: {
      hover: {
        sizeOffset: 4
      }
    },
    yaxis: {
      min: minValue,
      max: maxValue,
      tickAmount: 5,
      labels: {
        formatter: function(val) {
          return val.toFixed(2); // format y-axis labels as integers
        }
      }
    },
    tooltip: {
      x: {
    formatter: function(val) {
      
      if (areaSaplingChart.xaxis && areaSaplingChart.xaxis.categories) {
        // Check if categories array exists and has the corresponding index
        const categories = areaSaplingChart.xaxis.categories;
        if (val >= 0 && val < categories.length) {
          // Retrieve the month from the categories array using the index (val)
          // if (index !== -1) {
          //   return categories[val];
          // }
          return categories[val];
        }
      }
      // Default return value if categories array is not defined or index is invalid
      return "Month " + val;
    }
  },
      y: {
        formatter: function(val) {
          return val.toFixed(2); // format y-axis tooltip as fixed to two decimal places
        }
      }
    },
    colors: ["#5c61f2", "#ff9766"]
  };

  return (
    <div>
      <div>
        <ReactApexChart
          options={areaSaplingChart}
          series={areaSaplingChart.series}
          type="area"
          height={232}
        />
      </div>
    </div>
  );
};

export default MonthlyPerformance;
