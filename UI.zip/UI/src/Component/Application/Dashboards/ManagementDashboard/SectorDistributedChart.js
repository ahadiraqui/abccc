import React, { useEffect, useState } from 'react';
import ReactApexChart from 'react-apexcharts';
import { useAppDispatch, useAppSelector } from '../../../../ReduxToolkit/Hooks';
import { GetDashboardManagementSector } from '../../../../ReduxToolkit/Reducers/DashboardAction';

const SectorDistributedChart = () => {
  const dispatch = useAppDispatch();
  const dashboardAction = useAppSelector((state)=>state.dashboardAction);
  const dashboardManagementSectorList = dashboardAction.dashboardManagementSectorList;

  const [sectorList,setSectorList] = useState([]);

  useEffect(()=>{
    dispatch(GetDashboardManagementSector());
  },[])

  useEffect(()=>{
    if(dashboardManagementSectorList && dashboardManagementSectorList?.length>0)
    {
      const data = dashboardManagementSectorList?.map((item)=>({
        x : item?.Name,
        y : 20,
        // color: getRandomColor()
      }))

      setSectorList(data);
    }
  },[dashboardManagementSectorList])

  const options = {
    series: [
      {
        data : sectorList,
        // data: [
        //   { x: 'Acme', y: 20 },
        //   { x: 'Helios', y: 40},
        //   { x: 'Km', y: 50},
        //   { x: 'First', y: 55},
        //   { x: 'Marsh', y: 84 },
        //   { x: 'Lambach', y: 31 },
        //   { x: 'Strategic', y: 50 },
        //   { x: 'Dossa', y: 30 },
        //   { x: 'Embee', y: 44 },
        //   { x: 'Hindustan', y: 59 },
        //   { x: 'Globesecure', y: 66 },
        //   { x: 'Unison', y: 25 },
        //   { x: 'Choice', y: 50  },
        //   { x: 'Anand', y: 29 },
        //   { x: 'Blue', y: 40 },
        //   { x: 'Royal', y: 30 },
        //   { x: 'Futurance', y: 59 },
        // ],
      },
    ],
    legend: {
      show: false,
    },
    chart: {
      height: 350,
      type: 'treemap',
      toolbar: {
        show: false
      },
    },
    tooltip: {
      enabled: true,
      style: {
        fontSize: '12px',
        fontFamily: 'Helvetica, Arial, sans-serif',
      },
      custom: function({ series, seriesIndex, dataPointIndex, w }) {
        return `<div>${w.config.series[0].data[dataPointIndex].x}</div>`;
      },
    },
    plotOptions: {
      treemap: {
        distributed: true,
        enableShades: false,
        // colorScale: {
        //   ranges: [
        //     {
        //       from: 70,
        //       to: 80,
        //       color: '#33b1ff',
        //     },
        //     {
        //       from: 60,
        //       to: 70,
        //       color: '#fa4d56',
        //     },
        //     {
        //       from: 60,
        //       to: 70,
        //       color: '#547D57',
        //     },
        //     {
        //       from: 50,
        //       to: 60,
        //       color: '#CC92EB',
        //     },
        //     {
        //       from: 40,
        //       to: 50,
        //       color: '#9BB69A',
        //     },
        //     {
        //       from: 30,
        //       to: 40,
        //       color: '#4E938A',
        //     },
        //     {
        //       from: 20,
        //       to: 30,
        //       color: '#73E6C7',
        //     },
        //     {
        //       from: 10,
        //       to: 20,
        //       color: '#E2A29C',
        //     },
        //     {
        //       from: 0,
        //       to: 20,
        //       color: '#C4C3BA',
        //     },
        //     {
        //       from: 80,
        //       to: 90,
        //       color: '#C4905F',
        //     },
        //   ],
        // },
      },
    },
  };

  // Rendering the chart component
  return (
    <div id="chart" className="chart-font">
      <ReactApexChart options={options} series={options.series} type="treemap" height={270} />
    </div>
  );
};

export default SectorDistributedChart;
