import { useEffect, useState } from "react";

import { FormGroup, Label, Row, Col, CardBody, Card } from "reactstrap";

import { Btn, H6, H5, H4, SVG } from "../../../../AbstractElements";
import { Link } from "react-router-dom";
import MonthlyTarget from "./MonthlyTarget";
import ConsolidatedSummaryReportChart from "../../Reports/YearlyConsolidatedSummaryReport/ConsolidatedSummaryReportChart";
import MonthlyPerformance from "./MonthlyPerformance";

import YealryTarget from "./YealryTarget";
import OpportunityYearly from "./OpportunityYearly";
import TotalRevenue from "../../../Dashboard/Ecommerce/TotalRevenue/TotalRevenue";
import LatestWinActive from "./Tables/LatestWinActive";
import WinAndNotActive from "./Tables/WinAndNotActive";
import UpcomingPresentations from "./Tables/UpcomingPresentations";
import UpcomingRenewals from "./Tables/UpcomingRenewals";
import { useAppDispatch, useAppSelector } from "../../../../ReduxToolkit/Hooks";
import { GetDashboardEmployeeSalesPipeline } from "../../../../ReduxToolkit/Reducers/DashboardAction";

export const SalesPersonDashboard = () => {
  const dispatch = useAppDispatch();
  const dashboardAction = useAppSelector((state:any)=>state.dashboardAction);
  const dashboardSalesPipeline = dashboardAction.dashboardSalesPipeline;
  
  const [explorationPipeline,setExplorationPipeline] = useState<any>(null);
  const [leadPipeline,setLeadPipeline] = useState<any>(null);
  const [winPipeline,setWinPipeline] = useState<any>(null);

  useEffect(()=>{
    dispatch(GetDashboardEmployeeSalesPipeline());
  },[])

  useEffect(()=>{
    if(dashboardSalesPipeline && dashboardSalesPipeline?.length>0)
    {
      for(let i=0;i<dashboardSalesPipeline?.length;i++)
      {
        if(dashboardSalesPipeline[i]?.CurrentStage === "Exploration")
        {
          setExplorationPipeline(dashboardSalesPipeline[i]);
        }
        else if(dashboardSalesPipeline[i]?.CurrentStage === "Lead")
        {
          setLeadPipeline(dashboardSalesPipeline[i]);
        } 
        else if(dashboardSalesPipeline[i]?.CurrentStage === "Close")
        {
          setWinPipeline(dashboardSalesPipeline[i]);
        }
      }
    }
  },[dashboardSalesPipeline]);

  return (
    <div className="page-body">
      <div className="m-block center-block-meeting  mt-4 mb-1  pt-1 pt-1">
        <div className="ps-0 col-sm-6">
          <h3 className="screen-title text-tr-none mb-2">Dashboard</h3>
        </div>
        <Row>
          <Col md="6">
            <Row>
              <Col md="6">
                <Card>
                  <CardBody style={{minHeight:'306px',maxHeight:'306px'}}>
                    <p className="chart-title mb-0">Monthly Target(Not Available)</p>
                    <MonthlyTarget />
                  </CardBody>
                </Card>
              </Col>
              <Col md="6">
                <Card>
                  <CardBody style={{minHeight:'306px',maxHeight:'306px'}}>
                    <p className="chart-title mb-0">Yearly Target</p>
                    <YealryTarget />
                  </CardBody>
                </Card>
              </Col>
            </Row>
          </Col>
          <Col md="6">
            <Card>
              <CardBody>
                <p className="chart-title mb-0">Monthwise Achieved Target(Not Available)</p>
                <MonthlyPerformance />
              </CardBody>
            </Card>
          </Col>
        </Row>
        <Row className="opp-card">
          <Col md="6">
          <Card>
              <CardBody>
                <p className="chart-title mb-0">Sales Pipeline</p>
                <Row>
              <Col md="6">
                <Card className="animate" style={{backgroundColor: '#e2e5ff'}}>
                  <CardBody>
                    <div className="d-flex">
                      <span>
                        <SVG iconId="Revenue" />
                      </span>
                      <div className="flex-shrink-0">
                        <H4>{explorationPipeline?.ExplorationCount > 0 ? explorationPipeline?.ExplorationCount: ""}</H4>
                        <H6>Exploration</H6>
                        <div className="arrow-chart">
                          {/* <SVG iconId="arrow-chart-up" /> */}
                          <H5 className="font-success">{explorationPipeline?.Explorationpremium  ? explorationPipeline?.Explorationpremium: ""}</H5>
                        </div>
                      </div>
                    </div>
                  </CardBody>
                </Card>
              </Col>
              <Col md="6">
                <Card className="animate" style={{backgroundColor: '#ffede5'}}>
                  <CardBody>
                    <div className="d-flex lead">
                      <span className="lead-svg">
                        <SVG iconId="Sales" />
                      </span>
                      <div className="flex-shrink-0">
                        <H4>{leadPipeline?.LeadCount > 0 ? leadPipeline?.LeadCount: ""}</H4>
                        <H6>Leads</H6>
                        <div className="arrow-chart">
                          {/* <SVG iconId="arrow-chart-up" /> */}
                          <H5 className="font-success">{leadPipeline?.LeadPremium ? leadPipeline?.LeadPremium: ""}</H5>
                        </div>
                      </div>
                    </div>
                  </CardBody>
                </Card>
              </Col>
              <Col md="6">
                <Card className="animate" style={{backgroundColor: '#e4f1df'}}>
                  <CardBody>
                    <div className="d-flex win">
                      <span className="win-svg">
                        <SVG iconId="Customer" />
                      </span>
                      <div className="flex-shrink-0">
                        <H4>{winPipeline?.WinCount > 0 ? winPipeline?.WinCount: ""}</H4>
                        <H6>Wins</H6>
                        <div className="arrow-chart">
                          {/* <SVG iconId="arrow-chart-up" /> */}
                          <H5 className="font-success">{winPipeline?.WinPremium ? winPipeline?.WinPremium: ""}</H5>
                        </div>
                      </div>
                    </div>
                  </CardBody>
                </Card>
              </Col>
              {/* <Col md="6">
                <Card className="animate" style={{backgroundColor: '#c9e6f5'}}>
                  <CardBody>
                    <div className="d-flex ret">
                      <span className="ret-svg">
                        <SVG iconId="Product" />
                      </span>
                      <div className="flex-shrink-0">
                        <H4>10</H4>
                        <H6>Retention</H6>
                        <div className="arrow-chart">
                          <SVG iconId="arrow-chart" />
                          <H5 className="font-danger">-10%</H5>
                        </div>
                      </div>
                    </div>
                  </CardBody>
                </Card>
              </Col> */}
            </Row>
              </CardBody>
            </Card>

         
          </Col>
          <Col md="6">
            <Card>
              <CardBody>
                <p className="chart-title mb-0">Yearly Opportunity</p>
                <OpportunityYearly />
              </CardBody>
            </Card>
          </Col>
        </Row>
        <Row>
          <Col md="6">
            <Card>
              <CardBody>
                <p className="chart-title mb-1">Latest Wins/Active</p>
                <LatestWinActive />
              </CardBody>
            </Card>
          </Col>
          <Col md="6">
            <Card>
              <CardBody>
                <p className="chart-title mb-1">Wins/Not Active</p>
                <WinAndNotActive/>
              </CardBody>
            </Card>
          </Col>
        </Row>
        <Row>
          <Col md="6">
            <Card>
              <CardBody>
                <p className="chart-title mb-1">Upcoming Presentations</p>
               <UpcomingPresentations/>
              </CardBody>
            </Card>
          </Col>
          <Col md="6">
            <Card>
              <CardBody>
                <p className="chart-title mb-1">Upcoming Renewals</p>
                <UpcomingRenewals/>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    </div>
  );
};
