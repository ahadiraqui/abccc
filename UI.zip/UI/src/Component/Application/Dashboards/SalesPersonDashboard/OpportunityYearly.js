import React, { useEffect, useState } from 'react';
import ReactApexChart from 'react-apexcharts';
import { useAppDispatch, useAppSelector } from '../../../../ReduxToolkit/Hooks';
import { GetDashboardEmployeeYearlyOpportunity } from '../../../../ReduxToolkit/Reducers/DashboardAction';

const OpportunityYearly = () => {
  const dispatch = useAppDispatch();
  const dashboardAction = useAppSelector((state)=>state.dashboardAction);
  const dashboardSalesYearlyOpportunity = dashboardAction.dashboardSalesYearlyOpportunity;

  const [maxValue,setMaxValue] = useState(0);
  const [explorationList,setExplorationList] = useState([]);
  const [leadList,setLeadList] = useState([]);
  const [winList,setWinList] = useState([]);
  const [months,setMonths] = useState([])

  useEffect(()=>{
    dispatch(GetDashboardEmployeeYearlyOpportunity());
  },[])

  useEffect(() => {
    if (dashboardSalesYearlyOpportunity && dashboardSalesYearlyOpportunity.length > 0) {
      let max = 0;

      const months = [...new Set(dashboardSalesYearlyOpportunity.map(item => item.Month))];
      
      months.sort((a, b) => {
        const monthOrder = [ 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec','Jan', 'Feb', 'Mar'];
        return monthOrder.indexOf(a) - monthOrder.indexOf(b);
      });

      const stageData = {
        'Exploration': [],
        'Lead': [],
        'Close': []
      };

      dashboardSalesYearlyOpportunity.forEach(item => {
        stageData[item.CurrentStage].push(item);
        if (item.ExplorationCount > max && item.CurrentStage === 'Exploration') {
          max = item.ExplorationCount;
        }
        if (item.LeadCount > max && item.CurrentStage === 'Lead') {
          max = item.LeadCount;
        }
        if (item.WinCount > max && item.CurrentStage === 'Close') {
          max = item.WinCount;
        }
      });

      setMaxValue(max);
      setExplorationList(months.map(month => stageData['Exploration'].find(item => item.Month === month)?.ExplorationCount || 0));
      setLeadList(months.map(month => stageData['Lead'].find(item => item.Month === month)?.LeadCount || 0));
      setWinList(months.map(month => stageData['Close'].find(item => item.Month === month)?.WinCount || 0));
      setMonths(months);
    }
  }, [dashboardSalesYearlyOpportunity]);

  const options = {
    series: [
      {
        name: 'Exploration',
        data :explorationList
        // data: [44, 55, 57, 56, 61, 58, 63, 60, 66, 68, 70, 72] // Add more data points for each month
      },
      {
        name: 'Leads',
        data : leadList
        // data: [76, 85, 101, 98, 87, 105, 91, 114, 94, 98, 102, 110] // Add more data points for each month
      },
      {
        name: 'Wins',
        data : winList
        // data: [35, 41, 36, 26, 45, 48, 52, 53, 41, 44, 47, 50] // Add more data points for each month
      }
    ],
    chart: {
      type: 'bar',
      height: 235,
      toolbar: {
        show: false
      },
    },
  
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: '55%',
        endingShape: 'rounded'
      }
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      show: true,
      width: 2,
      colors: ['transparent']
    },
    xaxis: {
      categories : months
      // categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], // Updated to include all months
    },
    yaxis: {
      // title: {
      //   text: '$ (thousands)'
      // },
      min: 0,
      max: maxValue,
      tickAmount: 6,
    },
    fill: {
      opacity: 1
    },
    colors: ['#5c61f2', '#ff9766', '#51bb25'],
    tooltip: {
      y: {
        formatter: function (val) {
          // return "$ " + val + " thousands";
          return val;
        }
      }
    }
  };

  return (
    <div className="column-chart">
      <ReactApexChart options={options} series={options.series} type="bar" height={235} />
    </div>
  );
};

export default OpportunityYearly;
