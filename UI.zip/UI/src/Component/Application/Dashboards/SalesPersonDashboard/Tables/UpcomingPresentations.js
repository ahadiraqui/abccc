import { Col, Row } from "reactstrap";
import AgGridTable from "../../../../../CommonElements/AgGridTable";
import { GetDashboardEmployeeUpcomingPresentations } from "../../../../../ReduxToolkit/Reducers/DashboardAction";
import { useAppDispatch, useAppSelector } from "../../../../../ReduxToolkit/Hooks";
import { useEffect } from "react";

const UpcomingPresentations = () => {
  const dispatch = useAppDispatch();
  const dashboardAction = useAppSelector((state)=>state.dashboardAction);
  const dashboardSalesUpcomingPresentationList = dashboardAction.dashboardSalesUpcomingPresentationList;

  useEffect(()=>{
    dispatch(GetDashboardEmployeeUpcomingPresentations());
  },[])

  const style = { height: "213px", width: "100%" };
  const getRowHeight = () => 40;

  const columnDefs = [
    // {
    //   headerName: "SN",
    //   field: "SN",
    //   sortable: false,
    //   filter: false,
    //   resizable: false,
    //   suppressMovable: true,
    //   minWidth: 60,
    //   width: 60
    // },

    {
      headerName: "Corporate",
      field: "CorporateName",
      sortable: false,
      filter: false,
      minWidth: 170,
      resizable: false,
      autoHeight: true,
      width: 170,
      suppressMovable: true,
      cellStyle: function(params) {
        return { whiteSpace: "normal" };
      }
    },

    {
      headerName: "Confidence Level",
      field: "ConfidenceLevel",
      sortable: false,
      resizable: false,
      filter: false,
      minWidth: 130,
      width: 130,
      autoHeight: true,
      suppressMovable: true,
      headerClass: "right-align wrap-text text-right-side",
      cellClass: ["justify-content-end"],
      cellStyle: function(params) {
        return { whiteSpace: "normal" };
      }
    },
    {
      headerName: "Date",
      field: "PresentationDate",
      sortable: false,
      resizable: false,
      filter: false,
      minWidth: 100,
      autoHeight: true,
      suppressMovable: true,
      width: 100,
      headerClass: "right-align wrap-text text-right-side",
      cellClass: ["justify-content-end"]
    },
    {
      headerName: "Influencer",
      field: "InfluencerName",
      sortable: false,
      resizable: false,
      filter: false,
      autoHeight: true,
      minWidth: 140,
      suppressMovable: true,
      width: 140,
      headerClass: "right-align wrap-text text-right-side",
      cellClass: ["justify-content-end"],
      cellRenderer : function(params) { 
        if (typeof params.value === 'object' && Object.keys(params.value).length === 0) {
          return '';
        } else {
          return params.value.toString();
        }
      }
    }
  ];
  const rowData = [
    {
      SN: 1,
      Corporate: "Eicher Motors",
      ConfidenceLevel: "High",
      Date: "18-Jun-2024",
      Influencer: "Santosh Jadhav"
    },
    {
      SN: 2,
      Corporate: "Bajaj Finance",
      ConfidenceLevel: "Average",
      Date: "17-Jun-2024",
      Influencer: "Sham Patil"
    },

    {
      SN: 3,
      Corporate: "Nestle Indai",
      ConfidenceLevel: "High",
      Date: "16-Jun-2024",
      Influencer: "Rohit Patidar"
    }
  ];

  return (
    <AgGridTable
      rowData={dashboardSalesUpcomingPresentationList}
      className="dashboard-grid"
      columnDefs={columnDefs}
      Style={style}
      getRowHeight={getRowHeight}
      pagination={false}
    />
  );
};

export default UpcomingPresentations;
