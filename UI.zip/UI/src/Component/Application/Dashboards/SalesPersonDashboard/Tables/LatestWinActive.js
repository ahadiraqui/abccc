import { useEffect } from "react";
import { Col, Row } from "reactstrap";
import AgGridTable from "../../../../../CommonElements/AgGridTable";
import { useAppDispatch, useAppSelector } from "../../../../../ReduxToolkit/Hooks";
import { GetDashboardEmployeeWinsActive } from "../../../../../ReduxToolkit/Reducers/DashboardAction";
import { formatIndianNumber } from "../../../OpportunityGrid/formatIndianNumber";

const LatestWinActive = () => {
  const dispatch = useAppDispatch();
  const dashboardAction = useAppSelector((state)=>state.dashboardAction);
  const dashboardSalesWinActiveList = dashboardAction.dashboardSalesWinActiveList;

  useEffect(()=>{
    dispatch(GetDashboardEmployeeWinsActive());
  },[])

  const style = { height: "213px", width: "100%" };
  const getRowHeight = () => 40;

  const columnDefs = [
    // {
    //   headerName: "SN",
    //   field: "SN",
    //   sortable: false,
    //   filter: false,
    //   resizable: false,
    //   suppressMovable: true,
    //   minWidth: 60,
    //   width: 60
    // },

    {
      headerName: "Corporate",
      field: "CorporateName",
      sortable: false,
      filter: false,
      minWidth: 165,
      resizable: false,
      autoHeight: true,
      width: 165,
      suppressMovable: true,
      cellStyle: function(params) {
        return { whiteSpace: "normal" };
      }
    },

    {
      headerName: "Premium",
      headerComponentParams: { template: '<span class="outer-span"><span class="amt-col">Premium</span><span class="icon-span">(<i class="fa fa-rupee"></i>)</span>'},
      field: "premium",
      sortable: false,
      resizable: false,
      filter: false,
      minWidth: 140,
      width: 140,
      autoHeight: true,
      suppressMovable: true,
      headerClass: "right-align wrap-text text-right-side header-right",
      cellClass: ["justify-content-end"],
      cellStyle: function(params) {
        return { whiteSpace: "normal" };
      },
      cellRenderer : function(params){
        if(params?.value>0)
        {
          return formatIndianNumber(params?.value?.toString())
        }else {
          return ""
        }
      }
    },
    {
      headerName: "TPA fee %",
      field: "TPAFeePercent",
      sortable: false,
      resizable: false,
      filter: false,
      minWidth: 110,
      autoHeight: true,
      suppressMovable: true,
      width: 110,
      headerClass: "right-align wrap-text text-right-side",
      cellClass: ["justify-content-end"]
    },
    {
      headerName: "TPA fee",
      headerComponentParams: { template: '<span class="outer-span"><span class="amt-col">TPA fee</span><span class="icon-span">(<i class="fa fa-rupee"></i>)</span>'},
      field: "InceptionTPAFee",
      sortable: false,
      resizable: false,
      filter: false,
      autoHeight: true,
      minWidth: 140,
      suppressMovable: true,
      width: 140,
      headerClass: "right-align wrap-text text-right-side header-right",
      cellClass: ["justify-content-end"],
      cellRenderer : function(params){
        if(params?.value>0)
        {
          return formatIndianNumber(params?.value?.toString())
        }else {
          return ""
        }
      }
    },
  ];

  return (
    <AgGridTable
      rowData={dashboardSalesWinActiveList}
      className="dashboard-grid"
      columnDefs={columnDefs}
      Style={style}
      getRowHeight={getRowHeight}
      pagination={false}
    />
  );
};

export default LatestWinActive;
