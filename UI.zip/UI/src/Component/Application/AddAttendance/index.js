import React, { useEffect, useState } from "react";
import {
  Card,
  CardBody,
  Row,
  Col,
  Form,
  CardFooter,
  TabContent,
  TabPane,
  Label
} from "reactstrap";
import dayjs from "dayjs";

import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { Btn } from "../../../AbstractElements";
import './style.scss'
import { useFormik } from "formik";
import { useAppDispatch } from "../../../ReduxToolkit/Hooks";
import { AddAttendanceAPI } from "../../../ReduxToolkit/Reducers/AttendanceAction";
import { useNavigate } from "react-router-dom";

const AddAttendance = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState("1");

  const [selectedDate, setSelectedDate] = useState(dayjs());
  const [selectedToDate, setSelectedToDate] = useState(dayjs());

  const toggle = tab => {
    if (activeTab !== tab) setActiveTab(tab);
  };
  const getTabName = (tab)=>{
    if(tab == "1")
    {
      return "Weekly Off"
    }
    else if(tab == "2")
    {
      return "Holiday"
    }
    else if(tab == "3")
    {
      return "Leave"
    }
    else if(tab == "4")
    {
      return "Nothing to Reporting"
    }
  }
  const handleDateChange = date => {
    setSelectedDate(date);
    setFieldValue("fromDate",date);
  };
  const handleToDateChange = date =>{
    setSelectedToDate(date);
    setFieldValue("toDate",date);
  }

  const formatDate = date => {
    if (!date) return "";
    return dayjs(date).format("ddd, DD MMM YYYY");
  };

  const {values,setFieldValue,handleChange,handleSubmit,errors,touched,resetForm,handleBlur,setFieldError,setFieldTouched} = useFormik({
    initialValues: {
      attendance: 1,
      fromDate :'',
      toDate:''
    },
    // validationSchema : validationSchema,
    onSubmit: (values,action) => {
      const attendance = getTabName(activeTab);

      const payload = {
        attendanceId: 0,
        applicationUserId: 0,
        employeeId: 0,
        attendanceFromDate: selectedDate.format('YYYY-MM-DDTHH:mm:ss.SSSZ'),
        attendanceToDate: (activeTab === "2" || activeTab === "3") ? selectedToDate.format('YYYY-MM-DDTHH:mm:ss.SSSZ') : null,
        isWorkedHalfDay: false,
        attendance: attendance,
        workedinBranchNothingToReport: false,
        recordStatus: "Active"
      }
      // alert(JSON.stringify(payload, null, 2));
      dispatch(AddAttendanceAPI(payload));
      action.resetForm();
      navigate(`${process.env.PUBLIC_URL}/attendance`)
    },
  }); 

  // const handleCancel = ()=>{
  //   resetForm();
  // }
  return (
    <div className="page-body">
      <div className="d-flex justify-content-between mt-4 mb-1 align-items-center pt-1 pt-1">
        <div className="ps-0 col-sm-6">
          <h3 className="screen-title">Attendance</h3>
        </div>
      </div>
      <Row>
        <Col className="d-none d-md-block" md="2"></Col>
        <Col md="8">
          <Card>
            <CardBody>
              <Form>
                <div className="d-flex gap-3 tab-mobile flex-wrap"> 
                  <div>
                    <span
                      className={
                        activeTab === "1"
                          ? "active btn btn-outline-primary"
                          : "btn btn-outline-primary"
                      }
                      onClick={() => {
                        toggle("1");
                      }}
                    >
                      Weekly Off
                    </span>
                    </div>
                    <div>
                    <span
                      className={
                        activeTab === "2"
                          ? "active btn btn-outline-primary"
                          : "btn btn-outline-primary"
                      }
                      onClick={() => {
                        toggle("2");
                      }}
                    >
                      Holiday
                    </span>
                    </div>
                    <div>
                    <span
                      className={
                        activeTab === "3"
                          ? "active btn btn-outline-primary"
                          : "btn btn-outline-primary"
                      }
                      onClick={() => {
                        toggle("3");
                      }}
                    >
                      Leave
                    </span>
                    </div>
                    <div>
                    <span
                      className={
                        activeTab === "4"
                          ? "active btn btn-outline-primary"
                          : "btn btn-outline-primary"
                      }
                      onClick={() => {
                        toggle("4");
                      }}
                    >
                    Working from branch and nothing to report
                    </span>
                    </div>
                </div>
                <TabContent activeTab={activeTab}>
                  <TabPane tabId="1">
                    <div className="gap-2 mt-4">
                    <div>
                      <Label style={{ paddingRight: "15px" }}>Date</Label>
                      </div>
                      <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DatePicker
                          className="custom-date"
                          value={selectedDate}
                          // value = {values?.fromDate}
                          onChange={handleDateChange}
                          // onChange = {handleChange}
                          renderInput={props => (
                            <input {...props} variant="standard" fullWidth />
                          )}
                          format="ddd, DD MMM YYYY" // Format for the displayed date
                        />
                      </LocalizationProvider>
                    </div>
                  </TabPane>
                  <TabPane tabId="2">
                    <Row className="mt-4">
                      <Col md="6" className="mb-15">
                      <div>
                        <Label>From Date</Label>
                        </div>
                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                          <DatePicker
                            className="custom-date"
                            value={selectedDate}
                            // value={values?.fromDate}
                            onChange={handleDateChange}
                            renderInput={props => (
                              <input {...props} variant="standard" fullWidth />
                            )}
                            format="ddd, DD MMM YYYY" // Format for the displayed date
                          />
                        </LocalizationProvider>
                      </Col>
                      <Col md="6">
                      <div>
                        <Label>To Date</Label>
                        </div>
                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                          <DatePicker
                            className="custom-date"
                            value={selectedToDate}
                            onChange={handleToDateChange}
                            renderInput={props => (
                              <input {...props} variant="standard" fullWidth />
                            )}
                            format="ddd, DD MMM YYYY" // Format for the displayed date
                          />
                        </LocalizationProvider>
                      </Col>
                    </Row>
                  </TabPane>
                  <TabPane tabId="3">
                  <Row className="mt-4">
                      <Col md="6" className="mb-15">
                      <div>
                        <Label>From Date</Label>
                        </div>
                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                          <DatePicker
                            className="custom-date"
                            value={selectedDate}
                            onChange={handleDateChange}
                            renderInput={props => (
                              <input {...props} variant="standard" fullWidth />
                            )}
                            format="ddd, DD MMM YYYY" // Format for the displayed date
                          />
                        </LocalizationProvider>
                      </Col>
                      <Col md="6">
                      <div>
                        <Label>To Date</Label>
                        </div>
                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                          <DatePicker
                            className="custom-date"
                            value={selectedToDate}
                            onChange={handleToDateChange}
                            renderInput={props => (
                              <input {...props} variant="standard" fullWidth />
                            )}
                            format="ddd, DD MMM YYYY" // Format for the displayed date
                          />
                        </LocalizationProvider>
                      </Col>
                    </Row>
                  </TabPane>
                  <TabPane tabId="4">
                  <Row className="mt-4">
                      <Col md="6">
                      <div>
                        <Label>Date</Label>
                        </div>
                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                          <DatePicker
                            className="custom-date"
                            value={selectedDate}
                            onChange={handleDateChange}
                            renderInput={props => (
                              <input {...props} variant="standard" fullWidth />
                            )}
                            format="ddd, DD MMM YYYY" // Format for the displayed date
                          />
                        </LocalizationProvider>
                      </Col>
                
                    </Row>
                  </TabPane>
                </TabContent>
                <CardFooter className="text-end mt-4">
                  <Btn color="primary" type="submit" onClick={handleSubmit}>
                    Submit
                  </Btn>
                  <Btn
                    className="btn btn-light"
                    type="reset"
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </Btn>
                </CardFooter>
              </Form>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default AddAttendance;
