import { useEffect, useState } from "react";
// import DatePicker, { DateObject } from 'react-multi-date-picker';
import AgGridTable from "../../../CommonElements/AgGridTable";
// import dayjs from 'dayjs';
import dayjs from "dayjs";

import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import "./style.scss";
import { Btn, P } from "../../../AbstractElements";
import { Link } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../../../ReduxToolkit/Hooks";
import { Typeahead } from "react-bootstrap-typeahead";
import { Label } from "reactstrap";
import { getBelongsToEntityList } from "../../../ReduxToolkit/Reducers/CommonSlice";
import { GapRegisterMail, GetGapRegisterReport } from "../../../ReduxToolkit/Reducers/GapReportAction";

export const GapReportGrid = () => {
  const dispatch = useAppDispatch();
  const commonAction = useAppSelector((state)=>state.commonAction);
  const belongsToList = commonAction.belongsToList;

  const gapReportAction = useAppSelector((state)=>state.gapReportAction);
  const gapReport = gapReportAction.gapReport;

  const gridOptions = {
    // Other grid options...
    rowClassRules: {
      // Apply 'even-row' class to even-numbered rows
      "even-row": params => params.node.rowIndex % 2 === 0,
      // Apply 'odd-row' class to odd-numbered rows
      "odd-row": params => params.node.rowIndex % 2 !== 0
    }
  };
  
  const style = { height: "calc(100vh - 244px)", width: "100%" };
  const getRowHeight = () => 30;

  const [selectedMonth, setSelectedMonth] = useState(dayjs());
  const [selectedDate, setSelectedDate] = useState(dayjs().format("MM-DD-YYYY"));
  const [selectedDateForShow, setSelectedDateForShow] = useState(dayjs().format('ddd DD, MMMM YYYY'));
  const [selectedBranch, setSelectedBranch] = useState([]);
  const [selectedDaysinMonth, setSelectedDaysinMonth] = useState(dayjs(selectedDate).daysInMonth());

  const handleDateChange = date => {
    
    const isCurrentMonth = date.isSame(dayjs(), 'month');
    const formattedDate = isCurrentMonth ? date.format('MM-DD-YYYY') : date.endOf('month').format('MM-DD-YYYY');
    const formattedDateForShow = isCurrentMonth ? date.format('ddd DD, MMMM YYYY') : date.endOf('month').format('ddd DD, MMMM YYYY');
    setSelectedDateForShow(formattedDateForShow);
    setSelectedDate(formattedDate);
    setSelectedDaysinMonth(dayjs(date).daysInMonth())
    // console.log("GAPDATE",date,isCurrentMonth,formattedDate);
    setSelectedMonth(date);
  };
  // console.log("selectedDate",selectedDate)
  
  // const maxDate = dayjs().endOf('month').toDate();
  const handleChangeBelongsTo = (value) => {
    // value[0]?.BranchId
    setSelectedBranch(value);
  }

  useEffect(()=>{
    dispatch(GetGapRegisterReport(selectedDate,null));
    dispatch(getBelongsToEntityList('branch',null,null,null,null));
  },[])

  const getCellStyle = (params) => {
    const value = params?.value;
    if (!value || value.length !== 2) {
      return {
        backgroundColor: "transparent",
        width: "28px",
        margin: "2px",
        fontWeight: 500,
        padding: "7px",
        color: "#000",
      };
    }
  
    const code = value.charAt(0);
    switch (code) {
      case "R":
        return {
          backgroundColor: "#c34747",
          width: "28px",
          margin: "2px",
          fontWeight: 500,
          padding: "7px",
          color: "#fff",
        };
      case "G":
        return {
          backgroundColor: "#3eb547",
          width: "28px",
          margin: "2px",
          fontWeight: 500,
          padding: "7px",
          color: "#fff",
        };
      case "O":
      case "H":
      case "L":
      case "N":
        return {
          backgroundColor: "#3eb547",
          width: "28px",
          margin: "2px",
          fontWeight: 500,
          padding: "7px",
          color: "#000",
        };
      default:
        return {
          backgroundColor: "transparent",
          width: "28px",
          margin: "2px",
          fontWeight: 500,
          padding: "7px",
          color: "#000",
        };
    }
  };

  const columnDefs = [
    {
      headerName: "Name",
      field: "FullName",
      minWidth: 340,
      width: 340,
      sortable: false,
      headerClass: "leftAlign",
      cellClass: [""]
    }
  ];
  
  // Add columns for each day of the month
  for (let i = 1; i <= selectedDaysinMonth; i++) {
    columnDefs.push({
      headerName: i.toString(),
      field: `Day${i}`,
      minWidth: 30,
      width: 30,
      sortable: false,
      headerClass: "wrap-text right-align centerItems",
      cellClass: "justify-content-end",
      cellRenderer : function (params) {
        return params?.value?.charAt(1) || "";
      },
      cellStyle : getCellStyle,
      resizable: false,
      suppressMovable: true
    });
  }

  const handleShow = ()=>{
    dispatch(GetGapRegisterReport(selectedDate,selectedBranch[0]?.BranchId || null));
  }

  const handleRemind = () => {
    //selectedDate pass to api
    dispatch(GapRegisterMail(selectedDate));
  }

  return (
    <div className="page-body gap-wrepper">
      <div className="m-block center-block d-flex justify-content-between mt-4 mb-1 align-items-center pt-1 pt-1">
        <div class="ps-0 col-sm-6">
          <h3 className="screen-title" style={{display: 'flex',alignItems: 'center',gap: '15px'}}>Gap Report <span className="small-title-headting">{"As on " + selectedDateForShow}</span></h3>
        </div>
        <div>
          <div className="d-flex gap-3 mt-2">
             <div>
             <Label>Date</Label>
             <div>
             <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                className="custom-date"
                views={["year", "month"]}
                value={selectedMonth}
                onChange={handleDateChange}
                renderInput={props => (
                  <input {...props} variant="standard" fullWidth />
                )}
                format="MMM YYYY"
                maxDate={dayjs()}
              />
            </LocalizationProvider>
             </div>
             </div>
         
            <div>
              {/* <AutoCompleteBranch />{" "} */}
              <Label>Branch</Label>
                <Typeahead
                  id="branchId" 
                  options={belongsToList || []}
                  placeholder="Select Branch..."
                  filterBy={["BranchName"]}
                  labelKey={(belongsToList) => `${belongsToList?.BranchName}`}
                  selected={selectedBranch}
                  onChange={handleChangeBelongsTo}
                  clearButton
                />
            </div>
            <div className="text-end mt-4">
              {/* <Link> */}
                <Btn color="primary" block className="w-100" onClick={handleShow}>
                  Show
                </Btn>
                {/* to={`${process.env.PUBLIC_URL}/add-opportunity`} */}
              {/* </Link> */}
            </div>
            <div className="text-end mt-4">
              <Btn color="primary" onClick={handleRemind}>
                  Remind
              </Btn>
            </div>
          </div>
        </div>
      </div>

      {/* <p>AG Grid Table Test</p> */}
      <AgGridTable className="gap-report center-block"
        rowData={gapReport}
        columnDefs={columnDefs}
        Style={style}
        getRowHeight={getRowHeight}
        // pagination={true}
        // paginationPageSize={15}
      />
      <div className="p-2">
        <P style={{fontWeight:600,marginBottom:'0',color:'#2e35ff'}}>Note:</P>
        <div className="d-flex gap-2 mob-block" style={{color:'#000'}}>
        <P><span style={{color:'#2e35ff',fontWeight:600}}>W</span> - Working Day,</P>
        <P><span style={{color:'#2e35ff',fontWeight:600}}>O</span> - Weekly Off,</P>
        <P><span style={{color:'#2e35ff',fontWeight:600}}>H</span> - Holiday,</P>
        <P><span style={{color:'#2e35ff',fontWeight:600}}>L</span> - Leave,</P>
        <P><span style={{color:'#2e35ff',fontWeight:600}}>N</span> - Nothing to report</P>
        
        </div>
      
      </div>
    </div>
  );
};
