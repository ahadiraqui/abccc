import { useEffect, useState } from "react";
// import DatePicker, { DateObject } from 'react-multi-date-picker';
import AgGridTable from "../../../CommonElements/AgGridTable";
// import dayjs from 'dayjs';
import dayjs from "dayjs";

import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import "./style.scss";
import { Btn } from "../../../AbstractElements";
import { Link, useNavigate } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../../../ReduxToolkit/Hooks";
import { getOpportunityList, setOpportunityDataById, setOpportunityEditFlag, setOpportunityFlag, setOpportunityId } from "../../../ReduxToolkit/Reducers/OpportunityAction";
import { setOpportunityTab } from "../../../ReduxToolkit/Reducers/MeetingAction";
import { Col, Label, Row } from "reactstrap";

export const WinGrid = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const opportunityAction = useAppSelector((state)=>state.opportunityAction);
  const opportunityList = opportunityAction.opportunityList;

  const gridOptions = {
    // Other grid options...
    rowClassRules: {
      // Apply 'even-row' class to even-numbered rows
      "even-row": params => params.node.rowIndex % 2 === 0,
      // Apply 'odd-row' class to odd-numbered rows
      "odd-row": params => params.node.rowIndex % 2 !== 0
    }
  };
  const CustomHeaderRenderer = ({ value }) => {
    return <div style={{ whiteSpace: "pre-wrap" }}>{value}</div>;
  };

  const CustomCellRenderer = ({ value }) => {
    return <div style={{ whiteSpace: "pre-wrap" }}>{value}</div>;
  };

  const formatIndianNumber = (number) => {
    if (!number.trim()) return "";

    // Otherwise, format the number with Indian style comma separation
    return parseFloat(number.replace(/,/g, "")).toLocaleString("en-IN");
  };

  const columnDefs = [
    // {
    //   headerName: "Sr.No.",
    //   field: "srNo",
    //   sortable: true,
    //   filter: false,
    //   minWidth: 80,
    //   width: 80,
    //   headerClass: "right-align",
    //   cellClass: ["justify-content-end"]
    // },
    {
      headerName: "Edit",
      field: "Edit",
      sortable: false,
      filter: false,
      minWidth: 66,
      width: 66,
      cellRenderer: params => {
        return (
          <>
            <i
              className="icon-pencil-alt"
              style={{ color: "#5b60ef", fontSize: "15px", cursor: "pointer" }}
              onClick={()=>{
                dispatch(setOpportunityDataById([]));
                dispatch(setOpportunityId(params?.data?.OpportunityGUID));
                dispatch(setOpportunityEditFlag(true));
                dispatch(setOpportunityTab("3"));
                dispatch(setOpportunityFlag(1));
                navigate(`${process.env.PUBLIC_URL}/add-new-opportunity`);
              }}
            ></i>
          </>
        );
      }
    },
    {
      headerName: "Date",
      field: "CurrentStageDate",
      minWidth: 100,
      width: 100,
      headerClass: "right-align wrap-text",
      cellClass: ["justify-content-end"],
      cellRenderer: function(params) {
        const dates = params.value?.split("T")
        return dates[0] || "";
      },
      cellStyle: function(params) {
        return { 'whiteSpace': 'normal' }; 
      },
      autoHeight: true,
    },
    { headerName: "Stage", field: "CurrentStage", minWidth: 90, width: 90,sortable: true, filter: true, filterParams: { buttons: ["reset"]},
        cellRenderer : function(params) {
            return params?.value === "Close" && params?.data?.OpportunityStatus === "Win" ? "Win" : ""
        }
     },
    {
      headerName: "Corporate Name",
      field: "CorporateName",
      minWidth: 120,
      width: 120,
      headerClass: "wrap-text",
      cellStyle: function(params) {
        // Define your custom cell style logic here
        return { 'whiteSpace': 'normal' }; // Example style with text-wrap
      },
      autoHeight: true,
      sortable: true, filter: true, filterParams: { buttons: ["reset"]},
    },
    {
      headerName: "Broker Name",
      field: "BrokerName",
      minWidth: 130,
      width: 130,
      headerClass: "wrap-text",
      autoHeight: true,
      cellStyle: function(params) {
        // Define your custom cell style logic here
        return { 'whiteSpace': 'normal' }; // Example style with text-wrap
      },
      sortable: true, filter: true, filterParams: { buttons: ["reset"]},
    },
    { headerName: "IC Name", field: "InsuranceCompanyName", minWidth: 140, width: 140,   cellStyle: function(params) {
        // Define your custom cell style logic here
        return { 'whiteSpace': 'normal' }; // Example style with text-wrap
      }, autoHeight: true,sortable: true, filter: true, filterParams: { buttons: ["reset"]}, },
    {
      headerName: "Current TPA",
      field: "TPAName",
      minWidth: 150,
      width: 150,
      cellStyle: function(params) {
        // Define your custom cell style logic here
        return { 'whiteSpace': 'normal' }; // Example style with text-wrap
      },
      sortable: true, filter: true, filterParams: { buttons: ["reset"]},
    },
    {
      headerName: "Premium Amount",
      headerComponentParams: { template: '<span class="outer-span"><span class="amt-col">Premium Amount</span><span class="icon-span">(<i class="fa fa-rupee"></i>)</span>'},
      field: "Premium",
      minWidth: 130,
      width: 130,
      headerClass: "right-align wrap-text text-align-right",
      cellClass: ["justify-content-end"],
      autoHeight: true,
      filter: 'agNumberColumnFilter',
      filterParams: {
        buttons: ["reset"]
      },

      cellStyle: function(params) {
        // Define your custom cell style logic here
        return { 'whiteSpace': 'normal' }; // Example style with text-wrap
      },
      cellRenderer : function(params) {
        return formatIndianNumber(params?.value?.toString())
      }
    },
    {
      headerName: "Premium Amount (In Words)",
      field: "PremiumAmountinWords",
      minWidth: 160,
      width: 160,
      headerClass: "right-align wrap-text text-align-right",
      // cellClass: ["justify-content-end"],
      autoHeight: true,
      sortable: true, filter: true, filterParams: { buttons: ["reset"]},
      cellStyle: function(params) {
        // Define your custom cell style logic here
        return { 'whiteSpace': 'normal' }; // Example style with text-wrap
      },
    },
    {
      headerName: "TPA Fee %",
      field: "TPAFeePercentage",
      minWidth: 90,
      width: 90,
      headerClass: "right-align text-align-right wrap-text",
      cellClass: ["justify-content-end"],
      cellStyle: function(params) {
        return { 'whiteSpace': 'normal' }; 
      },
      autoHeight: true,
      filter: 'agNumberColumnFilter',
      filterParams: {
        buttons: ["reset"]
      },

    },
    {
      headerName: "TPA Fee Amount",
      headerComponentParams: { template: '<span class="outer-span"><span class="amt-col">TPA Fee Amount</span><span class="icon-span">(<i class="fa fa-rupee"></i>)</span>'},
      field: "TPAFee",
      minWidth: 130,
      width: 130,
      headerClass: "right-align wrap-text text-align-right",
      cellClass: ["justify-content-end"],
      autoHeight: true,
      cellRenderer : function(params) {
        return formatIndianNumber(params?.value?.toString())
      },
      cellStyle: function(params) {
        return { 'whiteSpace': 'normal' }; 
      },
      autoHeight: true,
      filter: 'agNumberColumnFilter',
      filterParams: {
        buttons: ["reset"]
      },

    },
    {
      headerName: "TPA Fee Amount (In Words)",
      field: "TPAFeeAmountinWords",
      minWidth: 180,
      width: 180,
      headerClass: "right-align wrap-text text-align-right",
      // cellClass: ["justify-content-end"],
      cellStyle: function(params) {
        return { 'whiteSpace': 'normal' }; 
      },
      autoHeight: true,
      sortable: true, filter: true, filterParams: { buttons: ["reset"]},
    },
    {
      headerName: "Confidence Level",
      field: "CurrentConfidenceLevel",
      minWidth: 130,
      width: 130,
      headerClass: "right-align wrap-text",
      autoHeight: true,
      sortable: true, filter: true, filterParams: { buttons: ["reset"]},
    },
    {
      headerName: "Influencer Required",
      field: "IfInfluencerRequired",
      minWidth: 100,
      width: 100,
      headerClass: "right-align wrap-text",
      cellRenderer: function(params) {
        return params.value ? "Yes" : "No";
      }
    },
    {
      headerName: "Presentation Required",
      field: "PresentationRequired",
      minWidth: 120,
      width: 120,
      headerClass: "right-align wrap-text",
      cellRenderer: function(params) {
        return params.value ? "Yes" : "No";
      }
    },
    {
      headerName: "Presentation Date",
      field: "PresentationDate",
      minWidth: 120,
      width: 120,
      headerClass: "right-align wrap-text",
      cellClass: ["justify-content-end"],
      cellRenderer: function(params) {
        const dates = params.value?.split("T")
        return dates[0] || "";
      },
      cellStyle: function(params) {
        return { 'whiteSpace': 'normal' }; 
      },
      autoHeight: true,
    },
  ];

  const style = { height: "calc(100vh - 140px)", width: "100%" };
  const getRowHeight = () => 30;

  const [selectedDate, setSelectedDate] = useState();
  const [selectedDate1, setSelectedDate1] = useState();

  const handleDateChange = date => {
    setSelectedDate(date);
    dispatch(getOpportunityList(date?.format("MM-DD-YYYY"),selectedDate1?.format("MM-DD-YYYY") || null, "Win"))
  };

  const handleDateChange1 = date => {
    setSelectedDate1(date);
    dispatch(getOpportunityList(selectedDate?.format("MM-DD-YYYY") || null,date?.format("MM-DD-YYYY"), "Win"))
  };

  useEffect(()=>{
    dispatch(getOpportunityList(null,null, "Win"))
  },[]);

//   console.log("opportunityList",opportunityList);

  const formatDate = date => {
    if (!date) return "";
    return dayjs(date).format("ddd, DD MMM YYYY");
  };

  // const [value, setValue] = useState([new DateObject()]);
  // const onChange = ()=>{
  //     console.log("DatePicker",new DateObject())
  // }
  return (
    <div className="page-body">
      <div className="m-block center-block-meeting d-flex justify-content-between mt-4 mb-1 align-items-center pt-1 pt-1">
        <div class="ps-0 col-sm-6">
          <h3 className="screen-title">Win</h3>
        </div>
        {/* <div>
          <div className="d-flex gap-3 mt-2">
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                className="custom-date"
                value={selectedDate}
                onChange={handleDateChange}
                renderInput={props => (
                  <input {...props} variant="standard" fullWidth />
                )}
                format="ddd, DD MMM YYYY" // Format for the displayed date
              />
            </LocalizationProvider>
          </div>
        </div> */}
        <div>
          <Row className="align-items-center mb-2">
            <Col md="12">
              <Row>
                <Col>
                  <Label>From Date</Label>
                  <div>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <DatePicker
                        className="custom-date"
                        value={selectedDate}
                        onChange={handleDateChange}
                        renderInput={props => (
                          <input {...props} variant="standard" fullWidth />
                        )}
                        format="ddd, DD MMM YYYY" // Format for the displayed date
                      />
                    </LocalizationProvider>
                  </div>
                </Col>
                <Col>
                  <Label>To Date</Label>
                  <div>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <DatePicker
                        className="custom-date"
                        value={selectedDate1}
                        onChange={handleDateChange1}
                        renderInput={props => (
                          <input {...props} variant="standard" fullWidth />
                        )}
                        format="ddd, DD MMM YYYY" // Format for the displayed date
                      />
                    </LocalizationProvider>
                  </div>
                </Col>
              </Row>
            </Col>
          </Row>
        </div>
      </div>

      {/* <p>AG Grid Table Test</p> */}
      <AgGridTable
        rowData={opportunityList || []} className="center-block-meeting-grid"
        columnDefs={columnDefs}
        Style={style}
        getRowHeight={getRowHeight}
        pagination={true}
        paginationPageSize={15}
      />
    </div>
  );
};
