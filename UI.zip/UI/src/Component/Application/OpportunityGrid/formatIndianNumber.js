export const formatIndianNumber = (number) => {
    if (!number.trim()) return "";

    return parseFloat(number.replace(/,/g, "")).toLocaleString("en-IN");
};

export const numberToWords = (number) => {
    const ones = [
      "",
      "One",
      "Two",
      "Three",
      "Four",
      "Five",
      "Six",
      "Seven",
      "Eight",
      "Nine"
    ];
    const teens = [
      "Ten",
      "Eleven",
      "Twelve",
      "Thirteen",
      "Fourteen",
      "Fifteen",
      "Sixteen",
      "Seventeen",
      "Eighteen",
      "Nineteen"
    ];
    const tens = [
      "",
      "",
      "Twenty",
      "Thirty",
      "Forty",
      "Fifty",
      "Sixty",
      "Seventy",
      "Eighty",
      "Ninety"
    ];

    const num = parseFloat(number.replace(/,/g, ""));
    let numStr = num.toString();

    const getHundreds = (num) => {
      let result = "";
      if (num > 99) {
        result += ones[Math.floor(num / 100)] + " Hundred ";
        num %= 100;
      }
      if (num > 19) {
        result += tens[Math.floor(num / 10)] + " ";
        num %= 10;
      }
      if (num > 9 && num < 20) {
        result += teens[num - 10] + " ";
        num = 0;
      }
      if (num > 0) {
        result += ones[num] + " ";
      }
      return result;
    };

    const units = ["", "Thousand", "Lakh", "Crore", "Arab", "Kharab","Padma", "Shankh", "Maha-shankh"];
    let words = [];

    let chunkCount = 0;
    while (numStr.length > 0) {
      let chunkSize = chunkCount === 0 ? 3 : 2;
      let chunk = numStr.slice(-chunkSize);
      numStr = numStr.slice(0, -chunkSize);
      if (parseInt(chunk, 10) > 0) {
        words.unshift(getHundreds(parseInt(chunk, 10)) + units[chunkCount]);
      }
      chunkCount++;
    }

    return words.join(" ").trim();
  };