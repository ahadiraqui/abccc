import { organizationList } from "../../../../../Data/Application/Contacts/Contacts";
import { TabPane } from "reactstrap";
import { H3, Image, LI, P, UL } from "../../../../../AbstractElements";
import { dynamicImage } from "../../../../../Service";
import { Link } from "react-router-dom";
import {
  EmailAddress,
  Gender,
  General,
  Href,
  Personal,
  Print
} from "../../../../../utils/Constant";

const TabOrganization = () => {
  return (
    <>
      {organizationList.map((item, i) => (
        <TabPane tabId={item.activeTab} key={i}>
          <div className="profile-mail">
            {/* <div className="d-flex align-items-center">
              <Image
                className="img-100 img-fluid m-r-20 rounded-circle update_img_5"
                src={dynamicImage(`${item.image}`)}
                alt="images"
              />
              <div className="flex-grow-1 mt-0">
                <H3>
                  <span className="first_name_5">{item.name}</span>
                </H3>
                <P className="email_add_5">{item.email}</P>
              </div>
            </div> */}
            <div className="email-general">
              <H3>Official</H3>
              <div className="row">
                <div className="col-md-4">
                  <P>Department: </P>
                </div>
                <div className="col-md-8">
                  <span className="font-primary email_add_5">Management</span>
                </div>
              </div>
              <div className="row">
                <div className="col-md-4">
                  <P>Designation: </P>
                </div>
                <div className="col-md-8">
                  <span className="font-primary email_add_5">Officer</span>
                </div>
              </div>
              <div className="row">
                <div className="col-md-4">
                  <P>State: </P>
                </div>
                <div className="col-md-8">
                  <span className="font-primary email_add_5">Maharastra</span>
                </div>
              </div>
              <div className="row">
                <div className="col-md-4">
                  <P>City: </P>
                </div>
                <div className="col-md-8">
                  <span className="font-primary email_add_5">Pune</span>
                </div>
              </div>

              <div className="gender">
                <H3>{Personal}</H3>
                <div className="row">
                <div className="col-md-4">
              <p>{Gender}</p>
                </div>
                <div className="col-md-8">
                <span className="font-primary email_add_5">
                    {item.gender}
                  </span>
                </div>
              </div>
               
                <div className="row">
                <div className="col-md-4">
                  <P> Email Address 1:</P>
                </div>
                <div className="col-md-8">
                <span className="font-primary email_add_5">{item.email}</span>
                </div>
              </div>
              <div className="row">
                <div className="col-md-4">
                <P> Email Address 1:</P>
                </div>
                <div className="col-md-8">
                <span className="font-primary email_add_5">{item.email}</span>
                </div>
              </div>
              <div className="row">
                <div className="col-md-4">
                 <P>  Mobile Number 1:</P>
                </div>
                <div className="col-md-8">
                  <span className="font-primary email_add_5">8585858585</span>
                </div>
              </div>
              <div className="row">
                <div className="col-md-4">
                <P>  Mobile Number 1:</P>
                </div>
                <div className="col-md-8">
                <span className="font-primary email_add_5">8585858585</span>
                </div>
              </div>
              <div className="mt-3">
                Brief Description of Contact:
              </div>
              <p style={{lineHeight:'20px'}}>
              Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups
              </p>
           
              
              </div>
            </div>
          </div>
        </TabPane>
      ))}
    </>
  );
};

export default TabOrganization;
