import { useEffect, useState } from "react";

import { Btn } from "../../../../AbstractElements";
import {
  Card,
  CardBody,
  CardFooter,
  Col,
  Form,
  FormGroup,
  Input,
  Label,
  Row
} from "reactstrap";
import AutocompleteSelect from "../../../../CommonElements/AutoCompleteSelectBox";
import AutoCompleteCity from "../../../../CommonElements/AutoCompleteSelectBox/AutoCompleteCity";
import AutoCompleteBelongs from "../../../../CommonElements/AutoCompleteSelectBox/AutoCompleteBelongs";
import { useFormik } from "formik";
import { useAppDispatch, useAppSelector } from "../../../../ReduxToolkit/Hooks";
import { Autocomplete, TextField } from "@mui/material";
import { getBelongsToEntityList, getCitiesList, getStateList, setBelongsToFlag, setCityFlag, setStateFlag } from "../../../../ReduxToolkit/Reducers/CommonSlice";
import { Typeahead } from "react-bootstrap-typeahead";
import { AddUpdateContact, getContactData, setContactDataByID } from "../../../../ReduxToolkit/Reducers/ContactSlice";
import { useNavigate } from "react-router-dom";
import * as Yup from "yup";

export const ContactAdd = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const state:any = useAppSelector((state)=>state.contact);
  const editFlag = state.editFlag;
  const editContactID = state.editContactID;
  const ContactDataByID = state.ContactDataByID;
  const contactFlag = state.contactFlag;

  const commonAction = useAppSelector((state:any)=>state.commonAction);
  const stateList = commonAction.stateList;
  const citiesList = commonAction.citiesList;
  const belongsToList =commonAction.belongsToList;
  const stateFlag = commonAction.stateFlag;
  const cityFlag = commonAction.cityFlag;
  const belongsToFlag = commonAction.belongsToFlag;

  const [selected,setSelected] = useState<string[]>([]);
  const [selectedCity,setSelectedCity] = useState<string[]>([]);
  const [selectedBelongsTo,setSelectedBelongsTo] = useState<string[]>([]);

  // console.log("belongsToFlag",belongsToFlag,stateFlag,cityFlag);

  useEffect(()=>{
    if(contactFlag === 3)
    {
      navigate(`${process.env.PUBLIC_URL}/contacts`)
    }
  },[contactFlag])
  const validationSchema = Yup.object({
    firstName :Yup.string().required("Please enter First Name"),
    primaryEmail : Yup.string().matches(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, 'Invalid email format'),
    alternateEmail : Yup.string().matches(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, 'Invalid email format'),
    primaryMobile: Yup.string().matches(/^[6-9]+/, 'Primary Mobile Number should start with 6,7,8 or 9').matches(/^[0-9]{10}$/,'Primary Mobile Number must have 10 characters'),
    alternateMobile:Yup.string().matches(/^[6-9]+/, 'Alternate Mobile Number should start with 6,7,8 or 9').matches(/^[0-9]{10}$/,'Alternate Mobile Number must have 10 characters'),
  })
  const {values,setFieldValue,handleChange,handleSubmit,errors,touched,resetForm,handleBlur} = useFormik({
    initialValues: {
      prefix: '',
      firstName :'',
      middleName:'',
      lastName: '',
      DOB:'',
      designation:'',
      location:'',
      stateId : 0,
      cityId:0,
      contactType :'',
      contactBelongsTo_nameofcompanyId : 0,
      department:'',
      primaryMobile:'',
      alternateMobile:'',
      primaryEmail:'',
      alternateEmail: '',
      notes:''
    },
    validationSchema : validationSchema,
    // validateOnChange
    onSubmit: (values,action) => {
      const payload = {
        contactGUID : editContactID || null,
        prefix: values?.prefix,
        firstName :values?.firstName,
        middleName: values?.middleName,
        lastName: values?.lastName,
        dob: values?.DOB || null,
        designation: values?.designation,
        location: values?.location,
        stateId : values?.stateId > 0 ? values?.stateId : null,
        cityId: values?.cityId >0 ? values?.cityId : null,
        contactType : values?.contactType,
        contactBelongsTo_nameofcompanyId : values?.contactBelongsTo_nameofcompanyId,
        department: values?.department,
        primaryMobile: values?.primaryMobile,
        alternateMobile: values?.alternateMobile,
        primaryEmail: values?.primaryEmail,
        alternateEmail: values?.alternateEmail,
        notes: values?.notes
      }
      dispatch(AddUpdateContact(payload));
      action.resetForm();
      setSelected([]);
      setSelectedCity([]);
      setSelectedBelongsTo([]);
      // navigate(`${process.env.PUBLIC_URL}/contacts`)
    },
  });

  const handleCancel = ()=>{
    resetForm();
  }

  useEffect(()=>{
    setSelected([]);
    setSelectedCity([]);
    setSelectedBelongsTo([]);
    setFieldValue("contactType","");
    if(editContactID)
    {
      dispatch(getContactData(editContactID));
    }
    dispatch(getStateList());
  },[])

  const handleChangeState = (value:any) => {
    setFieldValue("stateId",value[0]?.StateId || 0);
    setSelected(value);
    setSelectedCity([]);
    setFieldValue("cityId",0);
    dispatch(getCitiesList(value[0]?.StateId));
  };

  const handleChangeCity = (value:any) => {
    setFieldValue("cityId",value[0]?.cityId || 0);
    setSelectedCity(value);
  }
  const handleChangeBelongsTo = (value:any)=>{
    // console.log("belongsTO",value[0]);
    if(value?.length > 0){
      values?.contactType == "Aggregator" ?
        setFieldValue("contactBelongsTo_nameofcompanyId",value[0]?.AggregatorId || 0) :
      values?.contactType == "Broker" ?
        setFieldValue("contactBelongsTo_nameofcompanyId",value[0]?.BrokerId || 0) :
      values?.contactType == "Corporate" ? 
        setFieldValue("contactBelongsTo_nameofcompanyId",value[0]?.CorporateId || 0) :
      values?.contactType == "Agent" ? 
        setFieldValue("contactBelongsTo_nameofcompanyId",value[0]?.AgentId || 0) :
      values?.contactType == "Insurance Company" && setFieldValue("contactBelongsTo_nameofcompanyId",value[0]?.InsuranceCompanyId || 0);
      setSelectedBelongsTo(value);
    }
    else{
      setFieldValue("contactBelongsTo_nameofcompanyId",null)
      setSelectedBelongsTo([]);
    }
  }

  useEffect(()=>{
    if(ContactDataByID)
    {
      setFieldValue("prefix",ContactDataByID?.prefix);
      setFieldValue("firstName",ContactDataByID?.firstName);
      setFieldValue("middleName",ContactDataByID?.middleName);
      setFieldValue("lastName",ContactDataByID?.lastName);
      setFieldValue("DOB",ContactDataByID?.birthDate);
      setFieldValue("designation",ContactDataByID?.designation);
      // location:'',
      setFieldValue("stateId",ContactDataByID?.stateId || 0);
      dispatch(getCitiesList(ContactDataByID?.stateId || 0))

      setFieldValue("cityId",ContactDataByID?.cityId || 0);
      setFieldValue("contactType",ContactDataByID?.contactType);
      dispatch(getBelongsToEntityList(ContactDataByID?.contactType,ContactDataByID?.cityId || 0,null,null,null))

      // setFieldValue("contactBelongsTo_nameofcompanyId
      setFieldValue("department",ContactDataByID?.department);
      setFieldValue("primaryMobile",ContactDataByID?.primaryContactNumber || "");
      setFieldValue("alternateMobile",ContactDataByID?.alternateContactNumber || "")
      setFieldValue("primaryEmail",ContactDataByID?.primaryEmail || "")
      setFieldValue("alternateEmail",ContactDataByID?.alternateEmail || "")
      setFieldValue("notes",ContactDataByID?.notes)

      // ContactDataByID?.contactType ==
      ContactDataByID?.contactType == "Aggregator" ?
      setFieldValue("contactBelongsTo_nameofcompanyId",ContactDataByID?.AggregatorId || 0) :
      ContactDataByID?.contactType == "Broker" ?
      setFieldValue("contactBelongsTo_nameofcompanyId",ContactDataByID?.BrokerId || 0) :
      ContactDataByID?.contactType == "Corporate" ? 
      setFieldValue("contactBelongsTo_nameofcompanyId",ContactDataByID?.CorporateId || 0) :
      ContactDataByID?.contactType == "Agent" ? 
      setFieldValue("contactBelongsTo_nameofcompanyId",ContactDataByID?.AgentId || 0) :
      ContactDataByID?.contactType == "Insurance Company" && setFieldValue("contactBelongsTo_nameofcompanyId",ContactDataByID?.InsuranceCompanyId || 0);

    //   if (belongsToList) {
    //     if (ContactDataByID?.contactType == "Aggregator") {
    //         const list = belongsToList?.find((item:any) => item.AggregatorId == ContactDataByID?.AggregatorId);
    //         const newArray = [ ...selectedBelongsTo, list ];
    //         setSelectedBelongsTo(newArray);
    //     } else if (ContactDataByID?.contactType == "Broker") {
    //         const list = belongsToList?.find((item:any) => item.BrokerId == ContactDataByID?.BrokerId);
    //         const newArray = [ ...selectedBelongsTo, list ];
    //         setSelectedBelongsTo(newArray);
    //     } else if (ContactDataByID?.contactType == "Corporate") {
    //         const list = belongsToList?.find((item:any) => item.CorporateId == ContactDataByID?.CorporateId);
    //         const newArray = [ ...selectedBelongsTo, list ];
    //         setSelectedBelongsTo(newArray);
    //     } else if (ContactDataByID?.contactType == "Agent") {
    //         const list = belongsToList?.find((item:any) => item.AgentId == ContactDataByID?.AgentId);
    //         const newArray = [ ...selectedBelongsTo, list ];
    //         setSelectedBelongsTo(newArray);
    //     } else if (ContactDataByID?.contactType == "Insurance Company") {
    //         const list = belongsToList?.find((item:any) => item.InsuranceCompanyId == ContactDataByID?.InsuranceCompanyId);
    //         const newArray = [ ...selectedBelongsTo, list ];
    //         setSelectedBelongsTo(newArray);
    //     }
    //  }else{
    //    setSelectedBelongsTo([])
    //  }
    
      // if(belongsToList)
      // {
      //   (ContactDataByID?.contactType == "Aggregator") ?
      //   (
      //     // belongsToList && setSelectedBelongsTo([belongsToList?.find((item:any)=>item.AggregatorId == ContactDataByID?.AggregatorId)])
      //     const list = belongsToList?.find((item:any) => item.AggregatorId == ContactDataByID?.AggregatorId);
      //     const newArray = [ ...selected, list ];
      //     setSelected(newArray);
      //   ) :
      //   (ContactDataByID?.contactType == "Broker") ?
      //   (belongsToList && setSelectedBelongsTo([belongsToList?.find((item:any)=>item.BrokerId == ContactDataByID?.BrokerId)])) :
      //   ContactDataByID?.contactType == "Corporate" ? 
      //   belongsToList && setSelectedBelongsTo([belongsToList?.find((item:any)=>item.CorporateId == ContactDataByID?.CorporateId)]) :
      //   ContactDataByID?.contactType == "Agent" ? 
      //   belongsToList && setSelectedBelongsTo([belongsToList?.find((item:any)=>item.AgentId == ContactDataByID?.AgentId)]) :
      //   ContactDataByID?.contactType == "Insurance Company" && 
      //   belongsToList && setSelectedBelongsTo([belongsToList?.find((item:any)=>item.InsuranceCompanyId == ContactDataByID?.InsuranceCompanyId)]);
      // }
      // debugger
      // stateList && setSelected(stateList?.find((item:any) => item.StateId === ContactDataByID?.stateId))
      // if(stateList)
      // {
      //   const selectedState = stateList?.find((item:any) => item.StateId === ContactDataByID?.stateId)
      //   const newArray = [ ...selected, selectedState ];
      //   setSelected(newArray);
      // }
      // if(citiesList)
      // {
      //   const selectedCityFind = citiesList?.find((item:any) => item.cityId === ContactDataByID?.cityId)
      //   const newArray = [ ...selectedCity, selectedCityFind ];
      //   setSelectedCity(newArray);
      // }
      // citiesList && setSelectedCity([citiesList?.find((item:any)=>item.cityId == ContactDataByID?.cityId)])
    }
  },[ContactDataByID]);

  useEffect(()=>{
    if(ContactDataByID && stateList && stateFlag == 1)
    {
      dispatch(setStateFlag(2));
      const selectedState = stateList?.find((item:any) => item.StateId === ContactDataByID?.stateId) || null
      if(selectedState)
      {const newArray = [ ...selected, selectedState ];
      setSelected(newArray);}
    }
  },[ContactDataByID,stateList])
  // useEffect(()=>{
  //   if(ContactDataByID && citiesList && cityFlag == 1)
  //   {
  //     dispatch(setCityFlag(2));
  //     const selectedCityFind = citiesList?.find((item:any) => item.cityId === ContactDataByID?.cityId) || null;
  //     if(selectedCityFind)
  //     {const newArray = [ ...selectedCity, selectedCityFind ];
  //     setSelectedCity(newArray);}
  //   }
  // },[ContactDataByID,citiesList])
  useEffect(()=>{
    if(citiesList && citiesList?.length>0 && cityFlag == 1 && ContactDataByID && editFlag == true)
    {
      const selectedCityFind = citiesList?.find((item:any) => item.cityId === ContactDataByID?.cityId) || null;
      if(selectedCityFind)
      {const newArray = [ ...selectedCity, selectedCityFind ];
      setSelectedCity(newArray);}
    }
  },[citiesList])
  useEffect(()=>{
    if(ContactDataByID && belongsToList && belongsToFlag == 1 && belongsToList?.length>0)
    {
      dispatch(setBelongsToFlag(2));
      console.log("belongsToList",belongsToList);
      if (ContactDataByID?.contactType == "Aggregator") {
        const list = belongsToList?.find((item:any) => item.AggregatorId == ContactDataByID?.aggregatorId) || null;
        if(list)
        {const newArray = [ ...selectedBelongsTo, list ];
        setSelectedBelongsTo(newArray);}
      } else if (ContactDataByID?.contactType == "Broker") {
          const list = belongsToList?.find((item:any) => item.BrokerId == ContactDataByID?.brokerId) || null;
          if(list)
        {const newArray = [ ...selectedBelongsTo, list ];
        setSelectedBelongsTo(newArray);}
      } else if (ContactDataByID?.contactType == "Corporate") {
          const list = belongsToList?.find((item:any) => item.CorporateId == ContactDataByID?.corporateId) || null;
          if(list)
        {const newArray = [ ...selectedBelongsTo, list ];
        setSelectedBelongsTo(newArray);}
      } else if (ContactDataByID?.contactType == "Agent") {
          const list = belongsToList?.find((item:any) => item.AgentId == ContactDataByID?.agentId) || null;
          if(list)
        {const newArray = [ ...selectedBelongsTo, list ];
        setSelectedBelongsTo(newArray);}
      } else if (ContactDataByID?.contactType == "Insurance Company") {
          const list = belongsToList?.find((item:any) => item.InsuranceCompanyId == ContactDataByID?.insuranceCompanyId) || null;
          if(list)
        {const newArray = [ ...selectedBelongsTo, list ];
        setSelectedBelongsTo(newArray);}
      }
    }
  },[belongsToList])

  console.log("SELECTEDDATA",selected,selectedCity,selectedBelongsTo);
  return (
    <div className="page-body">
      <div className="d-flex justify-content-between mt-4 mb-1 align-items-center pt-1 pt-1">
        <div className="ps-0 col-sm-6">
          <h3 className="screen-title">{editFlag ? "Edit Contact" : "Add Contact"}</h3>
        </div>
      </div>
      
      <Row>
        <Col lg="3" className="d-none d-lg-block"></Col>
        <Col lg="6">
          <Form onSubmit = {handleSubmit}>
            <Card>
              {/* <CardHeaderCommon  tagClass={"card-title mb-0"}>Add</div> */}
              <CardBody>
                <Row>
                  <Col md="12">
                    <FormGroup>
                      <Label>Prefix</Label>
                      <Input 
                        type="select" 
                        className="form-select" 
                        id="prefix" 
                        name="prefix" 
                        value={values?.prefix}
                        onChange = {handleChange}
                      >
                        <option>{"--Select--"}</option>
                        <option>{"Mr."}</option>
                        <option>{"Mrs."}</option>
                        <option>{"Miss."}</option>
                        <option>{"Dr."}</option>
                      </Input>
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    <FormGroup>
                      <Label>First Name</Label>
                      <Input 
                        type="text" 
                        // placeholder="Name" 
                        id="firstName" 
                        name="firstName" 
                        value={values?.firstName}
                        onBlur={handleBlur}
                        onChange = {handleChange}
                      />
                      {touched.firstName && errors.firstName ? (<p className="form-error">{errors.firstName}</p>) : null}
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    <FormGroup>
                      <Label>Middle Name</Label>
                      <Input 
                        type="text" 
                        // placeholder="Name"
                        id="middleName" 
                        name="middleName" 
                        value={values?.middleName}
                        onChange = {handleChange}
                       />
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    <FormGroup>
                      <Label>Last Name</Label>
                      <Input 
                        type="text" 
                        // placeholder="Name"
                        id="lastName" 
                        name="lastName" 
                        value={values?.lastName}
                        onChange = {handleChange}
                       />
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    <FormGroup>
                      <Label>Date of birth</Label>
                      <Input 
                        type="date" 
                        // placeholder="date"
                        id="DOB" 
                        name="DOB" 
                        value={values?.DOB}
                        onChange = {handleChange}
                        max={new Date().toISOString().split('T')[0]}
                       />
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    <FormGroup>
                      <Label>Designation</Label>
                      <Input 
                        type="text" 
                        // placeholder="Designation"
                        id="designation" 
                        name="designation" 
                        value={values?.designation}
                        onChange = {handleChange}
                      />
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    <FormGroup>
                      <Label>Location</Label>
                      <Input 
                        type="text" 
                        // placeholder="Location"
                        id="location" 
                        name="location" 
                        value={values?.location}
                        onChange = {handleChange}
                      />
                    </FormGroup>
                  </Col>

                  <Col md="12">
                    <Label>State</Label>
                    <Typeahead
                      id="stateId" 
                      options={stateList || []}
                      placeholder="Select state..."
                      filterBy={["Name"]}
                      labelKey={(stateList:any) => stateList ? `${stateList?.Name}` : ""}
                      selected={selected || null}
                      onChange={handleChangeState}
                      clearButton
                    />
                  </Col>
                  <Col md="12">
                    {/* <AutoCompleteCity /> */}
                    <Label>City</Label>
                    <Typeahead
                      id="cityId" 
                      options={citiesList || []}
                      placeholder="Select city..."
                      filterBy={["cityName"]}
                      labelKey={(citiesList:any) => citiesList ? `${citiesList?.cityName}` : ""}
                      selected={selectedCity || null}
                      onChange={handleChangeCity}
                      clearButton
                    />
                  </Col>
                  <Col md="12">
                    <FormGroup>
                      <Label>Contact Type</Label>
                      <Input 
                        type="select" 
                        className="form-select"
                        id="contactType" 
                        name="contactType" 
                        value={values?.contactType}
                        onChange = {(event)=>{
                          setFieldValue("contactType",event.target.value);
                          setSelectedBelongsTo([]);
                          dispatch(getBelongsToEntityList(event.target.value,values?.cityId,null,null,null));
                        }}
                      >
                        <option>{"--Select--"}</option>
                        <option>{"Agent"}</option>
                        <option>{"Broker"}</option>
                        <option>{"Corporate"}</option>
                        <option>{"Insurance Company"}</option>
                        <option>{"Aggregator"}</option>
                        {/* <option>{"Other"}</option> */}
                      </Input>
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    {/* <AutoCompleteBelongs /> */}
                    <Label>Contact Belongs to(Name of the company)</Label>
                    {values?.contactType == "Aggregator" ? 
                      <Typeahead
                        id="contactBelongsTo_nameofcompanyId" 
                        options={belongsToList || []}
                        placeholder="Select ..."
                        filterBy={["AggregatorName"]}
                        labelKey={(belongsToList:any) => belongsToList ? `${belongsToList?.AggregatorName}` : ""}
                        selected={selectedBelongsTo || null}
                        onChange={handleChangeBelongsTo}
                        clearButton
                      /> : 
                      values?.contactType == "Insurance Company" ?
                      <Typeahead
                        id="contactBelongsTo_nameofcompanyId" 
                        options={belongsToList || []}
                        placeholder="Select ..."
                        filterBy={["InsuranceCompanyName"]}
                        labelKey={(belongsToList:any) => belongsToList ? `${belongsToList?.InsuranceCompanyName}` : ""}
                        selected={selectedBelongsTo || null}
                        onChange={handleChangeBelongsTo}
                        clearButton
                      /> : 
                      values?.contactType == "Broker" ?
                      <Typeahead
                        id="contactBelongsTo_nameofcompanyId" 
                        options={belongsToList || []}
                        placeholder="Select ..."
                        filterBy={["BrokerName"]}
                        labelKey={(belongsToList:any) => belongsToList ? `${belongsToList?.BrokerName}` : ""}
                        selected={selectedBelongsTo || null}
                        onChange={handleChangeBelongsTo}
                        clearButton
                      /> : 
                      values?.contactType == "Corporate" ?
                      <Typeahead
                        id="contactBelongsTo_nameofcompanyId" 
                        options={belongsToList || []}
                        placeholder="Select ..."
                        filterBy={["CorporateName"]}
                        labelKey={(belongsToList:any) => belongsToList ? `${belongsToList?.CorporateName}` : ""}
                        selected={selectedBelongsTo || null}
                        onChange={handleChangeBelongsTo}
                        clearButton
                      /> : 
                      values?.contactType == "Agent" ?
                      <Typeahead
                        id="contactBelongsTo_nameofcompanyId" 
                        options={belongsToList || []}
                        placeholder="Select ..."
                        filterBy={["AgentName"]}
                        labelKey={(belongsToList:any) => belongsToList ? `${belongsToList?.AgentName}` : ""}
                        selected={selectedBelongsTo || null}
                        onChange={handleChangeBelongsTo}
                        clearButton
                      /> 
                      : 
                      <Input 
                        type="text" 
                        placeholder="Select ..."
                      />
                    }
                  </Col>

                  <Col md="12">
                    <FormGroup>
                      <Label>Department</Label>
                      <Input 
                        type="text" 
                        // placeholder="Department"
                        id="department" 
                        name="department" 
                        value={values?.department}
                        onChange = {handleChange}
                      />
                    </FormGroup>
                  </Col>

                  <Col md="12">
                    <FormGroup>
                      <Label>Primary Mobile</Label>
                      <Input 
                        type="text" 
                        placeholder="Primary Mobile"
                        id="primaryMobile" 
                        name="primaryMobile"
                        value={values?.primaryMobile}
                        onChange = {handleChange}
                      />
                      {errors.primaryMobile ? (<p className="form-error">{errors.primaryMobile}</p>) : null}
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    <FormGroup>
                      <Label>Alternate Mobile</Label>
                      <Input 
                        type="text" 
                        placeholder="Alternate Mobile"
                        id="alternateMobile" 
                        name="alternateMobile" 
                        value={values?.alternateMobile}
                        onChange = {handleChange}
                      />
                      {errors.alternateMobile ? (<p className="form-error">{errors.alternateMobile}</p>) : null}
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    <FormGroup>
                      <Label>Primary Email</Label>
                      <Input 
                        type="email" 
                        placeholder="Primary Email"
                        id="primaryEmail" 
                        name="primaryEmail" 
                        value={values?.primaryEmail}
                        onChange = {handleChange}
                      />
                      {errors.primaryEmail ? (<p className="form-error">{errors.primaryEmail}</p>) : null}
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    <FormGroup>
                      <Label>Alternate Email</Label>
                      <Input 
                        type="email" 
                        placeholder="Alternate Email" 
                        id="alternateEmail" 
                        name="alternateEmail" 
                        value={values?.alternateEmail}
                        onChange = {handleChange}
                      />
                      {errors.alternateEmail ? (<p className="form-error">{errors.alternateEmail}</p>) : null}
                    </FormGroup>
                  </Col>

                  <Col md="12">
                    <Label>
                      Brief Description of Contact
                      <span
                        style={{
                          fontSize: "12px",
                          color: "gray",
                          paddingLeft: "10px"
                        }}
                      >
                        (max 500 characters)
                      </span>
                    </Label>
                    <textarea
                      className="form-control"
                      rows={3}
                      placeholder=""
                      id="notes" 
                      name="notes" 
                      value={values?.notes}
                      onChange = {handleChange}
                    />
                  </Col>
                </Row>
              </CardBody>
              <CardFooter className="text-end">
                <Btn color="primary" type="submit">
                  {editFlag ? "Update Contact" : "Add Contact"}
                </Btn>
                <Btn
                  className="btn btn-light"
                  type="reset"
                  style={{ marginLeft: "10px" }}
                  onClick = {handleCancel}
                >
                  Cancel
                </Btn>
              </CardFooter>
            </Card>
          </Form>
        </Col>
      </Row>
    </div>
  );
};
