import { useEffect, useState } from "react";
// import DatePicker, { DateObject } from 'react-multi-date-picker';
import AgGridTable from "../../../../CommonElements/AgGridTable";
import { FaEdit } from "react-icons/fa";
 import "./style.scss";
import { Btn } from "../../../../AbstractElements";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../../../../ReduxToolkit/Hooks";
import { getContactGridData, setEditContactID, setEditFlag } from "../../../../ReduxToolkit/Reducers/ContactSlice";
import { setBelongsToFlag, setCityFlag, setStateFlag } from "../../../../ReduxToolkit/Reducers/CommonSlice";
export const ContactGrid = () => {
  const dispatch=useAppDispatch();
  const contactGridData : any = useAppSelector((state)=> state.contact.contactGridData)
  const navigate = useNavigate();

  const columnDefs = [
    // {
    //   headerName: "ID",
    //   field: "contactGUID",
    //   sortable: true,
    //   filter: false,
    //   minWidth: 65,
    //   width: 65,
    //   headerClass: "right-align",     
    //   cellClass: ["justify-content-end"],
    // },
    {
      headerName: "Edit",
      field: "Edit",
      sortable: false,
      filter: false,
      minWidth: 66,
      width: 66,
      cellRenderer: (params:any) => {
        return (
          <>
            <i
              className="icon-pencil-alt"
              style={{ color: "#5b60ef", fontSize: "15px", cursor: "pointer" }}
              onClick = {()=>{
                dispatch(setStateFlag(1)); dispatch(setCityFlag(1)); dispatch(setBelongsToFlag(1));
                dispatch(setEditFlag(true)); dispatch(setEditContactID(params?.data?.ContactGUID)); navigate(`${process.env.PUBLIC_URL}/editContact`)}}
            >
            </i>
          </>
        );
      }
    },
    {
      headerName: "Name",
      field: "Name",
      sortable: true,
      filter: true,
      filterParams: {
        buttons: ["reset"]
      },
      minWidth: 160,
      width: 160
    },
    {
      headerName: "Type",
      field: "Type",
      sortable: true,
      filter: true,
      filterParams: {
        buttons: ["reset"]
      },
      minWidth: 90,
      width: 90
    },
    {
      headerName: "Belongs To",
      field: "BelongsTo",
      sortable: true,
      filter: true,
      filterParams: {
        buttons: ["reset"]
      },
      cellStyle: function(params:any) {
        // Define your custom cell style logic here
        return { 'white-space': 'normal' }; // Example style with text-wrap
      },
      autoHeight: true,
      minWidth: 170,
      width: 170
    },
    {
      headerName: "Location",
      field: "Location",
      sortable: true,
      filter: true,
      filterParams: {
        buttons: ["reset"]
      },
      minWidth: 160,
      width: 160
    },
    {
      headerName: "Department",
      field: "Department",
      sortable: true,
      filter: true,
      filterParams: {
        buttons: ["reset"]
      },
      minWidth: 140,
      width: 140
    },
    {
      headerName: "Designation",
      field: "Designation",
      sortable: true,
      filter: true,
      filterParams: {
        buttons: ["reset"]
      },
      minWidth: 130,
      width: 130
    },
    {
      headerName: "Primary Mobile",
      field: "contact",
      sortable: true,
      filter: false,
      filterParams: {
        buttons: ["reset"]
      },
      minWidth: 130,
      width: 130,
      headerClass: "right-align",     
      cellClass: ["justify-content-end"],
    },
    {
      headerName: "Primary Email",
      field: "Email",
      sortable: true,
      filter: true,
      filterParams: {
        buttons: ["reset"]
      },
      minWidth: 230,
      width: 230,
      cellStyle: { textWrap: "wrap" },

      autoHeight: true,
    },
    
  ];

  useEffect(()=>{
    dispatch(getContactGridData());
  },[])

  const style = { height: "calc(100vh - 140px)", width: "100%" };
  const getRowHeight = () => 30;

  // const [value, setValue] = useState([new DateObject()]);
  // const onChange = ()=>{
  //     console.log("DatePicker",new DateObject())
  // }
  return (
    <div className="page-body">
      <div className="d-flex center-block-meeting justify-content-between mt-4 mb-1 align-items-center pt-1 pt-1">
        <div className="ps-0 col-sm-6">
          <h3 className="screen-title">Contacts</h3>
        </div>
        <div>
          <div className="d-flex gap-3 mt-2">
            <div className="text-end">
              {/* <Link
                color="primary"
                className="w-100"
                to={`${process.env.PUBLIC_URL}/addContact`}
              > */}
                <Btn color="primary" block className="plus-button " 
                onClick={()=>{
                  dispatch(setEditFlag(false)); dispatch(setEditContactID(null)); navigate(`${process.env.PUBLIC_URL}/addContact`) 
                  }}>
                   <i className="icon-plus"></i> 
                   Add
                </Btn>
              {/* </Link> */}
            </div>
          </div>
        </div>
      </div>

      {/* <p>AG Grid Table Test</p> */}
      <AgGridTable
        rowData={contactGridData} className="center-block-meeting-grid"
        columnDefs={columnDefs}
        Style={style}
        getRowHeight={getRowHeight}
        pagination={true}
        paginationPageSize={15}
      />
    </div>
  );
};
