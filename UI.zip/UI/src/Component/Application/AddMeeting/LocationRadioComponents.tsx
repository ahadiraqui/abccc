import React, { useState } from "react";
import {
  Card,
  CardBody,
  CardFooter,
  Col,
  Form,
  FormGroup,
  Input,
  Label,
  Row
} from "reactstrap";
import TourLocationRadioComponentsState from "../AddAttendance/TourLocationRadioComponentsState";
import AutoCompleteTourCity from "./TourLocationRadioComponents";

function LocationRadioComponents() {
  const [selectedOption, setSelectedOption] = useState("Branch");
  const [selectedOption1, setSelectedOption1] = useState("");
  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);

  const handleOptionChange = (selectedOption: any) => {
    setSelectedOption(selectedOption);
    if (selectedOption == "Field") {
      setShow(true);
    } else {
      setShow(false);
    }
    if (selectedOption == "Branch") {
      setShow1(false);
    } else {
      setShow1(true);
    }
  };

  const handleOptionChange1 = (selectedOption1: any) => {
    setSelectedOption1(selectedOption1);
    if (selectedOption1 == "WithinCity") {
      setShow1(false);
    } else {
      setShow1(true);
    }
  };

  return (
    <>
      <div className="d-flex  mb-3 flex-wrap">
        <Label style={{ paddingRight: "20px" }}>Location</Label>
        <div
          className="btn-group padding-l"
          role="group"
          aria-label="Basic radio toggle button group"
        >
          <input
            type="radio"
            className="btn-check"
            name="options"
            id="Branch"
            autoComplete="off"
            checked={selectedOption === "Branch"}
            onChange={() => handleOptionChange("Branch")}
          />
          <label
            className={`btn btn-outline-primary me-4 ${
              selectedOption === "Branch" ? "active" : ""
            }`}
            htmlFor="Branch"
          >
            Branch
          </label>

          <input
            type="radio"
            className="btn-check"
            name="options"
            id="Field"
            autoComplete="off"
            checked={selectedOption === "Field"}
            onChange={() => handleOptionChange("Field")}
          />
          <label
            className={`btn btn-outline-primary me-4 ${
              selectedOption === "Field" ? "active" : ""
            }`}
            htmlFor="Field"
          >
            Field
          </label>
        </div>
      </div>
      {show && (
        <div className="d-flex flex-wrap">
          <Label style={{ paddingRight: "20px" }}>Tour Location</Label>
          <div
            className="btn-group pl-14px"
         
            role="group"
            aria-label="Basic radio toggle button group"
          >
            <input
              type="radio"
              className="btn-check"
              name="options"
              id="WithinCity"
              autoComplete="off"
              checked={selectedOption1 === "WithinCity"}
              onChange={() => handleOptionChange1("WithinCity")}
            />
            <label
              className={`btn btn-outline-primary me-4 ${
                selectedOption1 === "WithinCity" ? "active" : ""
              }`}
              htmlFor="WithinCity"
            >
              Within City
            </label>

            <input
              type="radio"
              className="btn-check"
              name="options"
              id="Tour"
              autoComplete="off"
              checked={selectedOption1 === "Tour"}
              onChange={() => handleOptionChange1("Tour")}
            />
            <label
              className={`btn btn-outline-primary me-4 ${
                selectedOption1 === "Tour" ? "active" : ""
              }`}
              htmlFor="Tour"
            >
              On Tour
            </label>
          </div>
        </div>
      )}
      {show1 && (
        <>       
        <TourLocationRadioComponentsState/>
        <AutoCompleteTourCity/>
        </>
      )}
    </>
  );
}

export default LocationRadioComponents;
