import { useEffect, useState } from "react";

import { Btn } from "../../../AbstractElements";
import {
  Card,
  CardBody,
  CardFooter,
  Col,
  Form,
  FormGroup,
  Input,
  Label,
  Row
} from "reactstrap";

import "./style.scss";


import LocationRadioComponents from "./LocationRadioComponents";
import { useFormik } from "formik";
import * as Yup from "yup";
import { Typeahead } from "react-bootstrap-typeahead";
import { useNavigate } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../../../ReduxToolkit/Hooks";
import { getCitiesList, getStateList, setCityFlag } from "../../../ReduxToolkit/Reducers/CommonSlice";
import moment from "moment";
import { AddUpdateMeeting, getMeetingDataById } from "../../../ReduxToolkit/Reducers/MeetingAction";
import { MobileDateTimePicker } from '@mui/x-date-pickers/MobileDateTimePicker';
import dayjs from "dayjs";

export const AddMeeting = () => {
  const [selectedOption, setSelectedOption] = useState("Branch");
  const [selectedOption1, setSelectedOption1] = useState("Within City");
  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);
  const [selected,setSelected] = useState<string[]>([]);
  const [selectedCity,setSelectedCity] = useState<string[]>([]);

  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const commonAction = useAppSelector((state:any)=>state.commonAction);
  const stateList = commonAction.stateList;
  const citiesList = commonAction.citiesList;
  const cityFlag = commonAction.cityFlag;

  const meetingAction = useAppSelector((state:any)=>state.meetingAction);
  const editMeetingFlag = meetingAction?.editMeetingFlag;
  const editMeetingID = meetingAction?.editMeetingID;
  const meetingDataById = meetingAction?.meetingDataById;

  // console.log("EDIT",meetingDataById)
  const handleOptionChange = (selectedOption: any) => {
    setSelectedOption(selectedOption);
    setFieldValue("location",selectedOption);
    if (selectedOption == "Field") {
      setSelectedOption1("Within City")
      setShow(true);
      setShow1(false);
    } 
    // else {
    //   setShow(false);
    // }
    if (selectedOption == "Branch") {
      setSelectedOption1("")
      setShow1(false);
      setShow(false);
    } 
    // else {
    //   setShow1(true);
    // }
  };
  const handleOptionChange1 = (selectedOption1: any) => {
    setFieldValue("tourLocation",selectedOption1);
    setSelectedOption1(selectedOption1);
    if (selectedOption1 == "Within City") {
      setShow1(false);
    } else {
      setShow1(true);
    }
  };

  useEffect(()=>{
    setSelected([]);
    setSelectedCity([]);
    dispatch(getStateList());
    if(editMeetingID)
    {
      dispatch(getMeetingDataById(editMeetingID));
    }
  },[])

  const validationSchema = Yup.object({
    startTime :Yup.string().required("Please enter Start Time"),
    endTime :Yup.string().required("Please enter End Time"),
    stateId: Yup.number().test({
      name: 'required',
      test: function(value) {
        const { tourLocation } = this.parent;
        if (((tourLocation === 'Tour' || selectedOption1=='Tour') && selectedOption == "Field") && value === 0) {
          return false;
        }
        return true;
      },
      message: 'Please select State'
    }),
    cityId: Yup.number().test({
      name: 'required',
      test: function(value) {
        const { tourLocation } = this.parent;
        if (((tourLocation === 'Tour' || selectedOption1=='Tour') && selectedOption == "Field") && value === 0) {
          return false;
        }
        return true;
      },
      message: 'Please select City'
    })
  })

  const {values,setFieldValue,handleChange,handleSubmit,errors,touched,resetForm,handleBlur,setFieldError,setFieldTouched} = useFormik({
    initialValues: {
      location: '',
      tourLocation :'',
      stateId:0,
      cityId: 0,
      mode:'',
      startTime:'',
      endTime:'',
      notes:''
    },
    validationSchema : validationSchema,
    onSubmit: (values,action) => {
      const payload = {
        meetingAt: values?.location || selectedOption,
        fieldMeetingAt: values?.tourLocation || selectedOption1 || "Within City",
        fieldMeetingCity: values?.cityId,
        fieldMeetingState: values?.stateId,
        mode: values?.mode,
        meetingDate: meetingDataById?.length>0 ? meetingDataById[0]?.MeetingDate : moment().format('YYYY-MM-DDTHH:mm:ss.SSSZ'),
        meetingStartTime: values?.startTime,
        meetingDueTime: values?.endTime,
        notes: values?.mode,
        meetingGUID: meetingDataById?.length>0 ? meetingDataById[0]?.MeetingGUID : null
      }
      dispatch(AddUpdateMeeting(payload));
      action.resetForm();
      setSelected([]);
      setSelectedCity([]);
      navigate(`${process.env.PUBLIC_URL}/meeting`)
    },
  }); 

  const handleCancel = ()=>{
    resetForm();
  }

  const handleChangeState = (value:any) => {
    setFieldValue("stateId",value[0]?.StateId);
    setSelected(value);
    setSelectedCity([]);
    setFieldValue("cityId",0);
    dispatch(getCitiesList(value[0]?.StateId));
  };

  const handleChangeCity = (value:any) => {
    setFieldValue("cityId",value[0]?.cityId);
    setSelectedCity(value);
  }

  useEffect(()=>{
    if(values?.location === "Branch")
    {
      setSelectedOption1("")
      setShow1(false);
      setFieldValue("stateId",0);
      setFieldValue("cityId",0);
      setSelected([]);
      setSelectedCity([]);
    }
    if(values?.tourLocation == "Within City")
    {
      setFieldValue("stateId",0);
      setFieldValue("cityId",0);
      setSelected([]);
      setSelectedCity([]);
    }
  },[values?.location,values?.tourLocation])

  useEffect(()=>{
    if(meetingDataById?.length>0)
    {
      setFieldValue("location",meetingDataById[0]?.MeetingAt);
      handleOptionChange(meetingDataById[0]?.MeetingAt);
      setFieldValue("tourLocation",meetingDataById[0]?.FieldMeetingAt);
      handleOptionChange1(meetingDataById[0]?.FieldMeetingAt);
      setFieldValue("stateId",meetingDataById[0]?.FieldMeetingState);
      setFieldValue("cityId",meetingDataById[0]?.FieldMeetingCity);
      setFieldValue("mode",meetingDataById[0]?.Mode);
      setFieldValue("notes",meetingDataById[0]?.Notes);

      const date = new Date(meetingDataById[0]?.MeetingDate);
      const timeComponents = meetingDataById[0]?.MeetingStartTime.split(":");
      const formattedTime = `${timeComponents[0]}:${timeComponents[1]}`;
      const formattedDateTime = `${date.toISOString().split('T')[0]}T${formattedTime}`;
      setFieldValue("startTime",formattedDateTime);

      const date2 = new Date(meetingDataById[0]?.MeetingDate);
      const timeComponents2 = meetingDataById[0]?.MeetingDueTime.split(":");
      const formattedTime2 = `${timeComponents2[0]}:${timeComponents2[1]}`;
      const formattedDateTime2 = `${date2.toISOString().split('T')[0]}T${formattedTime2}`;
      setFieldValue("endTime",formattedDateTime2);

      const selectedState = stateList?.find((item:any) => item.StateId === meetingDataById[0]?.FieldMeetingState)
      const newArray1  = [ ...selected, selectedState ];
      setSelected(newArray1);
      setSelectedCity([]);
      dispatch(setCityFlag(1));
      dispatch(getCitiesList(meetingDataById[0]?.FieldMeetingState));
    }
  },[meetingDataById]);

  useEffect(()=>{
    if(meetingDataById && citiesList && cityFlag == 1)
    {
      dispatch(setCityFlag(2));
      const selectedCityFind = citiesList?.find((item:any) => item.cityId === meetingDataById[0]?.FieldMeetingCity)
      const newArray = [ ...selectedCity, selectedCityFind ];
      setSelectedCity(newArray);
    }
  },[meetingDataById,citiesList])
  
  return (
    <div className="page-body">
      <div className="d-flex justify-content-between mt-4 mb-1 align-items-center pt-1 pt-1">
        <div className="ps-0 col-sm-6">
          <h3 className="screen-title">{editMeetingFlag ? "Edit Meeting" : "Add Meeting"}</h3>
        </div>
      </div>

      <Row>
        <Col lg="3" className="d-none d-lg-block"></Col>
        <Col lg="6">
          <Form onSubmit = {handleSubmit}>
            <Card>
              <CardBody>
                <Row>
                  <Col md="12">
                    <div className="mb-3">                     
                      {/* <LocationRadioComponents /> */}
                      <div className="d-flex  mb-3 flex-wrap">
                        <Label style={{ paddingRight: "20px" }}>Location</Label>
                        <div
                          className="btn-group padding-l"
                          role="group"
                          aria-label="Basic radio toggle button group"
                        >
                          <input
                            type="radio"
                            className="btn-check"
                            name="options"
                            id="Branch"
                            autoComplete="off"
                            checked={selectedOption === "Branch"}
                            onChange={() => handleOptionChange("Branch")}
                          />
                          <label
                            className={`btn btn-outline-primary me-4 ${
                              selectedOption === "Branch" ? "active" : ""
                            }`}
                            htmlFor="Branch"
                          >
                            Branch
                          </label>

                          <input
                            type="radio"
                            className="btn-check"
                            name="options"
                            id="Field"
                            autoComplete="off"
                            checked={selectedOption === "Field"}
                            onChange={() => handleOptionChange("Field")}
                          />
                          <label
                            className={`btn btn-outline-primary me-4 ${
                              selectedOption === "Field" ? "active" : ""
                            }`}
                            htmlFor="Field"
                          >
                            Field
                          </label>
                        </div>
                      </div>
                      {show && (
                        <div className="d-flex flex-wrap">
                          <Label style={{ paddingRight: "20px" }}>Tour Location</Label>
                          <div
                            className="btn-group pl-14px"
                        
                            role="group"
                            aria-label="Basic radio toggle button group"
                          >
                            <input
                              type="radio"
                              className="btn-check"
                              name="options"
                              id="WithinCity"
                              autoComplete="off"
                              checked={selectedOption1 === "Within City"}
                              onChange={() => handleOptionChange1("Within City")}
                            />
                            <label
                              className={`btn btn-outline-primary me-4 ${
                                selectedOption1 === "Within City" ? "active" : ""
                              }`}
                              htmlFor="WithinCity"
                            >
                              Within City
                            </label>

                            <input
                              type="radio"
                              className="btn-check"
                              name="options"
                              id="Tour"
                              autoComplete="off"
                              checked={selectedOption1 === "Tour"}
                              onChange={() => handleOptionChange1("Tour")}
                            />
                            <label
                              className={`btn btn-outline-primary me-4 ${
                                selectedOption1 === "Tour" ? "active" : ""
                              }`}
                              htmlFor="Tour"
                            >
                              Tour
                            </label>
                          </div>
                        </div>
                      )}
                      {show1 && (
                        <>
                          <Label>State</Label>
                          <Typeahead
                            id="stateId" 
                            options={stateList || []}
                            placeholder="Select state..."
                            filterBy={["Name"]}
                            labelKey={(stateList:any) => `${stateList?.Name}`}
                            selected={selected}
                            onChange={handleChangeState}
                          />
                          {errors.stateId ? (<p className="form-error">{errors.stateId}</p>) : null}
                          <Label>City</Label>
                          <Typeahead
                            id="cityId" 
                            options={citiesList || []}
                            placeholder="Select city..."
                            filterBy={["cityName"]}
                            labelKey={(citiesList:any) => `${citiesList?.cityName}`}
                            selected={selectedCity}
                            onChange={handleChangeCity}
                            onBlur={handleBlur}
                          />    
                          {errors.cityId  ? (<p className="form-error">{errors.cityId}</p>) : null}   
                        {/* <TourLocationRadioComponentsState/>
                        <AutoCompleteTourCity/> */}
                        </>
                      )}
                    </div>
                    {/* <FormGroup>
                      <Label>Location</Label>
                      <Input type="select" className="form-select">
                        <option>{"--Select--"}</option>
                        <option>{"Branch"}</option>
                        <option>{"Field"}</option>                   
                      </Input>
                    </FormGroup> */}
                  </Col>
                  {/* <Col md="12">
                    <div className="mb-3">
                      <Label style={{ paddingRight: "20px" }}>Tour Location</Label>
                      <TourLocationRadioComponents />
                    </div>
                  
                  </Col> */}

                  {/* <Col md="12">
                    <FormGroup>
                      <Label>Tour Location</Label>
                      <Input type="select" className="form-select">
                        <option>{"--Select--"}</option>
                        <option>{"Within City"}</option>
                        <option>{"On Tour"}</option>
                      </Input>
                    </FormGroup>
                  </Col> */}
                 
                  <Col md="12">
                    <FormGroup>
                      <Label>Mode</Label>
                      <Input 
                        type="select" 
                        className="form-select"
                        id="mode" 
                        name="mode" 
                        value={values?.mode}
                        onChange = {handleChange}
                      >
                        <option>{"--Select--"}</option>
                        <option>{"Phone call"}</option>
                        <option>{"Virtual meeting"}</option>
                        <option>{"In person"}</option>
                      </Input>
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    <FormGroup>
                      <Label>Start Time</Label>
                      <Input 
                        type="datetime-local" 
                        placeholder="time" 
                        id="startTime" 
                        name="startTime" 
                        value={values?.startTime}
                        onChange = {handleChange}
                        onBlur={handleBlur}
                      />
                      {touched.startTime && errors.startTime ? (<p className="form-error">{errors.startTime}</p>) : null}
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    <FormGroup>
                      <Label>End Time</Label>
                      <Input 
                        type="datetime-local" 
                        placeholder="time" 
                        id="endTime" 
                        name="endTime" 
                        value={values?.endTime}
                        onChange = {handleChange}
                        onBlur={handleBlur}
                      />
                      {touched.endTime && errors.endTime ? (<p className="form-error">{errors.endTime}</p>) : null}
                    </FormGroup>
                  </Col>
                  {/* <Col md="12">
                    <FormGroup>
                      <Label>Notes</Label>
                      <Input type="text" placeholder="Notes" />
                    </FormGroup>
                  </Col> */}

                  <Col md="12">
                    <Label>Notes</Label>
                    <textarea
                      className="form-control"
                      rows={3}
                      placeholder=""
                      id="notes" 
                      name="notes" 
                      value={values?.notes}
                      onChange = {handleChange}
                    />
                  </Col>
                </Row>
              </CardBody>
              <CardFooter className="text-end">
                <Btn color="primary" type="submit">
                  {editMeetingFlag ? "Update" : "Submit"}
                </Btn>
                <Btn
                  className="btn btn-light"
                  type="reset"
                  style={{ marginLeft: "10px" }}
                  onClick = {handleCancel}
                >
                  Cancel
                </Btn>
              </CardFooter>
            </Card>
          </Form>
        </Col>
      </Row>
    </div>
  );
};
