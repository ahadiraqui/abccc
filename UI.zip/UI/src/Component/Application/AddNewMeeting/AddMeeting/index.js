import { useEffect, useState } from "react";

import { Btn } from "../../../../AbstractElements";
import {
  Card,
  CardBody,
  CardFooter,
  Col,
  Form,
  FormGroup,
  Input,
  Label,
  Row,
  TabContent,
  TabPane
} from "reactstrap";
import { Link, useNavigate } from "react-router-dom";
import "./style.scss";
import moment from "moment";
import LocationRadioComponents from "./LocationRadioComponents";
import { useFormik } from "formik";
import dayjs from "dayjs";
import * as Yup from "yup";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";

import { useAppDispatch, useAppSelector } from "../../../../ReduxToolkit/Hooks";
import { getCitiesList, getStateList } from "../../../../ReduxToolkit/Reducers/CommonSlice";
import { AddUpdateMeeting, GetEmployeeWorkingStatus, getMeetingDataById, setDisableWorkingStatus, setOpportunityTab, setSelectedMeetingDate } from "../../../../ReduxToolkit/Reducers/MeetingAction";
import { Typeahead } from "react-bootstrap-typeahead";
import { AddAttendanceAPI } from "../../../../ReduxToolkit/Reducers/AttendanceAction";
import { setOpportunityDataById, setOpportunityEditFlag, setOpportunityFlag, setOpportunityId } from "../../../../ReduxToolkit/Reducers/OpportunityAction";
import DatePickerContainer from "../../../Forms/FormsWidgets/DatePicker/DatePicker";
import TimePickerCommon from "../../../../CommonElements/TimePickerCommon";
import { toast } from "react-toastify";
const AddNewMeetingComponents = () => {
  const [activeTab, setActiveTab] = useState("1");
  const [selectedDate, setSelectedDate] = useState(dayjs());
  const [selectedOption, setSelectedOption] = useState("Branch");
  const [selectedOption1, setSelectedOption1] = useState("Within City");
  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);
  const [selected,setSelected] = useState([]);
  const [selectedCity,setSelectedCity] = useState([]);

  const toggle = (tab) => {
    if (activeTab !== tab) setActiveTab(tab);
  };

  // const formatDate = (date) => {
  //   if (!date) return "";
  //   return dayjs(date).format("ddd, DD MMM YYYY");
  // };
  const handleDateChange = (date) => {
    setSelectedDate(date);
    dispatch(GetEmployeeWorkingStatus(date.format('MM-DD-YYYY')))
  };

  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const commonAction = useAppSelector((state)=>state.commonAction);
  const stateList = commonAction.stateList;
  const citiesList = commonAction.citiesList;
  const cityFlag = commonAction.cityFlag;

  const meetingAction = useAppSelector((state)=>state.meetingAction);
  const editMeetingFlag = meetingAction?.editMeetingFlag;
  const editMeetingID = meetingAction?.editMeetingID;
  const meetingDataById = meetingAction?.meetingDataById;
  const employeeWorkingStatus = meetingAction?.employeeWorkingStatus;
  const disableWorkingStatus = meetingAction?.disableWorkingStatus

  useEffect(()=>{
    dispatch(GetEmployeeWorkingStatus(selectedDate.format('MM-DD-YYYY')))
  },[])
  
  const getTabNumber = (tab)=>{
    if(tab == "Working")
    {
      return "0"
    }
    else if(tab == "Nothing to Report")
    {
      return "2"
    }
    else if(tab == "Weekly Off")
    {
      return "1"
    }
    else if(tab == "Leave")
    {
      return "3"
    }
    else if(tab == "Holiday")
    {
      return "4"
    }
  }

  useEffect(() => {
    // debugger
    if(employeeWorkingStatus === "Working")
    {
      dispatch(setDisableWorkingStatus(false));
    }
    else if(employeeWorkingStatus === "Not Worked")
    {
      dispatch(setDisableWorkingStatus(false));
    }
    else{
      dispatch(setDisableWorkingStatus(true));
    }

    if(employeeWorkingStatus !== "Not Worked")
    {
      const tabNo = getTabNumber(employeeWorkingStatus)
      toggle(tabNo);
    }
  }, [employeeWorkingStatus]);

  const handleOptionChange = (selectedOption) => {
    setSelectedOption(selectedOption);
    setFieldValue("location",selectedOption);
    if (selectedOption == "Field") {
      setSelectedOption1("Within City")
      setShow(true);
      setShow1(false);
    } 
    // else {
    //   setShow(false);
    // }
    if (selectedOption == "Branch") {
      setSelectedOption1("")
      setShow1(false);
      setShow(false);
    } 
    // else {
    //   setShow1(true);
    // }
  };
  const handleOptionChange1 = (selectedOption1) => {
    setFieldValue("tourLocation",selectedOption1);
    setSelectedOption1(selectedOption1);
    if (selectedOption1 == "Within City") {
      setShow1(false);
    } else {
      setShow1(true);
    }
  };

  useEffect(()=>{
    setSelected([]);
    setSelectedCity([]);
    dispatch(getStateList());
    if(editMeetingID)
    {
      // dispatch(getMeetingDataById(editMeetingID));
    }
  },[])

  const [activeTab1, setActiveTab1] = useState("1");
  const toggle1 = (tab1) => {
    if (activeTab1 !== tab1) setActiveTab1(tab1);
  };

  const getTabName = (tab)=>{
    if(tab == "0")
    {
      return "Working"
    }
    else if(tab == "2")
    {
      return "Nothing to Report"
    }
    else if(tab == "1")
    {
      return "Weekly Off"
    }
    else if(tab == "3")
    {
      return "Leave"
    }
    else if(tab == "4")
    {
      return "Holiday"
    }
  }

  const validationSchema = Yup.object({
    // startTime : activeTab === "0" ? Yup.string().required("Please enter Start Time") : Yup.string(),
    // endTime : activeTab === "0" ? Yup.string().required("Please enter End Time") : Yup.string(),
    stateId: Yup.number().test({
      name: 'required',
      test: function(value) {
        const { tourLocation } = this.parent;
        if (((tourLocation === 'Tour' || selectedOption1=='Tour') && selectedOption == "Field") && value === 0) {
          return false;
        }
        return true;
      },
      message: 'Please select State'
    }),
    cityId: Yup.number().test({
      name: 'required',
      test: function(value) {
        const { tourLocation } = this.parent;
        if (((tourLocation === 'Tour' || selectedOption1=='Tour') && selectedOption == "Field") && value === 0) {
          return false;
        }
        return true;
      },
      message: 'Please select City'
    })
  })

  const {values,setFieldValue,handleChange,handleSubmit,errors,touched,resetForm,handleBlur,setFieldError,setFieldTouched} = useFormik({
    initialValues: {
      location: '',
      tourLocation :'',
      stateId:0,
      cityId: 0,
      mode:'',
      startTime:'',
      endTime:'',
      notes:''
    },
    validationSchema : validationSchema,
    onSubmit: (values,action) => {
      if (activeTab === "0" && (!values?.startTime || !values?.endTime)) {
        toast.error("Please fill in both start time and end time.");
        return;
      }
      // console.log("DATETIME",selectedDate.format("YYYY-MM-DDT")+values?.startTime+":00.000Z")
      dispatch(setOpportunityTab(null))
      dispatch(setSelectedMeetingDate(null));

      const attendance = getTabName(activeTab);
      const attendancePayload = {
        attendanceId: 0,
        applicationUserId: 0,
        employeeId: 0,
        attendanceFromDate: selectedDate.format('YYYY-MM-DDTHH:mm:ss.SSSZ'),
        isWorkedHalfDay: false,
        attendance: attendance,
        workedinBranchNothingToReport: false,
        recordStatus: "Active"
      }
      // alert(JSON.stringify(values, null, 2));
      dispatch(AddAttendanceAPI(attendancePayload));

      if(attendance === "Working")
      {
        const payload = {
          meetingAt: values?.location || selectedOption,
          fieldMeetingAt: values?.tourLocation || selectedOption1 || "Within City",
          fieldMeetingCity: values?.cityId>0 ? values?.cityId : null,
          fieldMeetingState: values?.stateId>0 ? values?.stateId : null,
          mode: values?.mode,
          meetingDate: meetingDataById?.length>0 ? meetingDataById[0]?.MeetingDate : selectedDate.format('YYYY-MM-DDTHH:mm:ss.SSSZ'),
          meetingStartTime: values?.startTime,
          meetingDueTime: values?.endTime,
          notes: values?.mode,
          meetingGUID: meetingDataById?.length>0 ? meetingDataById[0]?.MeetingGUID : null
        }
        dispatch(AddUpdateMeeting(payload));
        dispatch(setOpportunityTab(activeTab1))
        dispatch(setSelectedMeetingDate(selectedDate.format('YYYY-MM-DD')));
        // alert(JSON.stringify(payload, null, 2));
        dispatch(setOpportunityDataById([]));
        dispatch(setOpportunityId(null));
        dispatch(setOpportunityEditFlag(false));
        dispatch(setOpportunityFlag(null))
        navigate(`${process.env.PUBLIC_URL}/add-new-opportunity`)
      }
      action.resetForm();
      setSelected([]);
      setSelectedCity([]);
      // navigate(`${process.env.PUBLIC_URL}/meeting`)
    },
  }); 

  const handleCancel = ()=>{
    resetForm();
  }

  const handleChangeState = (value) => {
    setFieldValue("stateId",value[0]?.StateId);
    setSelected(value);
    setSelectedCity([]);
    setFieldValue("cityId",0);
    dispatch(getCitiesList(value[0]?.StateId));
  };

  const handleChangeCity = (value) => {
    setFieldValue("cityId",value[0]?.cityId);
    setSelectedCity(value);
  }

  useEffect(()=>{
    if(values?.location === "Branch")
    {
      setSelectedOption1("")
      setShow1(false);
      setFieldValue("stateId",0);
      setFieldValue("cityId",0);
      setSelected([]);
      setSelectedCity([]);
    }
    if(values?.tourLocation == "Within City")
    {
      setFieldValue("stateId",0);
      setFieldValue("cityId",0);
      setSelected([]);
      setSelectedCity([]);
    }
  },[values?.location,values?.tourLocation])

  const setTimeValues = (type,value)=>{
    setFieldValue(type,selectedDate.format("YYYY-MM-DDT")+value+":00.000Z");
    //console.log("MEETING",type,value);
  }

  return (
    <div className="page-body">
      <div className="d-flex justify-content-between mt-4 mb-1 align-items-center pt-1 pt-1">
        <div className="ps-0 col-sm-6">
          <h3 className="screen-title"> Add Schedule </h3>
        </div>
      </div>

      <Row>
        <Col lg="3" className="d-none d-lg-block"></Col>
        <Col lg="6">
          <Form>
            <Card>
              <CardBody>
                <Row>
                  <Col md="12">
                    <div className="mb-3 btn-min">
                      {/* <Form> */}
                        <div className="gap-2 mb-4">
                          <div>
                            <Label style={{ paddingRight: "15px" }}>
                              Date
                            </Label>
                          </div>
                          <LocalizationProvider dateAdapter={AdapterDayjs}>
                            <DatePicker
                              className="custom-date"
                              value={selectedDate}
                              onChange={handleDateChange}
                              renderInput={props => (
                                <input
                                  {...props}
                                  variant="standard"
                                  fullWidth
                                />
                              )}
                              format="ddd, DD MMM YYYY" // Format for the displayed date
                              maxDate={selectedDate}
                            />
                          </LocalizationProvider>
                          {disableWorkingStatus && <div><span className="form-error">Your Attendance is marked as {employeeWorkingStatus}</span></div>}
                        </div>
                        {/* <div>
                          <span className="form-error">Your status is ${employeeWorkingStatus}</span>
                        </div> */}
                        <div className="tab-mobile-section">
                          <Row>
                            <Col md="4">
                              <div className="m-mb-15">
                                <span
                                  className={
                                    activeTab === "0"
                                      ? "active btn btn-outline-primary"
                                      : "btn btn-outline-primary"
                                  }
                                  onClick={() => {
                                    if (!disableWorkingStatus) {
                                      toggle("0");
                                    }
                                  }}
                                  style={{ cursor: disableWorkingStatus ? 'not-allowed' : 'pointer' }}
                                >
                                  Working
                                </span>
                              </div>
                            </Col>
                            <Col md="8">
                              <div>
                                <span
                                  className={
                                    activeTab === "2"
                                      ? "active btn btn-outline-primary"
                                      : "btn btn-outline-primary"
                                  }
                                  onClick={() => {
                                    if (!disableWorkingStatus && employeeWorkingStatus !== "Working") {
                                      toggle("2");
                                    }
                                  }}
                                  style={{ cursor: disableWorkingStatus || employeeWorkingStatus === "Working" ? 'not-allowed' : 'pointer',padding: '6px' }}
                                >
                                  Working from branch and nothing to report
                                </span>
                              </div>
                            </Col>
                          </Row>
                          <Row className="mt-3">
                            <Col md="4">
                              <div className="m-mb-15">
                                <span
                                  className={
                                    activeTab === "1"
                                      ? "active btn btn-outline-primary"
                                      : "btn btn-outline-primary"
                                  }
                                  onClick={() => {
                                    if (!disableWorkingStatus && employeeWorkingStatus !== "Working") {
                                      toggle("1");
                                    }
                                  }}
                                  style={{ cursor: disableWorkingStatus || employeeWorkingStatus === "Working" ? 'not-allowed' : 'pointer' }}
                                >
                                  Weekly Off
                                </span>
                              </div>
                            </Col>
                            <Col md="4">
                              <div className="m-mb-15">
                                <span
                                  className={
                                    activeTab === "3"
                                      ? "active btn btn-outline-primary"
                                      : "btn btn-outline-primary"
                                  }
                                  onClick={() => {
                                    if (!disableWorkingStatus && employeeWorkingStatus !== "Working") {
                                      toggle("3");
                                    }
                                  }}
                                  style={{ cursor: disableWorkingStatus || employeeWorkingStatus === "Working" ? 'not-allowed' : 'pointer' }}
                                >
                                  Leave
                                </span>
                              </div>
                            </Col>
                            <Col md="4">
                              <div>
                                <span
                                  className={
                                    activeTab === "4"
                                      ? "active btn btn-outline-primary"
                                      : "btn btn-outline-primary"
                                  }
                                  onClick={() => {
                                    if (!disableWorkingStatus && employeeWorkingStatus !== "Working") {
                                      toggle("4");
                                    }
                                  }}
                                  style={{ cursor: disableWorkingStatus || employeeWorkingStatus === "Working" ? 'not-allowed' : 'pointer' }}
                                >
                                  Holiday
                                </span>
                              </div>
                            </Col>
                          </Row>
                        </div>
                        {/* <TabContent activeTab={activeTab}>
                          <TabPane tabId="0">
                            <div className="gap-2 mt-4">
                              <div>
                                <Label style={{ paddingRight: "15px" }}>
                                  Date
                                </Label>
                              </div>
                              <LocalizationProvider dateAdapter={AdapterDayjs}>
                                <DatePicker
                                  className="custom-date"
                                  value={selectedDate}
                                  onChange={handleDateChange}
                                  renderInput={props => (
                                    <input
                                      {...props}
                                      variant="standard"
                                      fullWidth
                                    />
                                  )}
                                  format="ddd, DD MMM YYYY" // Format for the displayed date
                                />
                              </LocalizationProvider>
                            </div>
                          </TabPane>
                          <TabPane tabId="1">
                            <div className="gap-2 mt-4">
                              <div>
                                <Label style={{ paddingRight: "15px" }}>
                                  Date
                                </Label>
                              </div>
                              <LocalizationProvider dateAdapter={AdapterDayjs}>
                                <DatePicker
                                  className="custom-date"
                                  value={selectedDate}
                                  onChange={handleDateChange}
                                  renderInput={props => (
                                    <input
                                      {...props}
                                      variant="standard"
                                      fullWidth
                                    />
                                  )}
                                  format="ddd, DD MMM YYYY" // Format for the displayed date
                                />
                              </LocalizationProvider>
                            </div>
                          </TabPane>
                          <TabPane tabId="2">
                            <Row className="mt-4">
                              <Col md="6" className="mb-15">
                                <div>
                                  <Label>Date</Label>
                                </div>
                                <LocalizationProvider
                                  dateAdapter={AdapterDayjs}
                                >
                                  <DatePicker
                                    className="custom-date"
                                    value={selectedDate}
                                    onChange={handleDateChange}
                                    renderInput={props => (
                                      <input
                                        {...props}
                                        variant="standard"
                                        fullWidth
                                      />
                                    )}
                                    format="ddd, DD MMM YYYY" // Format for the displayed date
                                  />
                                </LocalizationProvider>
                              </Col>
                            </Row>
                          </TabPane>
                          <TabPane tabId="3">
                            <Row className="mt-4">
                              <Col md="6" className="mb-15">
                                <div>
                                  <Label>Date</Label>
                                </div>
                                <LocalizationProvider
                                  dateAdapter={AdapterDayjs}
                                >
                                  <DatePicker
                                    className="custom-date"
                                    value={selectedDate}
                                    onChange={handleDateChange}
                                    renderInput={props => (
                                      <input
                                        {...props}
                                        variant="standard"
                                        fullWidth
                                      />
                                    )}
                                    format="ddd, DD MMM YYYY" // Format for the displayed date
                                  />
                                </LocalizationProvider>
                              </Col>
                            </Row>
                          </TabPane>
                          <TabPane tabId="4">
                            <Row className="mt-4">
                              <Col md="6">
                                <div>
                                  <Label>Date</Label>
                                </div>
                                <LocalizationProvider
                                  dateAdapter={AdapterDayjs}
                                >
                                  <DatePicker
                                    className="custom-date"
                                    value={selectedDate}
                                    onChange={handleDateChange}
                                    renderInput={props => (
                                      <input
                                        {...props}
                                        variant="standard"
                                        fullWidth
                                      />
                                    )}
                                    format="ddd, DD MMM YYYY" // Format for the displayed date
                                  />
                                </LocalizationProvider>
                              </Col>
                            </Row>
                          </TabPane>
                        </TabContent> */}
                      {/* </Form> */}
                    </div>
                  </Col>
                </Row>
              </CardBody>
            </Card>
            <Card>
              <CardBody>
                {activeTab === "0" ? (
                  <div>
                    {/* <LocationRadioComponents /> */}
                    <div className="mb-3"> 
                      <div className="d-flex  mb-3 flex-wrap">
                        <Label style={{ paddingRight: "20px" }}>Location</Label>
                        <div
                          className="btn-group padding-l"
                          role="group"
                          aria-label="Basic radio toggle button group"
                        >
                          <input
                            type="radio"
                            className="btn-check"
                            name="options"
                            id="Branch"
                            autoComplete="off"
                            checked={selectedOption === "Branch"}
                            onChange={() => handleOptionChange("Branch")}
                          />
                          <label
                            className={`btn btn-outline-primary me-4 ${
                              selectedOption === "Branch" ? "active" : ""
                            }`}
                            htmlFor="Branch"
                          >
                            Branch
                          </label>

                          <input
                            type="radio"
                            className="btn-check"
                            name="options"
                            id="Field"
                            autoComplete="off"
                            checked={selectedOption === "Field"}
                            onChange={() => handleOptionChange("Field")}
                          />
                          <label
                            className={`btn btn-outline-primary me-4 ${
                              selectedOption === "Field" ? "active" : ""
                            }`}
                            htmlFor="Field"
                          >
                            Field
                          </label>
                        </div>
                      </div>
                      {show && (
                        <div className="d-flex flex-wrap">
                          <Label style={{ paddingRight: "20px" }}>Tour Location</Label>
                          <div
                            className="btn-group pl-14px"
                        
                            role="group"
                            aria-label="Basic radio toggle button group"
                          >
                            <input
                              type="radio"
                              className="btn-check"
                              name="options"
                              id="WithinCity"
                              autoComplete="off"
                              checked={selectedOption1 === "Within City"}
                              onChange={() => handleOptionChange1("Within City")}
                            />
                            <label
                              className={`btn btn-outline-primary me-4 ${
                                selectedOption1 === "Within City" ? "active" : ""
                              }`}
                              htmlFor="WithinCity"
                            >
                              Within City
                            </label>

                            <input
                              type="radio"
                              className="btn-check"
                              name="options"
                              id="Tour"
                              autoComplete="off"
                              checked={selectedOption1 === "Tour"}
                              onChange={() => handleOptionChange1("Tour")}
                            />
                            <label
                              className={`btn btn-outline-primary me-4 ${
                                selectedOption1 === "Tour" ? "active" : ""
                              }`}
                              htmlFor="Tour"
                            >
                              Tour
                            </label>
                          </div>
                        </div>
                      )}
                      {show1 && (
                        <>
                          <Label>State</Label>
                          <Typeahead
                            id="stateId" 
                            options={stateList || []}
                            placeholder="Select state..."
                            filterBy={["Name"]}
                            labelKey={(stateList) => `${stateList?.Name}`}
                            selected={selected}
                            onChange={handleChangeState}
                            clearButton
                          />
                          {errors.stateId ? (<p className="form-error">{errors.stateId}</p>) : null}
                          <Label>City</Label>
                          <Typeahead
                            id="cityId" 
                            options={citiesList || []}
                            placeholder="Select city..."
                            filterBy={["cityName"]}
                            labelKey={(citiesList) => `${citiesList?.cityName}`}
                            selected={selectedCity}
                            onChange={handleChangeCity}
                            onBlur={handleBlur}
                            clearButton
                          />    
                          {errors.cityId  ? (<p className="form-error">{errors.cityId}</p>) : null}   
                        </>
                      )}
                    </div>
                    <Col md="12">
                      <FormGroup>
                        <Label>Mode</Label>
                        <Input 
                          type="select" 
                          className="form-select"
                          id="mode" 
                          name="mode" 
                          value={values?.mode}
                          onChange = {handleChange}
                        >
                          <option>{"--Select--"}</option>
                          <option>{"Phone call"}</option>
                          <option>{"Virtual meeting"}</option>
                          <option>{"In person"}</option>
                        </Input>
                      </FormGroup>
                    </Col>
                    <Col md="12">
                      {/* <FormGroup>
                        <Label>Start Time</Label>
                        <Input 
                        type="datetime-local" 
                        placeholder="time" 
                        id="startTime" 
                        name="startTime" 
                        value={values?.startTime}
                        onChange = {handleChange}
                        // max={new Date().toISOString().slice(0, 16)}
                        // onBlur={handleBlur}
                      />
                      {errors.startTime ? (<p className="form-error">{errors.startTime}</p>) : null}
                      </FormGroup> */}
                       {/* <FormGroup>
                        <Label>Start Time</Label>
                        <div> */}
                        <TimePickerCommon setTimeValues={setTimeValues}/>
                        {/* <input className="form-control" ref={inputRef} /> */}
                        {/* </div>
                        </FormGroup> */}
                    </Col>                 
                  
                    {/* <Col md="12"> */}
                      {/* <FormGroup>
                        <Label>End Time</Label>
                        <Input 
                        type="datetime-local" 
                        placeholder="time" 
                        id="endTime" 
                        name="endTime" 
                        value={values?.endTime}
                        onChange = {handleChange}
                        // max={new Date().toISOString().slice(0, 16)}
                        // onBlur={handleBlur}
                      />
                      {errors.endTime ? (<p className="form-error">{errors.endTime}</p>) : null}
                      </FormGroup> */}
                      {/* <FormGroup>
                      <Label>End Time</Label>
                        <div>
                        <TimePickerCommon/>
                        </div>
                        </FormGroup> */}
                    {/* </Col> */}

                    <Col md="12">
                      <Label>Notes</Label>
                      <textarea
                        className="form-control"
                        rows={3}
                        placeholder=""
                        id="notes" 
                        name="notes" 
                        value={values?.notes}
                        onChange = {handleChange}
                      />
                    </Col>
                    <Row className="Opportunity mt-3">
                      <Col xs="4" md="4">
                        <div>
                          <span
                            className={
                              activeTab1 === "1"
                                ? "active btn btn-outline-primary"
                                : "btn btn-outline-primary"
                            }
                            onClick={() => {
                              toggle1("1");
                            }}
                          >
                            Exploration
                          </span>
                        </div>
                      </Col>
                      <Col xs="4" md="4">
                        <div>
                          <span
                            className={
                              activeTab1 === "2"
                                ? "active btn btn-outline-primary"
                                : "btn btn-outline-primary"
                            }
                            onClick={() => {
                              toggle1("2");
                            }}
                          >
                            Lead
                          </span>
                        </div>
                      </Col>
                      <Col xs="4" md="4">
                        <div>
                          <span
                            className={
                              activeTab1 === "3"
                                ? "active btn btn-outline-primary"
                                : "btn btn-outline-primary"
                            }
                            onClick={() => {
                              toggle1("3");
                            }}
                          >
                            Win
                          </span>
                        </div>
                      </Col>
                    </Row>
                  </div>
                ) : (
                  ""
                )}

                <CardFooter className="text-end">
                  {/* <Link to={`${process.env.PUBLIC_URL}/add-new-opportunity`}> */}
                    <Btn color="primary" type="submit" disabled={disableWorkingStatus} onClick={handleSubmit}>
                      Submit
                    </Btn>
                  {/* </Link> */}
                  <Btn
                    className="btn btn-light"
                    type="reset"
                    style={{ marginLeft: "10px" }}
                    onClick={handleCancel}
                    disabled={disableWorkingStatus}
                  >
                    Cancel
                  </Btn>
                </CardFooter>
              </CardBody>
            </Card>
          </Form>
        </Col>
      </Row>
    </div>
  );
};

export default AddNewMeetingComponents;
