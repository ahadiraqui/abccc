import React, { useState } from "react";
import { FormGroup, Label } from "reactstrap";
import { Typeahead } from "react-bootstrap-typeahead";
import "react-bootstrap-typeahead/css/Typeahead.css";


const IcData = ["Abc Capital Inc", "PTC India", "Ic Insurance", "TYA Broking Inc"];


const BrokerNames = () => {
  const [selected, setSelected] = useState<string[]>([]);

  const handleSelectedChange = (selectedOptions: any[]) => {
    const selectedNames = selectedOptions.map(option => option.name);
    setSelected(selectedNames);
  };

  return (
    <FormGroup>
      <Label>Broker Name</Label>
      <Typeahead
        id="state-autocomplete"
        options={IcData.map(name => ({ name }))}
        labelKey="name"
        placeholder="Broker Name"
        selected={selected.map(name => ({ name }))}
        onChange={handleSelectedChange}
      />
    </FormGroup>
  );
};

export default BrokerNames;
