import React, { useState, ChangeEvent } from 'react';

function formatNumberWithSeparator(number: number): string {
  return number.toLocaleString('en-IN');
}

function convertNumberToWords(number: number): string {
  const ones = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];
  const tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
  const teens = ['ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];

  if (number === 0) {
    return 'zero';
  }

  if (number < 10) {
    return ones[number];
  }

  if (number < 20) {
    return teens[number - 10];
  }

  if (number < 100) {
    return tens[Math.floor(number / 10)] + (number % 10 !== 0 ? '-' + ones[number % 10] : '');
  }

  if (number < 1000) {
    return ones[Math.floor(number / 100)] + ' hundred ' + convertNumberToWords(number % 100);
  }

  if (number < 100000) {
    return convertNumberToWords(Math.floor(number / 1000)) + ' thousand ' + convertNumberToWords(number % 1000);
  }

  if (number < 10000000) {
    return convertNumberToWords(Math.floor(number / 100000)) + ' lakh ' + convertNumberToWords(number % 100000);
  }

  if (number < 1000000000) {
    return convertNumberToWords(Math.floor(number / 10000000)) + ' crore ' + convertNumberToWords(number % 10000000);
  }

  return 'Number too large';
}

const NumberConverter: React.FC = () => {
  const [inputValue, setInputValue] = useState<string>('');
  const [formattedNumber, setFormattedNumber] = useState<string>('');
  const [numberInWords, setNumberInWords] = useState<string>('');

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>): void => {
    const { value } = e.target;
    setInputValue(value);

    // Format the input value with separator
    const formatted = formatNumberWithSeparator(parseInt(value, 10));
    setFormattedNumber(formatted);

    // Convert input value to words
    const words = convertNumberToWords(parseInt(value, 10));
    setNumberInWords(words);
  };

  return (
    <div>
      <label>Enter Number:</label>
      <input type="text" value={formattedNumber} onChange={handleInputChange} />
      <p>Number in Words: {numberInWords}</p>
    </div>
  );
};

export default NumberConverter;
