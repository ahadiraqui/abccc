import React, { useState } from "react";
import { FormGroup, Label } from "reactstrap";
import { Typeahead } from "react-bootstrap-typeahead";
import "react-bootstrap-typeahead/css/Typeahead.css";


const AgentNamesDate = ["Sachin Mahale", "Sontosh Kale", "Pankaj Raut", "Aniket Pande", "Datta Patil", "Dipika Pawar"];


const AgentNames = () => {
  const [selected, setSelected] = useState<string[]>([]);

  const handleSelectedChange = (selectedOptions: any[]) => {
    const selectedNames = selectedOptions.map(option => option.name);
    setSelected(selectedNames);
  };

  return (
    <FormGroup>
      <Label>Agent Name</Label>
      <Typeahead
        id="state-autocomplete"
        options={AgentNamesDate.map(name => ({ name }))}
        labelKey="name"
        placeholder="Agent Name"
        selected={selected.map(name => ({ name }))}
        onChange={handleSelectedChange}
      />
    </FormGroup>
  );
};

export default AgentNames;
