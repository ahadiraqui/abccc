import React, { useState } from "react";
import { FormGroup, Label } from "reactstrap";
import { Typeahead } from "react-bootstrap-typeahead";
import "react-bootstrap-typeahead/css/Typeahead.css";


const IcData = ["Pune", "Mumbai", "Nashik", "Thane"];


const UnderwrittingOfficeLocation = () => {
  const [selected, setSelected] = useState<string[]>([]);

  const handleSelectedChange = (selectedOptions: any[]) => {
    const selectedNames = selectedOptions.map(option => option.name);
    setSelected(selectedNames);
  };

  return (
    <FormGroup>
      <Label>Underwritting Office Location</Label>
      <Typeahead
        id="state-autocomplete"
        options={IcData.map(name => ({ name }))}
        labelKey="name"
        placeholder="Location"
        selected={selected.map(name => ({ name }))}
        onChange={handleSelectedChange}
      />
    </FormGroup>
  );
};

export default UnderwrittingOfficeLocation;
