import { Col, Input, Label } from 'reactstrap';
import { H6 } from '../../../../AbstractElements';

const PresentationRadio = () => {
  return (
    <Col xl="4" sm="6">
      <div className="checkbox-checked d-flex gap-3">        
        <div className="form-check radio radio-primary">
          <Input id="radio11" type="radio" name="radioGroup" defaultChecked />
          <Label for="radio11" check>Yes</Label>
        </div>
        <div className="form-check radio radio-primary">
          <Input id="radio22" type="radio" name="radioGroup" />
          <Label for="radio22" check>No</Label>
        </div>     
      </div>
    </Col>
  );
};

export default PresentationRadio;
