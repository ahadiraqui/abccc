import React, { useState } from "react";
import { FormGroup, Label } from "reactstrap";
import { Typeahead } from "react-bootstrap-typeahead";
import "react-bootstrap-typeahead/css/Typeahead.css";


const Person = ["Sachin Mahale", "Sontosh Kale", "Pankaj Raut", "Aniket Pande", "Datta Patil", "Dipika Pawar"];


const ContactPerson = () => {
  const [selected, setSelected] = useState<string[]>([]);

  const handleSelectedChange = (selectedOptions: any[]) => {
    const selectedNames = selectedOptions.map(option => option.name);
    setSelected(selectedNames);
  };

  return (
    <FormGroup>
      <Label>Contact Person Name</Label>
      <Typeahead
        id="state-autocomplete"
        options={Person.map(name => ({ name }))}
        labelKey="name"
        placeholder="Contact Person"
        selected={selected.map(name => ({ name }))}
        onChange={handleSelectedChange}
      />
    </FormGroup>
  );
};

export default ContactPerson;
