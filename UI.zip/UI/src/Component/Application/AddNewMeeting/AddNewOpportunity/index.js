import { useEffect, useRef, useState } from "react";

import {
  Card,
  CardBody,
  CardFooter,
  Col,
  Form,
  FormGroup,
  Input,
  Label,
  Row
} from "reactstrap";
import { Btn, H6 } from "../../../../AbstractElements";
import Corporate from "./AutoSelectDropdown";
import NumberConverter from "./NumberConverter";
import PresentationRadio from "./PresentationRadio";
import RadioButton from "./Radio";
import dayjs from "dayjs";
import moment from "moment";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import "./style.scss";
import CorporatSection from "./CorporatSection";
import AutoCompleteCity from "../../../../CommonElements/AutoCompleteSelectBox/AutoCompleteCity";
import AutocompleteSelect from "../../../../CommonElements/AutoCompleteSelectBox";
import IcNames from "./IcNames";
import UnderwrittingOfficeLocation from "./UnderwrittingOfficeLocation";
import ICSection from "./ICSection";
import BrokerNames from "./BrokerNames";
import BrokerLocation from "./BrokerLocation.1";
import AgentNames from "./AgentNames";
import AgentSection from "./AgentSection";
import AggregatgorNames from "./AggregatgorNames";
import AggregatgorSection from "./AggregatgorSection";
import IndianNumberConverter from "./AmountSeperator";
import { useAppDispatch, useAppSelector } from "../../../../ReduxToolkit/Hooks";
import { useFormik } from "formik";
import { getBelongsToEntityList, getBelongsToEntityListForOpportunity, getCitiesList, getEmployees, getOfficeLocation, getStateList, setStateFlag } from "../../../../ReduxToolkit/Reducers/CommonSlice";
import { Typeahead } from "react-bootstrap-typeahead";
import { AddUpdateOpportunity, getOpportunityById, setAmountSeparatorValue, setClearValuesAmountFlag, setOpportunityDataById, setOpportunityEditFlag, setOpportunityFlag, setOpportunityId } from "../../../../ReduxToolkit/Reducers/OpportunityAction";
import { getLatestMeeting } from "../../../../ReduxToolkit/Reducers/MeetingAction";
import utc from 'dayjs/plugin/utc'; // Import UTC plugin
import { getContactInformationList } from "../../../../ReduxToolkit/Reducers/ContactSlice";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { getHeaders } from "../../../../Api/apiUtils";
// dayjs.extend(utc);

const CorporateData = [
  "New Inc",
  "ABC Limited",
  "Broking company Ltd",
  "RTS Insurance Inc",
  "New Inc",
  "ABC Limited",
  "Broking company Ltd",
  "RTS Insurance Inc",
  "RTS Insurance Inc",
  "Unknown"
];
export const AddNewOpportunity = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const userData = useAppSelector((state)=> state.menuAction.userData);
  const roles = userData?.role?.split(",");

  const meetingAction = useAppSelector((state)=>state.meetingAction);
  const opportunityTab = meetingAction?.opportunityTab;
  const selectedMeetingDate = meetingAction?.selectedMeetingDate;
  const latestMeetingId = meetingAction?.latestMeetingId;
  
  const commonAction = useAppSelector((state)=>state.commonAction);
  const stateList = commonAction.stateList;
  const citiesList = commonAction.citiesList;
  const belongsToList = commonAction.belongsToList;
  const currentInsuranceCompanyList = commonAction.currentInsuranceCompanyList;
  const currentBrokerList = commonAction.currentBrokerList;
  const currentTPAList = commonAction.currentTPAList;
  const employeeList = commonAction.employeeList;
  const officeList = commonAction.officeList;
  // const stateFlag = commonAction.stateFlag;

  const contactAction = useAppSelector((state)=>state.contact);
  const contactInformationList = contactAction.contactInformationList;

  const opportunityAction = useAppSelector((state)=>state.opportunityAction);
  const opportunityId = opportunityAction.opportunityId;
  const opportunityEditFlag = opportunityAction.opportunityEditFlag;
  const opportunityDataByIdList = opportunityAction.opportunityDataById ;
  const opportunityDataById = opportunityDataByIdList?.length > 0 && opportunityDataByIdList[0] ;
  const opportunityFlag = opportunityAction.opportunityFlag;
  
  const [selected,setSelected] = useState([]);
  const [selectedCity,setSelectedCity] = useState([]);
  const [selectedBelongsTo,setSelectedBelongsTo] = useState([]);
  const [selectedSourceState,setSelectedSourceState] = useState([]);
  const [selectedSourceCity,setSelectedSourceCity] = useState([]);
  const [selectedCurrentInsuranceCompany,setSelectedCurrentInsuranceCompany] = useState([]);
  const [selectedCurrentBroker,setSelectedCurrentBroker] = useState([]);
  const [selectedCurrentTPA,setSelectedCurrentTPA] = useState([]);
  const [selectedEmployee,setSelectedEmployee] = useState([]);
  const [selectedOffice,setSelectedOffice] = useState([]);
  const [selectedContact,setSelectedContact] = useState([]);

  const [selectedDate, setSelectedDate] = useState(dayjs());
  const [selectedPresentationDate, setSelectedPresentationDate] = useState(dayjs());
  const [activeTab3, setActiveTab3] = useState("1");
  // const toggle3 = tab3 => {
  //   if (activeTab3 !== tab3) setActiveTab3(tab3);
  // };
  // console.log("selectedMeetingDate",selectedMeetingDate,selectedDate.toDate());
  const handleDateChange = date => {
    setSelectedDate(date);
    setFieldValue("date",date?.format('YYYY-MM-DDTHH:mm:ss.SSSZ'))
  };

  const handlePresentationDateChange = date => {
    setSelectedPresentationDate(date);
    setFieldValue("presentationDate",date?.format('YYYY-MM-DDTHH:mm:ss.SSSZ'))
  };

  useEffect(()=>{
    if(selectedMeetingDate !=null)
    {
      // handleDateChange(selectedMeetingDate);
      setSelectedDate(dayjs(selectedMeetingDate));
    }
  },[selectedMeetingDate])

  useEffect(()=>{
    if(opportunityFlag === 3)
    {
      if(roles[0] === "System Handler")
      {
        navigate(`${process.env.PUBLIC_URL}/blank-field-report`);
      }
      else
      {
        navigate(`${process.env.PUBLIC_URL}/app/calender`);
      }
    }
  },[opportunityFlag])

  useEffect(()=>{
    // dispatch(getLatestMeeting());
    // setSelected([]);
    // setSelectedCity([]);
    // setSelectedBelongsTo([]);
    // setSelectedSourceState([]);
    // setSelectedSourceCity([]);
    // setSelectedCurrentInsuranceCompany([]);
    // setSelectedCurrentBroker([]);
    // setSelectedCurrentTPA([]);
    // setSelectedEmployee([]);
    // setSelectedOffice([]);
    // setSelectedContact([]);
    dispatch(setClearValuesAmountFlag(true));
    dispatch(getStateList());
    dispatch(getBelongsToEntityListForOpportunity("Insurance Company"))
    dispatch(getBelongsToEntityListForOpportunity("Broker"))
    dispatch(getBelongsToEntityListForOpportunity("TPA"))
  },[])

  useEffect(()=>{
    if(opportunityId)
    {
      dispatch(getOpportunityById(opportunityId))
    }
  },[opportunityId])
  // console.log("opportunityId",opportunityId)
  const [sourceCityList,setSourceCityList] = useState([]);
  const getSourceCityListOnEdit = async (stateID) => {
    try 
    {
      const response = await axios.get(`${process.env.REACT_APP_BASEURL}/api/Contact/GetCities?StateId=${stateID}`,getHeaders());
      const data = response?.data?.responseObject;
      setSourceCityList(data);
    } 
    catch (error) 
    {
        console.error("Error fetching cities:", error);
    }
  };
  useEffect(()=>{
    if(opportunityDataByIdList?.length>0 && opportunityFlag == 1)
    {
      dispatch(setOpportunityFlag(2));
      const dates = opportunityDataById?.OpportunityDate?.split("T")||null;
      setSelectedDate(dayjs(dates[0]||null));

      const presentDates = opportunityDataById?.PresentationDate?.split("T")||null;
      setSelectedPresentationDate(dayjs(presentDates[0]||null));

      setFieldValue("corporate",opportunityDataById?.CorporateName);
      setFieldValue("address",opportunityDataById?.CorporateAddress);
      setFieldValue("location",opportunityDataById?.CorporateLocation);

      setFieldValue("stateId",opportunityDataById?.CorporateStateid);
      dispatch(getCitiesList(opportunityDataById?.CorporateStateid));
      const selectedState = stateList?.find((item) => item.StateId === opportunityDataById?.CorporateStateid) || null
      if(selectedState) {
        const newArray = [ ...selected, selectedState ];
        setSelected(newArray);
      }

      setFieldValue("cityId",opportunityDataById?.CorporateCityid);
      setFieldValue("currentInsuranceCompanyId",opportunityDataById?.CurrentInsuranceCompanyId);
      setFieldValue("currentBrokerId",opportunityDataById?.CurrentBrokerId);
      setFieldValue("currentTPAId",opportunityDataById?.CurrentTPAId);
      const currentICFound = currentInsuranceCompanyList?.find((item) => item?.InsuranceCompanyId === opportunityDataById?.CurrentInsuranceCompanyId) || null;
      if(currentICFound) {
        const newArray = [ ...selectedCurrentInsuranceCompany, currentICFound ];
        setSelectedCurrentInsuranceCompany(newArray);
      }
      const currentBrokerFound = currentBrokerList?.find((item) => item?.BrokerId === opportunityDataById?.CurrentBrokerId) || null;
      if(currentBrokerFound) {
        const newArray = [ ...selectedCurrentBroker, currentBrokerFound ];
        setSelectedCurrentBroker(newArray);
      }
      const currentTPAFound = currentTPAList?.find((item) => item?.TPAId === opportunityDataById?.CurrentTPAId) || null;
      if(currentTPAFound) {
        const newArray = [ ...selectedCurrentTPA, currentTPAFound ];
        setSelectedCurrentTPA(newArray);
      }
      
      setFieldValue("premium",opportunityDataById?.Premium);
      setFieldValue("premiumAmountInWords",opportunityDataById?.PremiumAmountinWords);
      setFieldValue("TPAFeesPercentage",opportunityDataById?.TPAFeePercentage);
      setFieldValue("TPAFeesAmount",opportunityDataById?.TPAFee);
      setFieldValue("TPAFeesAmountInWords",opportunityDataById?.TPAFeeAmountinWords);
      const amountValues = {
        premium : opportunityDataById?.Premium,
        premiumAmountInWords : opportunityDataById?.PremiumAmountinWords,
        TPAFeesPercentage : opportunityDataById?.TPAFeePercentage,
        TPAFeesAmount : opportunityDataById?.TPAFee,
        TPAFeesAmountInWords : opportunityDataById?.TPAFeeAmountinWords
      }
      dispatch(setAmountSeparatorValue(amountValues));

      toggle1(getConfidenceNumber(opportunityDataById?.CurrentConfidenceLevel));
      setFieldValue("influencerRequired",opportunityDataById?.IfInfluencerRequired == true ? "Yes" : "No")
      opportunityDataById?.IfInfluencerRequired == true && dispatch(getEmployees('employee',null,'only influencers'))
      setFieldValue("presentationRequired",opportunityDataById?.PresentationRequired == true ? "Yes" : "No")
      setFieldValue("presentationMode",opportunityDataById?.PresentationMode);
      setFieldValue("sourceType",opportunityDataById?.SourcedBy);
      if(opportunityDataById?.SourcedBy === "Broker" || opportunityDataById?.SourcedBy === "Aggregator" || opportunityDataById?.SourcedBy=== "Insurance Company")
      {
        dispatch(getBelongsToEntityList(opportunityDataById?.SourcedBy,null,null,null,null));
      }
      setFieldValue("sourcestateId",opportunityDataById?.sourceStateId);
      opportunityDataById?.sourceStateId > 0 && getSourceCityListOnEdit(opportunityDataById?.sourceStateId);
      const sourceStateFound = stateList?.find((item) => item.StateId === opportunityDataById?.sourceStateId) || null
      if(sourceStateFound) {
        const newArray = [ ...selectedSourceState, sourceStateFound ];
        setSelectedSourceState(newArray);
      }
      setFieldValue("sourcecityId",opportunityDataById?.sourceCityId);
      setFieldValue("contactId",opportunityDataById?.ContactId);
    }
  },[opportunityDataById])

  useEffect(()=>{
    if(citiesList.length>0 && opportunityDataById && opportunityEditFlag == true)
    {
      const selectedCityFind = citiesList?.find((item) => item.cityId === opportunityDataById?.CorporateCityid) || null;
      if(selectedCityFind)
      {const newArray = [ ...selectedCity, selectedCityFind ];
      setSelectedCity(newArray);}
    }
  },[citiesList])

  useEffect(()=>{
    if(sourceCityList.length>0 && opportunityDataById && opportunityEditFlag == true && opportunityDataById?.sourceStateId > 0)
    {
      const selectedCityFind = sourceCityList?.find((item) => item.cityId === opportunityDataById?.sourceCityId) || null;
      if(selectedCityFind)
      {const newArray = [ ...selectedSourceCity, selectedCityFind ];
      setSelectedSourceCity(newArray);}
    }
  },[sourceCityList])

  useEffect(()=>{
    if(belongsToList.length>0 && opportunityDataById && opportunityEditFlag == true)
    {
      if (opportunityDataById?.SourcedBy == "Aggregator") {
        const list = belongsToList?.find((item) => item.AggregatorId == opportunityDataById?.ContactAggregatorId) || null;
        if(list) {
          const newArray = [ ...selectedBelongsTo, list ];
          setSelectedBelongsTo(newArray);
          setFieldValue("sourceId",opportunityDataById?.ContactAggregatorId);
          dispatch(getContactInformationList("Aggregator",opportunityDataById?.ContactAggregatorId,null))
        }
      }else if (opportunityDataById?.SourcedBy == "Broker") {
        const list = belongsToList?.find((item) => item.BrokerId == opportunityDataById?.ContactBrokerId) || null;
        if(list) {
          const newArray = [ ...selectedBelongsTo, list ];
          setSelectedBelongsTo(newArray);
          setFieldValue("sourceId",opportunityDataById?.ContactBrokerId);
          dispatch(getOfficeLocation("broker office",null,"load offices",opportunityDataById?.ContactBrokerId,null))
          dispatch(getContactInformationList("Broker",opportunityDataById?.ContactBrokerId,null))
        }
      }else if (opportunityDataById?.SourcedBy == "Insurance Company") {
        const list = belongsToList?.find((item) => item.InsuranceCompanyId == opportunityDataById?.ContactInsuranceCompanyId) || null;
        if(list) {
          const newArray = [ ...selectedBelongsTo, list ];
          setSelectedBelongsTo(newArray);
          setFieldValue("sourceId",opportunityDataById?.ContactInsuranceCompanyId);
          dispatch(getOfficeLocation("insurance company office",null,"load offices",opportunityDataById?.ContactInsuranceCompanyId,null))
          dispatch(getContactInformationList("Insurance Company",opportunityDataById?.ContactInsuranceCompanyId,null))
        }
      }
    }
  },[belongsToList])

  useEffect(()=>{
    if(opportunityDataById?.IfInfluencerRequired == true && employeeList)
    {
      const EmployeeFound = employeeList?.find((item) => item.EmployeeId === opportunityDataById?.ifInfluencerEmployeeid) || null;
      if(EmployeeFound) {
        const newArray = [ ...selectedEmployee, EmployeeFound ];
        setSelectedEmployee(newArray);
        setFieldValue("employeeId",EmployeeFound?.EmployeeId);
      }
    }
  },[employeeList])

  useEffect(()=>{
    if(contactInformationList && contactInformationList?.length>0 && opportunityDataById && opportunityEditFlag == true)
    {
      const ContactFound = contactInformationList?.find((item) => item.ContactId === opportunityDataById?.ContactId) || null;
      if(ContactFound)
      {const newArray = [ ...selectedContact, ContactFound ];
      setSelectedContact(newArray);}
    }
  },[contactInformationList])

  useEffect(()=>{
    if( officeList && officeList?.length>0 && opportunityDataById && opportunityEditFlag == true)
    {
      if(values?.sourceType === "Broker")
      {
        const OfficeFound = officeList?.find((item) => item.BrokerOfficeId === opportunityDataById?.sourceBrokerOfficeId) || null;
        if(OfficeFound)
        {const newArray = [ ...selectedOffice, OfficeFound ];
        setSelectedOffice(newArray);}
        setFieldValue("underwrittingOfficeLocationId",opportunityDataById?.sourceBrokerOfficeId);
      }
      else if(values?.sourceType === "Insurance Company")
      {
        const OfficeFound = officeList?.find((item) => item.InsuranceCompanyOfficeId === opportunityDataById?.sourceInsuranceCompanyOfficeId) || null;
        if(OfficeFound)
        {const newArray = [ ...selectedOffice, OfficeFound ];
          setSelectedOffice(newArray);}
          setFieldValue("underwrittingOfficeLocationId",opportunityDataById?.sourceInsuranceCompanyOfficeId);
      }
    }
  },[officeList])

  const [activeTab, setActiveTab] = useState("1");
  const toggle = tab => {
    if (activeTab !== tab) setActiveTab(tab);
  };
  const [activeTab1, setActiveTab1] = useState("1");
  const toggle1 = tab1 => {
    if (activeTab1 !== tab1) {
      setActiveTab1(tab1);
      setFieldValue("confidenceLevel",tab1);
    }
  };

  const [selectedOption, setSelectedOption] = useState("--Select--");

  const handleSelectChange = e => {
    setSelectedOption(e.target.value);
  };

  useEffect(()=>{
    setActiveTab(opportunityTab)
  },[opportunityTab]);

  const getStageName = (stage)=>{
    if(stage === "1")
    {
      return "Exploration"
    }
    else if(stage === "2")
    {
      return "Lead"
    }
    else if(stage === "3")
    {
      return "Win"
    }
  }

  const getConfidenceLevel = (level)=>{
    if(level === "1")
    {
      return "High"
    }
    else if(level === "2")
    {
      return "Average"
    }
    else if(level === "3")
    {
      return "Low"
    }
    else if(level === "4")
    {
      return "Not Known"
    }
    else if(level === "5")
    {
      return "No Go"
    }
  }

  const getConfidenceNumber = (level)=>{
    if(level === "High")
    {
      return "1"
    }
    else if(level === "Average")
    {
      return "2"
    }
    else if(level === "Low")
    {
      return "3"
    }
    else if(level === "Not Known")
    {
      return "4"
    }
    else if(level === "No Go")
    {
      return "5"
    }
  }

  const {values,setFieldValue,handleChange,handleSubmit,errors,touched,resetForm,handleBlur,setFieldError,setFieldTouched} = useFormik({
    initialValues: {
      date:'',
      corporate:'',
      address:'',
      location:'',
      stateId:0,
      cityId:0,
      currentInsuranceCompanyId:0,
      currentBrokerId:0,
      currentTPAId:0,
      premium:0,
      premiumAmountInWords:'',
      TPAFeesPercentage : 0,
      TPAFeesAmount :0,
      TPAFeesAmountInWords :'',
      confidenceLevel : '',
      influencerRequired:'',
      employeeId : 0,
      presentationRequired : '',
      presentationDate : '',
      presentationMode:'',
      sourceType:'',
      sourceId :0,
      sourcestateId:0,
      sourcecityId:0,
      underwrittingOfficeLocationId : 0,
      contactId :0,
      moveTo : null
    },
    // validationSchema : validationSchema,
    onSubmit: (values,action) => {
      const stage = getStageName(activeTab);
      const confidenceLevelValue = getConfidenceLevel(activeTab1)
      console.log("stage",stage,confidenceLevelValue);
      // alert(JSON.stringify(values, null, 2));
      const payload = {
        opportunityGuid : opportunityEditFlag == true ? opportunityId ||null : null,
        meetingId: opportunityEditFlag == true ? opportunityDataById?.MeetingId : latestMeetingId, // need to change (last saved meeting)
        currentMeetingId: opportunityEditFlag == true ? opportunityDataById?.CurrentMeetingId : latestMeetingId, // need to change = meetingId:
        // applicationUserId: 1, // need to change (loggedin user id)
        opportunityDate: opportunityEditFlag == true ? opportunityDataById?.OpportunityDate : selectedDate.format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
        stage: stage === "Win" ? "Close" : stage, // ask //'exploration' or 'lead' or 'close' in case of win
        currentStage: stage === "Win" ? "Close" : stage, // ask stage:
        opportunityStatus: (stage === "Exploration" || stage === "Lead") ? null : stage, // if stage = exploration or lead then null or if stage = win or lost then stage 
        currentStageDate: opportunityEditFlag == true ? moment().format('YYYY-MM-DDTHH:mm:ss.SSS[Z]') : selectedDate.format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
        policyId: null, //always
        corporateName: values?.corporate, 
        corporateAddress: values?.address,
        corporateLocation: values?.location.length>0 ? values?.location : null,
        corporateCityid: values?.cityId > 0 ? values?.cityId : null,
        corporateStateid: values?.stateId>0 ? values?.stateId : null,
        corporateCountryid: 1,
        currentInsuranceCompanyId: values?.currentInsuranceCompanyId > 0 ? values?.currentInsuranceCompanyId : null,
        currentBrokerId: values?.currentBrokerId>0 ? values?.currentBrokerId : null,
        currentTPAId: values?.currentTPAId>0 ? values?.currentTPAId : null,
        premium: values?.premium || null, //set null if applicable
        premiumAmountinWords: values?.premiumAmountInWords || null,
        tpaFeePercentage: values?.TPAFeesPercentage || null, //set null if applicable
        tpaFee: values?.TPAFeesAmount || null, //set null if applicable
        tpaFeeAmountinWords: values?.TPAFeesAmountInWords || null,
        confidenceLevel: confidenceLevelValue || null, //ask //set null if applicable
        currentConfidenceLevel: confidenceLevelValue, //ask confidenceLevel:
        ifInfluencerRequired: values?.influencerRequired === "Yes" ? true : false,
        ifInfluencerApplicationUserId: null, // ask this question or remove
        ifInfluencerEmployeeid: values?.employeeId > 0 ? values?.employeeId : null,
        presentationRequired: values?.presentationRequired === "Yes" ? true : false,
        presentationDate: values?.presentationDate || selectedPresentationDate.format('YYYY-MM-DDTHH:mm:ss.SSS[Z]') || null,
        presentationMode : values?.presentationMode,
        sourcedBy: values?.sourceType?.length > 0 ? values?.sourceType : null,
        contactId: values?.contactId > 0 ? values?.contactId : selectedContact?.length>0 ? selectedContact[0]?.ContactId : null,
        corporateId: null,
        brokerId: (values?.sourceType==="Broker" && values?.sourceId>0) ? values?.sourceId : null,
        insuranceCompanyId: (values?.sourceType==="Insurance Company" && values?.sourceId>0) ? values?.sourceId : null,
        agentId: (values?.sourceType==="Agent" && values?.sourceId>0) ? values?.sourceId : null,
        aggregatorId: (values?.sourceType==="Aggregator" && values?.sourceId>0) ? values?.sourceId : null,
        sourceStateId : values?.sourcestateId>0 ? values?.sourcestateId : null,
        sourceCityId : values?.sourcecityId>0 ? values?.sourcecityId : null,
        sourceInsuranceCompanyOfficeId : (values?.sourceType==="Insurance Company" && values?.underwrittingOfficeLocationId>0) ? values?.underwrittingOfficeLocationId : null,
        sourceBrokerOfficeId : (values?.sourceType==="Broker" && values?.underwrittingOfficeLocationId>0) ? values?.underwrittingOfficeLocationId : null,
        moveTo : values?.moveTo
        // currentlyAssignedToApplicationUserId: 1, //(loggedin user id)
        // currentlyAssignedByApplicationUserId: 1, //(loggedin user id)
        // currentlyAssignedDateTimeStamp: 2024-06-06T07:11:43.229Z,
        // recordStatus: string,
        // createdDateTimeStamp: 2024-06-06T07:11:43.229Z,
        // createdByUserId: 1,
        // lastModifiedDateTimeStamp: 2024-06-06T07:11:43.229Z,
        // lastModifiedByUserId: 1,
        // lastModifications: string
      }
      dispatch(AddUpdateOpportunity(payload));
      // alert(JSON.stringify(payload, null, 2));
      console.log(payload)
      action.resetForm();
      dispatch(setClearValuesAmountFlag(true));
      setSelected([]);
      setSelectedCity([]);
      setSelectedBelongsTo([]);
      setSelectedSourceState([]);
      setSelectedSourceCity([]);
      setSelectedCurrentInsuranceCompany([]);
      setSelectedCurrentBroker([]);
      setSelectedCurrentTPA([]);
      setSelectedEmployee([]);
      setSelectedOffice([]);
      setSelectedContact([]);
      dispatch(setOpportunityEditFlag(false));
      dispatch(setOpportunityId(null));
      dispatch(setOpportunityDataById([]));
      dispatch(setOpportunityFlag(null));
    },
  }); 

  const handleCancel = ()=>{
    resetForm();
    dispatch(setClearValuesAmountFlag(true));
    setSelected([]);
    setSelectedCity([]);
    setSelectedBelongsTo([]);
    setSelectedSourceState([]);
    setSelectedSourceCity([]);
    setSelectedCurrentInsuranceCompany([]);
    setSelectedCurrentBroker([]);
    setSelectedCurrentTPA([]);
    setSelectedEmployee([]);
    setSelectedOffice([]);
    setSelectedContact([]);
    dispatch(setOpportunityEditFlag(false));
    dispatch(setOpportunityId(null));
    dispatch(setOpportunityDataById([]));
    dispatch(setOpportunityFlag(null));
  }

  const setValuesAmount = (type,value)=>{
    setFieldValue(type,value);
  }

  const handleChangeState = (value) => {
    setFieldValue("stateId",value[0]?.StateId);
    setSelected(value);
    setSelectedCity([]);
    setFieldValue("cityId",0);
    dispatch(getCitiesList(value[0]?.StateId));
  };

  const handleChangeCity = (value) => {
    setFieldValue("cityId",value[0]?.cityId);
    setSelectedCity(value);
  }

  const handleChangeSourceState = (value) => {
    setFieldValue("sourcestateId",value[0]?.StateId);
    setSelectedSourceState(value);
    setSelectedSourceCity([]);
    setFieldValue("sourcecityId",0);
    dispatch(getCitiesList(value[0]?.StateId));
  };

  const handleChangeSourceCity = (value) => {
    setFieldValue("sourcecityId",value[0]?.cityId);
    setSelectedSourceCity(value);
    values?.sourceType == "Insurance Company" && dispatch(getOfficeLocation("insurance company office",value[0]?.cityId,"load offices",values?.sourceId,null))
    values?.sourceType == "Broker" && dispatch(getOfficeLocation("broker office",value[0]?.cityId,"load offices",values?.sourceId,null))
  }

  const handleChangeBelongsTo = (value)=>{
    if(value)
    {
      if(values?.sourceType == "Aggregator") {
        setFieldValue("sourceId",value[0]?.AggregatorId || null) 
        dispatch(getContactInformationList("Aggregator",value[0]?.AggregatorId || null,null))
      }
      else if(values?.sourceType == "Broker") {
        setFieldValue("sourceId",value[0]?.BrokerId || null)
        dispatch(getContactInformationList("Broker",value[0]?.BrokerId || null,null))
      }
      else if (values?.sourceType == "Corporate") { 
        setFieldValue("sourceId",value[0]?.CorporateId || null)
        dispatch(getContactInformationList("Corporate",value[0]?.CorporateId || null,null))
      }
      else if(values?.sourceType == "Agent") { 
        setFieldValue("sourceId",value[0]?.AgentId || null)
        dispatch(getContactInformationList("Agent",value[0]?.AgentId || null,null))
      }
      else if(values?.sourceType == "Insurance Company") {
        setFieldValue("sourceId",value[0]?.InsuranceCompanyId || null);
        dispatch(getContactInformationList("Insurance Company",value[0]?.InsuranceCompanyId || null,null))
      }
      setSelectedBelongsTo(value);
    }else{
      setFieldValue("sourceId",null);
      setSelectedBelongsTo([]);
    }
  }

  const handleChangeCurrentInsuranceCompany = (value) => {
    setFieldValue("currentInsuranceCompanyId",value[0]?.InsuranceCompanyId);
    setSelectedCurrentInsuranceCompany(value);
  }

  const handleChangeCurrentBroker = (value) => {
    setFieldValue("currentBrokerId",value[0]?.BrokerId);
    setSelectedCurrentBroker(value);
  }

  const handleChangeCurrentTPA = (value) => {
    setFieldValue("currentTPAId",value[0]?.TPAId);
    setSelectedCurrentTPA(value);
  }

  const handleChangeEmployee = (value)=>{
    setFieldValue("employeeId",value[0]?.EmployeeId);
    setSelectedEmployee(value);
  }

  const handleChangeOffice = (value)=>{
    values?.sourceType == "Insurance Company" && setFieldValue("underwrittingOfficeLocationId",value[0]?.InsuranceCompanyOfficeId);
    values?.sourceType == "Broker" && setFieldValue("underwrittingOfficeLocationId",value[0]?.BrokerOfficeId);
    setSelectedOffice(value);
  }

  const handleChangeContact = (value)=>{
    setFieldValue("contactId",value[0]?.ContactId);
    setSelectedContact(value);
  }
  
  useEffect(()=>{
    if(values?.influencerRequired === "Yes")
    {
      dispatch(getEmployees('employee',null,'only influencers'))
    }
  },[values?.influencerRequired])

  useEffect(()=>{
    if(values?.sourceType == "Agent")
    {
      dispatch(getContactInformationList("Agent",null,null))
    }
  },[values?.sourceType])


  return (
    <div className="page-body">
      <div className="d-flex justify-content-between mt-4 mb-1 align-items-center pt-1 pt-1">
        <div className="ps-0 col-sm-6">
          <h3 className="screen-title">{opportunityEditFlag ? "Edit Opportunity" : "Add Opportunity"}</h3>
        </div>
      </div>

      <Row>
        <Col lg="3" className="d-none d-lg-block"></Col>
        <Col lg="6">
          <Form>
            <Card>
              <CardBody>
                <H6 className="card-title">Opportunity</H6>
                <Row className="Opportunity">
                  <Col xs="4" md="4">
                    <div>
                      <span
                        className={
                          activeTab === "1"
                            ? "active btn btn-outline-primary"
                            : "btn btn-outline-primary"
                        }
                        onClick={() => {
                          if(!(opportunityTab == "2" || opportunityTab == "3"))
                            toggle("1");
                        }}
                        style={{ cursor: (opportunityTab == "2" || opportunityTab == "3") ? 'not-allowed' : 'pointer' }}
                      >
                        Exploration
                      </span>
                    </div>
                  </Col>
                  <Col xs="4" md="4">
                    <div>
                      <span
                        className={
                          activeTab === "2"
                            ? "active btn btn-outline-primary"
                            : "btn btn-outline-primary"
                        }
                        onClick={() => {
                          if(!(opportunityTab == "1" || opportunityTab == "3"))
                            toggle("2");
                        }}
                        style={{ cursor: (opportunityTab == "1" || opportunityTab == "3") ? 'not-allowed' : 'pointer' }}
                      >
                        Lead
                      </span>
                    </div>
                  </Col>
                  <Col xs="4" md="4">
                    <div>
                      <span
                        className={
                          activeTab === "3"
                            ? "active btn btn-outline-primary"
                            : "btn btn-outline-primary"
                        }
                        onClick={() => {
                          if(!(opportunityTab == "1" || opportunityTab == "2"))
                            toggle("3");
                        }}
                        style={{ cursor: (opportunityTab == "1" || opportunityTab == "2") ? 'not-allowed' : 'pointer' }}
                      >
                        Win
                      </span>
                    </div>
                  </Col>
                </Row>
                <div className="mt-4">
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DatePicker
                      className="custom-date"
                      value={selectedDate}
                      onChange={handleDateChange}
                      renderInput={props => (
                        <input {...props} variant="standard" fullWidth />
                      )}
                      format="ddd, DD MMM YYYY" // Format for the displayed date
                      disabled = {selectedMeetingDate!=null ? true : opportunityEditFlag == true ? true : false}
                    />
                  </LocalizationProvider>
                </div>

                <Row className="mt-3">
                  <Col md="12">
                    {/* <Corporate
                      title="Corporate"
                      dataItem={CorporateData}
                      placeholder="Corporate"
                    /> */}
                     <FormGroup>
                        <Label>Corporate</Label>
                        <Input 
                          type="text" 
                          // placeholder="Corporate"
                          id="corporate"
                          name="corporate"
                          value={values?.corporate}
                          onChange = {handleChange}
                        />
                      </FormGroup>
                  </Col>
                  <Col md="12">
                    <FormGroup>
                      <Label>Address</Label>
                      <Input 
                        type="text" 
                        // placeholder="Address"
                        id="address"
                        name="address"
                        value={values?.address}
                        onChange = {handleChange}
                      />
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    <FormGroup>
                      <Label>Location</Label>
                      <Input 
                        type="text" 
                        // placeholder="Location"
                        id="location"
                        name="location"
                        value={values?.location}
                        onChange = {handleChange}
                      />
                    </FormGroup>
                  </Col>
                  <Col md="12">
                  <FormGroup>
                    <Label>State</Label>
                    <Typeahead
                      id="stateId" 
                      options={stateList || []}
                      placeholder="Select state..."
                      filterBy={["Name"]}
                      labelKey={(stateList) => `${stateList?.Name}`}
                      selected={selected}
                      onChange={handleChangeState}
                      clearButton
                    />
                    {/* {errors.stateId ? (<p className="form-error">{errors.stateId}</p>) : null} */}
                    </FormGroup>
                  </Col>
                  <Col md="12">
                  <FormGroup>
                    <Label>City</Label>
                    <Typeahead
                      id="cityId" 
                      options={citiesList || []}
                      placeholder="Select city..."
                      filterBy={["cityName"]}
                      labelKey={(citiesList) => `${citiesList?.cityName}`}
                      selected={selectedCity}
                      onChange={handleChangeCity}
                      clearButton
                    />    
                    {/* {errors.cityId  ? (<p className="form-error">{errors.cityId}</p>) : null} */}
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    {/* <Corporate
                      title="Current Insurance Company"
                      dataItem={CorporateData}
                      placeholder="Insurance Company"
                    /> */}
                    <FormGroup>
                    <Label>Current Insurance Company</Label>
                    <Typeahead
                      id="currentInsuranceCompanyId" 
                      options={currentInsuranceCompanyList || []}
                      placeholder="Select current Insurance Company..."
                      filterBy={["InsuranceCompanyName"]}
                      labelKey={(currentInsuranceCompanyList) => `${currentInsuranceCompanyList?.InsuranceCompanyName}`}
                      selected={selectedCurrentInsuranceCompany}
                      onChange={handleChangeCurrentInsuranceCompany}
                      clearButton
                    />    
                    {/* {errors.currentInsuranceCompanyId  ? (<p className="form-error">{errors.currentInsuranceCompanyId}</p>) : null} */}
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    {/* <Corporate
                      title="Current Broker"
                      dataItem={CorporateData}
                      placeholder="Broker"
                    /> */}
                    <FormGroup>
                    <Label>Current Broker</Label>
                    <Typeahead
                      id="currentBrokerId" 
                      options={currentBrokerList || []}
                      placeholder="Select Current Broker..."
                      filterBy={["BrokerName"]}
                      labelKey={(currentBrokerList) => `${currentBrokerList?.BrokerName}`}
                      selected={selectedCurrentBroker}
                      onChange={handleChangeCurrentBroker}
                      clearButton
                    />    
                    {/* {errors.currentBrokerId  ? (<p className="form-error">{errors.currentBrokerId}</p>) : null} */}
                    </FormGroup>
                  </Col>
                
                  <Col md="12">
                    {/* <Corporate
                      title="Current TPA"
                      dataItem={CorporateData}
                      placeholder="Current TPA"
                    /> */}
                    <FormGroup>
                    <Label>Current TPA</Label>
                    <Typeahead
                      id="currentTPAId" 
                      options={currentTPAList || []}
                      placeholder="Select Current TPA..."
                      filterBy={["TPAName"]}
                      labelKey={(currentTPAList) => `${currentTPAList?.TPAName}`}
                      selected={selectedCurrentTPA}
                      onChange={handleChangeCurrentTPA}
                      clearButton
                      // onBlur={handleBlur}
                    />    
                    {/* {errors.currentTPAId  ? (<p className="form-error">{errors.currentTPAId}</p>) : null} */}
                    </FormGroup>
                  </Col>
                  <IndianNumberConverter setValuesAmount = {setValuesAmount}/>

                  <Col>
                    <Label> Confidence Level</Label>
                    <Row className="confidence mt-2">
                      <Col xs="4">
                        <div>
                          <span
                            className={
                              activeTab1 === "1"
                                ? "active btn btn-outline-primary"
                                : "btn btn-outline-primary"
                            }
                            onClick={() => {
                              toggle1("1");
                            }}
                          >
                            High
                          </span>
                        </div>
                      </Col>
                      <Col xs="4">
                        <div>
                          <span
                            className={
                              activeTab1 === "2"
                                ? "active btn btn-outline-primary"
                                : "btn btn-outline-primary"
                            }
                            onClick={() => {
                              toggle1("2");
                            }}
                          >
                            Average
                          </span>
                        </div>
                      </Col>
                      <Col xs="4">
                        <div>
                          <span
                            className={
                              activeTab1 === "3"
                                ? "active btn btn-outline-primary"
                                : "btn btn-outline-primary"
                            }
                            onClick={() => {
                              toggle1("3");
                            }}
                          >
                            Low
                          </span>
                        </div>
                      </Col>
                      <Col xs="4">
                        <div>
                          <span
                            className={
                              activeTab1 === "4"
                                ? "active btn btn-outline-primary"
                                : "btn btn-outline-primary"
                            }
                            onClick={() => {
                              toggle1("4");
                            }}
                          >
                            Not known
                          </span>
                        </div>
                      </Col>
                      <Col xs="4">
                        <div>
                          <span
                            className={
                              activeTab1 === "5"
                                ? "active btn btn-outline-primary"
                                : "btn btn-outline-primary"
                            }
                            onClick={() => {
                              toggle1("5");
                            }}
                          >
                            No Go
                          </span>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                  <Row className="mt-4">
                    <Col md="4">
                      <Label>Influencer Required</Label>
                    </Col>
                    <Col md="8">
                      {/* <RadioButton /> */}
                      <Col xl="4" sm="6">
                        <div className="checkbox-checked d-flex gap-3">        
                          <div className="form-check radio radio-primary">
                            <Input id="influencerRequiredYes" type="radio" name="influencerRequired"
                              value="Yes" 
                              checked={values?.influencerRequired === "Yes"} 
                              onChange={handleChange} 
                            />
                            <Label for="influencerRequiredYes" check>Yes</Label>
                          </div>
                          <div className="form-check radio radio-primary">
                            <Input id="influencerRequiredNo" type="radio" name="influencerRequired" 
                              value="No" 
                              checked={values?.influencerRequired === "No"} 
                              onChange={handleChange} 
                            />
                            <Label for="influencerRequiredNo" check>No</Label>
                          </div>     
                        </div>
                      </Col>
                    </Col>
                    {values?.influencerRequired === "Yes" &&
                      (
                        <>
                          <Col md="12">
                            <FormGroup>
                            <Label>Employee</Label>
                            <Typeahead
                              id="employeeId" 
                              options={employeeList || []}
                              placeholder="Select Employee..."
                              filterBy={["FullName"]}
                              labelKey={(employeeList) => `${employeeList?.FullName}`}
                              selected={selectedEmployee}
                              onChange={handleChangeEmployee}
                              clearButton
                              // onBlur={handleBlur}
                            />    
                            {/* {errors.currentTPAId  ? (<p className="form-error">{errors.currentTPAId}</p>) : null} */}
                            </FormGroup>
                          </Col>
                        </>
                      )
                    }
                  </Row>
                  <Row className="mt-3">
                    <Col md="4">
                      <Label> Presentation Required</Label>
                    </Col>
                    <Col md="8">
                      {/* <RadioButton /> */}
                      <Col xl="4" sm="6">
                        <div className="checkbox-checked d-flex gap-3">        
                          <div className="form-check radio radio-primary">
                            <Input id="presentationRequiredYes" type="radio" name="presentationRequired"
                              value="Yes" 
                              checked={values?.presentationRequired === "Yes"} 
                              onChange={handleChange} 
                            />
                            <Label for="presentationRequiredYes" check>Yes</Label>
                          </div>
                          <div className="form-check radio radio-primary">
                            <Input id="presentationRequiredNo" type="radio" name="presentationRequired" 
                              value="No" 
                              checked={values?.presentationRequired === "No"} 
                              onChange={handleChange} 
                            />
                            <Label for="presentationRequiredNo" check>No</Label>
                          </div>     
                        </div>
                      </Col>
                    </Col>
                  </Row>
                  <Row className="mt-3 align-items-center">
                    <Col md="4">
                      <Label className="mb-0">Presentation Date</Label>
                    </Col>
                    <Col md="8">
                      <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DatePicker
                          className="custom-date"
                          value={selectedPresentationDate}
                          onChange={handlePresentationDateChange}
                          renderInput={props => (
                            <input {...props} variant="standard" fullWidth />
                          )}
                          format="ddd, DD MMM YYYY" // Format for the displayed date
                          minDate = {selectedDate}
                        />
                      </LocalizationProvider>
                    </Col>
                  </Row>
                  <Col md="12 mt-3">
                    <FormGroup>
                      <Label>Presentation Mode</Label>
                      <Input type="select" className="form-select"
                        id="presentationMode"
                        name="presentationMode"
                        value={values?.presentationMode}
                        onChange = {handleChange}
                      >
                        <option>{"--Select--"}</option>
                        <option>{"In Person"}</option>
                        <option>{"Virtural Meeting"}</option>
                      </Input>
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    <FormGroup>
                      <Label>Source</Label>
                      <Input
                        type="select"
                        className="form-select"
                        id="sourceType"
                        name="sourceType"
                        value={values?.sourceType}
                        // onChange = {handleChange}
                        onChange = {(event)=>{
                          setFieldValue("sourceType",event.target.value);
                          setSelectedBelongsTo([]);
                          dispatch(getBelongsToEntityList(event.target.value,null,null,null,null));
                        }}
                      >
                        <option>{"--Select--"}</option>
                        <option>{"Corporate"}</option>
                        <option>{"Insurance Company"}</option>
                        <option>{"Broker"}</option>
                        <option>{"Agent"}</option>
                        <option>{"Aggregator"}</option>
                      </Input>
                    </FormGroup>
                  </Col>
                  {/* {selectedOption === "Corporate" && (
                    <div>
                      <H6 className="card-title">Corporate</H6>
                      <Col md="12">
                        <AutocompleteSelect />
                      </Col>
                      <Col md="12">
                        <AutoCompleteCity />
                      </Col>

                      <Col md="12">
                        <Corporate
                          title="Corporate Name"
                          dataItem={CorporateData}
                          placeholder="Corporate"
                        />
                      </Col>
                      <CorporatSection />
                    </div>
                  )} */}
                  {values?.sourceType === "Insurance Company" && (
                    <div>
                      <H6 className="card-title">Insurance Company</H6>
                      <Col md="12">
                        {/* <IcNames /> */}
                        <FormGroup>
                          <Label>Insurance Company Name</Label>
                          <Typeahead
                          id="sourceId" 
                          options={belongsToList || []}
                          placeholder="Select ..."
                          filterBy={["InsuranceCompanyName"]}
                          labelKey={(belongsToList) => `${belongsToList?.InsuranceCompanyName}`}
                          selected={selectedBelongsTo}
                          onChange={handleChangeBelongsTo}
                          clearButton
                        />
                      </FormGroup>
                      </Col>
                      <Col md="12">
                        {/* <AutocompleteSelect /> */}
                        <FormGroup>
                        <Label>State</Label>
                        <Typeahead
                          id="sourcestateId" 
                          options={stateList || []}
                          placeholder="Select State..."
                          filterBy={["Name"]}
                          labelKey={(stateList) => `${stateList?.Name}`}
                          selected={selectedSourceState}
                          onChange={handleChangeSourceState}
                          clearButton
                        />
                        </FormGroup>
                      </Col>
                      <Col md="12">
                        {/* <AutoCompleteCity /> */}
                        <FormGroup>
                        <Label>City</Label>
                        <Typeahead
                          id="sourcecityId" 
                          options={citiesList || []}
                          placeholder="Select city..."
                          filterBy={["cityName"]}
                          labelKey={(citiesList) => `${citiesList?.cityName}`}
                          selected={selectedSourceCity}
                          onChange={handleChangeSourceCity}
                          clearButton
                        /> 
                        </FormGroup>   
                      </Col>
                      <Col md="12">
                        {/* <UnderwrittingOfficeLocation /> */}
                        <FormGroup>
                          <Label>Underwritting Office Location</Label>
                          <Typeahead
                            id="underwrittingOfficeLocationId"
                            options={officeList || []}
                            placeholder="Select Location..."
                            filterBy={["OfficeName"]}
                            labelKey={(officeList) => `${officeList?.OfficeName}`}
                            selected={selectedOffice}
                            onChange={handleChangeOffice}
                            clearButton
                          />
                        </FormGroup>
                      </Col>
                      {/* <ICSection /> */}
                      <Col md="12">
                        <div className="mb-2 d-flex">
                          <div>Address 1: </div>
                          <span style={{ fontWeight: 300, marginLeft: "15px" }}>
                            {selectedOffice?.length>0 ? selectedOffice[0]?.Address1 : ""}
                          </span>
                        </div>
                      </Col>
                      <Col md="12">
                        <div className="mb-2 d-flex">
                          <div>Address 2: </div>
                          <span style={{ fontWeight: 300, marginLeft: "15px" }}>
                            {selectedOffice?.length>0 ? selectedOffice[0]?.Address2 : ""}
                          </span>
                        </div>
                      </Col>
                      <Col md="12">
                        <FormGroup>
                          <Label>Contact Person Name</Label>
                          <Typeahead
                            id="contactId"
                            options={contactInformationList || []}
                            placeholder="Select Contact..."
                            filterBy={["ContactName"]}
                            labelKey={(contactInformationList) => `${contactInformationList?.ContactName}`}
                            selected={selectedContact}
                            onChange={handleChangeContact}
                            clearButton
                          />
                        </FormGroup>
                      </Col>
                      <Col md="12">
                        <div className="mb-2 d-flex">
                          <div>Designation: </div>
                          <span style={{ fontWeight: 300, marginLeft: "15px" }}>
                            {selectedContact?.length>0 ? selectedContact[0]?.Designation : ""}
                          </span>
                        </div>
                      </Col>
                      <Col md="12">
                        <div className="mb-2 d-flex">
                          <div>Phone Number : </div>
                          <span style={{ fontWeight: 300, marginLeft: "15px" }}>{selectedContact?.length>0 ? selectedContact[0]?.PrimaryContactNumber : ""}</span>
                        </div>
                      </Col>
                      <Col md="12">
                        <div className="mb-2 d-flex">
                          <div>Email : </div>
                          <span style={{ fontWeight: 300, marginLeft: "15px" }}>
                          {selectedContact?.length>0 ? selectedContact[0]?.PrimaryEmail : ""}
                          </span>
                        </div>
                      </Col>
                    </div>
                  )}
                  {values?.sourceType === "Broker" && (
                    <div>
                      <H6 className="card-title">Broker</H6>
                      <Col md="12">
                        <FormGroup>
                          <Label>Broker Name</Label>
                          <Typeahead
                          id="sourceId" 
                          options={belongsToList || []}
                          placeholder="Select ..."
                          filterBy={["BrokerName"]}
                          labelKey={(belongsToList) => `${belongsToList?.BrokerName}`}
                          selected={selectedBelongsTo}
                          onChange={handleChangeBelongsTo}
                          clearButton
                        />
                      </FormGroup>
                      </Col>
                      <Col md="12">
                        <FormGroup>
                        <Label>State</Label>
                        <Typeahead
                          id="sourcestateId" 
                          options={stateList || []}
                          placeholder="Select State..."
                          filterBy={["Name"]}
                          labelKey={(stateList) => `${stateList?.Name}`}
                          selected={selectedSourceState}
                          onChange={handleChangeSourceState}
                          clearButton
                        />
                        </FormGroup>
                      </Col>
                      <Col md="12">
                        <FormGroup>
                        <Label>City</Label>
                        <Typeahead
                          id="sourcecityId" 
                          options={citiesList || []}
                          placeholder="Select city..."
                          filterBy={["cityName"]}
                          labelKey={(citiesList) => `${citiesList?.cityName}`}
                          selected={selectedSourceCity}
                          onChange={handleChangeSourceCity}
                          clearButton
                        /> 
                        </FormGroup>   
                      </Col>
                      <Col md="12">
                        <FormGroup>
                          <Label>Office</Label>
                          <Typeahead
                            id="underwrittingOfficeLocationId"
                            options={officeList || []}
                            placeholder="Select Office..."
                            filterBy={["BrokerOfficeName"]}
                            labelKey={(officeList) => `${officeList?.BrokerOfficeName}`}
                            selected={selectedOffice}
                            onChange={handleChangeOffice}
                            clearButton
                          />
                        </FormGroup>
                      </Col>
                      <Col md="12">
                        <div className="mb-2 d-flex">
                          <div>Address 1: </div>
                          <span style={{ fontWeight: 300, marginLeft: "15px" }}>
                            {selectedOffice?.length>0 ? selectedOffice[0]?.Address1 : ""}
                          </span>
                        </div>
                      </Col>
                      <Col md="12">
                        <div className="mb-2 d-flex">
                          <div>Address 2: </div>
                          <span style={{ fontWeight: 300, marginLeft: "15px" }}>
                            {selectedOffice?.length>0 ? selectedOffice[0]?.Address2 : ""}
                          </span>
                        </div>
                      </Col>
                      <Col md="12">
                        <FormGroup>
                          <Label>Contact Person Name</Label>
                          <Typeahead
                            id="contactId"
                            options={contactInformationList || []}
                            placeholder="Select Contact..."
                            filterBy={["ContactName"]}
                            labelKey={(contactInformationList) => `${contactInformationList?.ContactName}`}
                            selected={selectedContact}
                            onChange={handleChangeContact}
                            clearButton
                          />
                        </FormGroup>
                      </Col>
                      <Col md="12">
                        <div className="mb-2 d-flex">
                          <div>Designation: </div>
                          <span style={{ fontWeight: 300, marginLeft: "15px" }}>
                            {selectedContact?.length>0 ? selectedContact[0]?.Designation : ""}
                          </span>
                        </div>
                      </Col>
                      <Col md="12">
                        <div className="mb-2 d-flex">
                          <div>Phone Number : </div>
                          <span style={{ fontWeight: 300, marginLeft: "15px" }}>{selectedContact?.length>0 ? selectedContact[0]?.PrimaryContactNumber : ""}</span>
                        </div>
                      </Col>
                      <Col md="12">
                        <div className="mb-2 d-flex">
                          <div>Email : </div>
                          <span style={{ fontWeight: 300, marginLeft: "15px" }}>
                          {selectedContact?.length>0 ? selectedContact[0]?.PrimaryEmail : ""}
                          </span>
                        </div>
                      </Col>
                    </div>
                  )}
                  {values?.sourceType === "Agent" && (
                    <div>
                      <H6 className="card-title">Agent</H6>
                      {/* <Col md="12">
                        <AgentNames />
                      </Col>
                      <Col md="12">
                        <AutocompleteSelect />
                      </Col>
                      <Col md="12">
                        <AutoCompleteCity />
                      </Col> */}
                      {/* <AgentSection /> */}
                      <Col md="12">
                        <FormGroup>
                          <Label>Contact Person Name</Label>
                          <Typeahead
                            id="contactId"
                            options={contactInformationList || []}
                            placeholder="Select Contact..."
                            filterBy={["ContactName"]}
                            labelKey={(contactInformationList) => `${contactInformationList?.ContactName}`}
                            selected={selectedContact}
                            onChange={handleChangeContact}
                            clearButton
                          />
                        </FormGroup>
                      </Col>
                      <Col md="12">
                        <div className="mb-2 d-flex">
                          <div>Designation: </div>
                          <span style={{ fontWeight: 300, marginLeft: "15px" }}>
                            {selectedContact?.length>0 ? selectedContact[0]?.Designation : ""}
                          </span>
                        </div>
                      </Col>
                      <Col md="12">
                        <div className="mb-2 d-flex">
                          <div>Phone Number : </div>
                          <span style={{ fontWeight: 300, marginLeft: "15px" }}>{selectedContact?.length>0 ? selectedContact[0]?.PrimaryContactNumber : ""}</span>
                        </div>
                      </Col>
                      <Col md="12">
                        <div className="mb-2 d-flex">
                          <div>Email : </div>
                          <span style={{ fontWeight: 300, marginLeft: "15px" }}>
                          {selectedContact?.length>0 ? selectedContact[0]?.PrimaryEmail : ""}
                          </span>
                        </div>
                      </Col>
                    </div>
                  )}
                  {values?.sourceType === "Aggregator" && (
                    <div>
                      <H6 className="card-title">Aggregator</H6>
                      {/* <Col md="12">
                        <AggregatgorNames />
                      </Col>

                      <AggregatgorSection /> */}
                      <Col md="12">
                        <FormGroup>
                          <Label>Aggregator Name</Label>
                          <Typeahead
                          id="sourceId" 
                          options={belongsToList || []}
                          placeholder="Select ..."
                          filterBy={["AggregatorName"]}
                          labelKey={(belongsToList) => `${belongsToList?.AggregatorName}`}
                          selected={selectedBelongsTo}
                          onChange={handleChangeBelongsTo}
                          clearButton
                        />
                      </FormGroup>
                      </Col>
                      <Col md="12">
                        <FormGroup>
                          <Label>Contact Person Name</Label>
                          <Typeahead
                            id="contactId"
                            options={contactInformationList || []}
                            placeholder="Select Contact..."
                            filterBy={["ContactName"]}
                            labelKey={(contactInformationList) => `${contactInformationList?.ContactName}`}
                            selected={selectedContact}
                            onChange={handleChangeContact}
                            clearButton
                          />
                        </FormGroup>
                      </Col>
                      <Col md="12">
                        <div className="mb-2 d-flex">
                          <div>Designation: </div>
                          <span style={{ fontWeight: 300, marginLeft: "15px" }}>
                            {selectedContact?.length>0 ? selectedContact[0]?.Designation : ""}
                          </span>
                        </div>
                      </Col>
                      <Col md="12">
                        <div className="mb-2 d-flex">
                          <div>Phone Number : </div>
                          <span style={{ fontWeight: 300, marginLeft: "15px" }}>{selectedContact?.length>0 ? selectedContact[0]?.PrimaryContactNumber : ""}</span>
                        </div>
                      </Col>
                      <Col md="12">
                        <div className="mb-2 d-flex">
                          <div>Email : </div>
                          <span style={{ fontWeight: 300, marginLeft: "15px" }}>
                          {selectedContact?.length>0 ? selectedContact[0]?.PrimaryEmail : ""}
                          </span>
                        </div>
                      </Col>
                    </div>
                  )}
                </Row>
                {/* <Row className="Opportunity align-items-center last-btn-part">
                  <Col md="6" className="mt-3">
                    <div>
                      <span
                        className={
                          activeTab3 === "1"
                            ? "active btn btn-outline-primary"
                            : "btn btn-outline-primary"
                        }
                        onClick={() => {
                          toggle3("1");
                        }}
                      >
                        Add another from same source
                      </span>
                    </div>
                  </Col>
                  <Col md="6" className="mt-3">
                    <div>
                      <span
                        className={
                          activeTab3 === "2"
                            ? "active btn btn-outline-primary"
                            : "btn btn-outline-primary"
                        }
                        onClick={() => {
                          toggle3("2");
                        }}
                      >
                        Add another from different source
                      </span>
                    </div>
                  </Col>
                  <Col md="4" className="mt-3">
                    <div>
                      <span
                        className={
                          activeTab3 === "3"
                            ? "active btn btn-outline-primary"
                            : "btn btn-outline-primary"
                        }
                        onClick={() => {
                          toggle3("3");
                        }}
                      >
                        This is it
                      </span>
                    </div>
                  </Col>
                </Row> */}
                {opportunityEditFlag && (
                  <>
                    <Row>
                      {roles[0] === "Sales Representative" && opportunityTab!=2 && opportunityTab!=3 && <Col>
                        <Btn
                          // className={"btn w-100 btn-outline-primary"}
                          className={
                            values?.moveTo === "Lead"
                              ? "active w-100 btn btn-outline-primary"
                              : "btn w-100 btn-outline-primary"
                          }
                          type="button"
                          onClick={()=>setFieldValue("moveTo","Lead")}
                        >
                          Move to Lead
                        </Btn>
                      </Col>}
                      {roles[0] === "Sales Representative" && opportunityTab!=3 && <Col>
                        <Btn
                          className={
                            values?.moveTo === "Win"
                              ? "active w-100 btn btn-outline-primary"
                              : "btn w-100 btn-outline-primary"
                          }
                          type="button"
                          onClick={()=>setFieldValue("moveTo","Win")}
                        >
                          Move to Win
                        </Btn>
                      </Col>}
                      {roles[0] === "Sales Representative" && opportunityTab!=3 && <Col>
                        <Btn
                          className={
                            values?.moveTo === "Lost"
                              ? "active w-100 btn btn-outline-primary"
                              : "btn w-100 btn-outline-primary"
                          }
                          type="button"
                          onClick={()=>setFieldValue("moveTo","Lost")}
                        >
                          Move to Lost
                        </Btn>
                      </Col>}
                    </Row>
                  </>
                )}
              </CardBody>

              <CardFooter className="text-end">
                <Btn color="primary" type="submit" onClick={handleSubmit}>
                  {opportunityEditFlag ? "Update" : "Submit"}
                </Btn>
                <Btn
                  className="btn btn-light"
                  type="reset"
                  style={{ marginLeft: "10px" }}
                  onClick = {handleCancel}
                >
                  Clear
                </Btn>
              </CardFooter>
            </Card>
          </Form>
        </Col>
      </Row>
    </div>
  );
};
