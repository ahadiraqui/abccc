import React, { useState } from "react";
import {
  Card,
  CardBody,
  Row,
  Col,
  Form,
  CardFooter,
  TabContent,
  TabPane,
  Label
} from "reactstrap";
import dayjs from "dayjs";

import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { Btn } from "../../../../AbstractElements";
import './style.scss'
const AddNewAttendance = () => {
  const [activeTab, setActiveTab] = useState("1");

  const [selectedDate, setSelectedDate] = useState(dayjs());

  const toggle = tab => {
    if (activeTab !== tab) setActiveTab(tab);
  };

  const handleDateChange = date => {
    setSelectedDate(date);
  };

  const formatDate = date => {
    if (!date) return "";
    return dayjs(date).format("ddd, DD MMM YYYY");
  };
  return (
 
     
      <Row>    
        <Col>
          <Card>
            <CardBody>
              <Form>

                <CardFooter className="text-end mt-4">
                  <Btn color="primary" type="submit">
                    Submit
                  </Btn>
                  <Btn
                    className="btn btn-light"
                    type="reset"
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </Btn>
                </CardFooter>
              </Form>
            </CardBody>
          </Card>
        </Col>
      </Row>

  );
};

export default AddNewAttendance;
