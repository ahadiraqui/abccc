import { useState } from "react";

import {
  Card,
  CardBody,
  CardFooter,
  Col,
  Form,
  FormGroup,
  Input,
  Label,
  Row
} from "reactstrap";
import { Btn, H6 } from "../../../AbstractElements";
import Corporate from "./AutoSelectDropdown";
import NumberConverter from "./NumberConverter";
import PresentationRadio from "./PresentationRadio";
import RadioButton from "./Radio";
import dayjs from "dayjs";

import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import "./style.scss";
import CorporatSection from "./CorporatSection";
import AutoCompleteCity from "../../../CommonElements/AutoCompleteSelectBox/AutoCompleteCity";
import AutocompleteSelect from "../../../CommonElements/AutoCompleteSelectBox";
import IcNames from "./IcNames";
import UnderwrittingOfficeLocation from "./UnderwrittingOfficeLocation";
import ICSection from "./ICSection";
import BrokerNames from "./BrokerNames";
import BrokerLocation from "./BrokerLocation.1";
import AgentNames from "./AgentNames";
import AgentSection from "./AgentSection";
import AggregatgorNames from "./AggregatgorNames";
import AggregatgorSection from "./AggregatgorSection";
import IndianNumberConverter from "./AmountSeperator";
import { useFormik } from "formik";

const CorporateData = [
  "New Inc",
  "ABC Limited",
  "Broking company Ltd",
  "RTS Insurance Inc",
  "New Inc",
  "ABC Limited",
  "Broking company Ltd",
  "RTS Insurance Inc"
];
export const AddOpportunity = () => {
  const [selectedDate, setSelectedDate] = useState(dayjs());
  const [activeTab3, setActiveTab3] = useState("1");
  const toggle3 = tab3 => {
    if (activeTab3 !== tab3) setActiveTab3(tab3);
  };

  const handleDateChange = date => {
    setSelectedDate(date);
  };

  const formatDate = date => {
    if (!date) return "";
    return dayjs(date).format("ddd, DD MMM YYYY");
  };
  const [activeTab, setActiveTab] = useState("1");
  const toggle = tab => {
    if (activeTab !== tab) setActiveTab(tab);
  };
  const [activeTab1, setActiveTab1] = useState("1");
  const toggle1 = tab1 => {
    if (activeTab1 !== tab1) setActiveTab1(tab1);
  };

  const [selectedOption, setSelectedOption] = useState("--Select--");

  const handleSelectChange = e => {
    setSelectedOption(e.target.value);
  };
  return (
    <div className="page-body">
      <div className="d-flex justify-content-between mt-4 mb-1 align-items-center pt-1 pt-1">
        <div className="ps-0 col-sm-6">
          <h3 className="screen-title">Add opportunity</h3>
        </div>
      </div>

      <Row>
        <Col lg="3" className="d-none d-lg-block"></Col>
        <Col lg="6">
          <Form>
            <Card>
              <CardBody>
                <H6 className="card-title">Opportunity</H6>
                <Row className="Opportunity">
                  <Col xs="4" md="4">
                    <div>
                      <span
                        className={
                          activeTab === "1"
                            ? "active btn btn-outline-primary"
                            : "btn btn-outline-primary"
                        }
                        onClick={() => {
                          toggle("1");
                        }}
                      >
                        Exploration
                      </span>
                    </div>
                  </Col>
                  <Col xs="4" md="4">
                    <div>
                      <span
                        className={
                          activeTab === "2"
                            ? "active btn btn-outline-primary"
                            : "btn btn-outline-primary"
                        }
                        onClick={() => {
                          toggle("2");
                        }}
                      >
                        Lead
                      </span>
                    </div>
                  </Col>
                  <Col xs="4" md="4">
                    <div>
                      <span
                        className={
                          activeTab === "3"
                            ? "active btn btn-outline-primary"
                            : "btn btn-outline-primary"
                        }
                        onClick={() => {
                          toggle("3");
                        }}
                      >
                        Win
                      </span>
                    </div>
                  </Col>
                </Row>
                <div className="mt-4">
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DatePicker
                      className="custom-date"
                      value={selectedDate}
                      onChange={handleDateChange}
                      renderInput={props => (
                        <input {...props} variant="standard" fullWidth />
                      )}
                      format="ddd, DD MMM YYYY" // Format for the displayed date
                    />
                  </LocalizationProvider>
                </div>

                <Row className="mt-3">
                  <Col md="12">
                    <Corporate
                      title="Corporate"
                      dataItem={CorporateData}
                      placeholder="Corporate"
                    />
                  </Col>
                  <Col md="12">
                    <Corporate
                      title="Current TPA"
                      dataItem={CorporateData}
                      placeholder="Current TPA"
                    />
                  </Col>
                  <IndianNumberConverter />

                  <Col>
                    <Label> Confidence Level</Label>
                    <Row className="confidence mt-2">
                      <Col xs="4">
                        <div>
                          <span
                            className={
                              activeTab1 === "1"
                                ? "active btn btn-outline-primary"
                                : "btn btn-outline-primary"
                            }
                            onClick={() => {
                              toggle1("1");
                            }}
                          >
                            High
                          </span>
                        </div>
                      </Col>
                      <Col xs="4">
                        <div>
                          <span
                            className={
                              activeTab1 === "2"
                                ? "active btn btn-outline-primary"
                                : "btn btn-outline-primary"
                            }
                            onClick={() => {
                              toggle1("2");
                            }}
                          >
                            Average
                          </span>
                        </div>
                      </Col>
                      <Col xs="4">
                        <div>
                          <span
                            className={
                              activeTab1 === "3"
                                ? "active btn btn-outline-primary"
                                : "btn btn-outline-primary"
                            }
                            onClick={() => {
                              toggle1("3");
                            }}
                          >
                            Low
                          </span>
                        </div>
                      </Col>
                      <Col xs="4">
                        <div>
                          <span
                            className={
                              activeTab1 === "4"
                                ? "active btn btn-outline-primary"
                                : "btn btn-outline-primary"
                            }
                            onClick={() => {
                              toggle1("4");
                            }}
                          >
                            Not known
                          </span>
                        </div>
                      </Col>
                      <Col xs="4">
                        <div>
                          <span
                            className={
                              activeTab1 === "5"
                                ? "active btn btn-outline-primary"
                                : "btn btn-outline-primary"
                            }
                            onClick={() => {
                              toggle1("5");
                            }}
                          >
                            No Go
                          </span>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                  <Row className="mt-4">
                    <Col md="4">
                      <Label>Influencer Required</Label>
                    </Col>
                    <Col md="8">
                      <RadioButton />
                    </Col>
                  </Row>
                  <Row className="mt-3">
                    <Col md="4">
                      <Label> Presentation Required</Label>
                    </Col>
                    <Col md="8">
                      <RadioButton />
                    </Col>
                  </Row>
                  <Row className="mt-3 align-items-center">
                    <Col md="4">
                      <Label className="mb-0">Presentation Date</Label>
                    </Col>
                    <Col md="8">
                      <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DatePicker
                          className="custom-date"
                          value={selectedDate}
                          onChange={handleDateChange}
                          renderInput={props => (
                            <input {...props} variant="standard" fullWidth />
                          )}
                          format="ddd, DD MMM YYYY" // Format for the displayed date
                        />
                      </LocalizationProvider>
                    </Col>
                  </Row>
                  <Col md="12 mt-3">
                    <FormGroup>
                      <Label>Presentation Mode</Label>
                      <Input type="select" className="form-select">
                        <option>{"--Select--"}</option>
                        <option>{"In Person"}</option>
                        <option>{"Virtural Meeting"}</option>
                      </Input>
                    </FormGroup>
                  </Col>
                  <Col md="12">
                    <FormGroup>
                      <Label>Source</Label>
                      <Input
                        type="select"
                        className="form-select"
                        onChange={handleSelectChange}
                        value={selectedOption}
                      >
                        <option>{"--Select--"}</option>
                        <option>{"Corporate"}</option>
                        <option>{"Insurance Company"}</option>
                        <option>{"Broker"}</option>
                        <option>{"Agent"}</option>
                        <option>{"Aggregatgor"}</option>
                      </Input>
                    </FormGroup>
                  </Col>
                  {selectedOption === "Corporate" && (
                    <div>
                      <H6 className="card-title">Corporate</H6>
                      <Col md="12">
                        <AutocompleteSelect />
                      </Col>
                      <Col md="12">
                        <AutoCompleteCity />
                      </Col>

                      <Col md="12">
                        <Corporate
                          title="Corporate Name"
                          dataItem={CorporateData}
                          placeholder="Corporate"
                        />
                      </Col>
                      <CorporatSection />
                    </div>
                  )}
                  {selectedOption === "Insurance Company" && (
                    <div>
                      <H6 className="card-title">Insurance Company</H6>
                      <Col md="12">
                        <IcNames />
                      </Col>
                      <Col md="12">
                        <AutocompleteSelect />
                      </Col>
                      <Col md="12">
                        <AutoCompleteCity />
                      </Col>
                      <Col md="12">
                        <UnderwrittingOfficeLocation />
                      </Col>
                      <ICSection />
                    </div>
                  )}
                  {selectedOption === "Broker" && (
                    <div>
                      <H6 className="card-title">Broker</H6>
                      <Col md="12">
                        <BrokerNames />
                      </Col>
                      <Col md="12">
                        <AutocompleteSelect />
                      </Col>
                      <Col md="12">
                        <AutoCompleteCity />
                      </Col>
                      <Col md="12">
                        <BrokerLocation />
                      </Col>
                      <ICSection />
                    </div>
                  )}
                  {selectedOption === "Agent" && (
                    <div>
                      <H6 className="card-title">Agent</H6>
                      <Col md="12">
                        <AgentNames />
                      </Col>
                      <Col md="12">
                        <AutocompleteSelect />
                      </Col>
                      <Col md="12">
                        <AutoCompleteCity />
                      </Col>
                      <AgentSection />
                    </div>
                  )}
                  {selectedOption === "Aggregatgor" && (
                    <div>
                      <H6 className="card-title">Aggregatgor</H6>
                      <Col md="12">
                        <AggregatgorNames />
                      </Col>

                      <AggregatgorSection />
                    </div>
                  )}
                </Row>
                <Row className="Opportunity align-items-center last-btn-part">
                  <Col md="6" className="mt-3">
                    <div>
                      <span
                        className={
                          activeTab3 === "1"
                            ? "active btn btn-outline-primary"
                            : "btn btn-outline-primary"
                        }
                        onClick={() => {
                          toggle3("1");
                        }}
                      >
                        Add another from same source
                      </span>
                    </div>
                  </Col>
                  <Col md="6" className="mt-3">
                    <div>
                      <span
                        className={
                          activeTab3 === "2"
                            ? "active btn btn-outline-primary"
                            : "btn btn-outline-primary"
                        }
                        onClick={() => {
                          toggle3("2");
                        }}
                      >
                        Add another from different source
                      </span>
                    </div>
                  </Col>
                  {/* <Col md="4" className="mt-3">
                    <div>
                      <span
                        className={
                          activeTab3 === "3"
                            ? "active btn btn-outline-primary"
                            : "btn btn-outline-primary"
                        }
                        onClick={() => {
                          toggle3("3");
                        }}
                      >
                        This is it
                      </span>
                    </div>
                  </Col> */}
                </Row>
              </CardBody>

              <CardFooter className="text-end">
                <Btn color="primary" type="submit">
                  Submit
                </Btn>
                <Btn
                  className="btn btn-light"
                  type="reset"
                  style={{ marginLeft: "10px" }}
                >
                  Cancel
                </Btn>
              </CardFooter>
            </Card>
          </Form>
        </Col>
      </Row>
    </div>
  );
};
