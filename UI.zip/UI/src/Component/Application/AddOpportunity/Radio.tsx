import { Col, Input, Label } from 'reactstrap';
import { H6 } from '../../../AbstractElements';

const RadioButton = () => {
  return (
    <Col xl="4" sm="6">
      <div className="checkbox-checked d-flex gap-3">        
        <div className="form-check radio radio-primary">
          <Input id="radio1" type="radio" name="radioGroup" defaultChecked />
          <Label for="radio1" check>Yes</Label>
        </div>
        <div className="form-check radio radio-primary">
          <Input id="radio2" type="radio" name="radioGroup" />
          <Label for="radio2" check>No</Label>
        </div>     
      </div>
    </Col>
  );
};

export default RadioButton;
