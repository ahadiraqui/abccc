import { Col } from "reactstrap";
import { Btn } from "../../../AbstractElements";

import ContactPerson from "./ContactPerson";

const ICSection = () => {
  return (
    <div>
      <Col md="12">
        <div className="mb-2 d-flex">
          <div>Building: </div>
          <span style={{ fontWeight: 300, marginLeft: "15px" }}>
            PTC Inc 3rd Floor, Space A-2 Building
          </span>
        </div>
      </Col>
      <Col md="12">
        <div className="mb-2 d-flex">
          <div>Street / Landmark: </div>
          <span style={{ fontWeight: 300, marginLeft: "15px" }}>
            S.No. 46/1 E, Nagar Rd, Wadgaon Sheri, Pune.
          </span>
        </div>
      </Col>
      <Col>
        <div className="d-flex justify-content-between align-items-center gap-2">
          <div style={{ width: "100%" }}>
            <ContactPerson />
          </div>
          <div style={{ marginTop: "8px" }} className="contact-person">
            <Btn color="primary" type="submit">
              Add Contact
            </Btn>
          </div>
        </div>
      </Col>
      <Col md="12">
        <div className="mb-2 d-flex">
          <div>Designation: </div>
          <span style={{ fontWeight: 300, marginLeft: "15px" }}>
            Sale Officer
          </span>
        </div>
      </Col>
      <Col md="12">
        <div className="mb-2 d-flex">
          <div>Phone Number : </div>
          <span style={{ fontWeight: 300, marginLeft: "15px" }}>85858585</span>
        </div>
      </Col>
      <Col md="12">
        <div className="mb-2 d-flex">
          <div>Email : </div>
          <span style={{ fontWeight: 300, marginLeft: "15px" }}>
            abc@gmail.com
          </span>
        </div>
      </Col>
    </div>
  );
};

export default ICSection;
