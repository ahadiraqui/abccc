import { Card, CardBody, Col, Container, Row } from "reactstrap";
import DragCalendar from "./DragCalendar/DragCalendar";
import Breadcrumbs from "../../../CommonElements/Breadcrumbs/Breadcrumbs";
import { Apps, CalenderHeading } from "../../../utils/Constant";
import { Btn } from "../../../AbstractElements";
import { Link } from "react-router-dom";
const CalenderContainer = () => {
  return (
    <>
      {/* <Breadcrumbs mainTitle={CalenderHeading} parent={Apps} /> */}
      <Container fluid className="calendar-basic">
        <Card>
          <CardBody>
            <Row>
              <Col sm="12">          
              <div className="text-end mb-2" style={{display: "flex", justifyContent: 'space-between'}}>
              <div className="d-md-flex  gap-2 text-start">
               <div className="exp-badge"><i className="fa fa-circle"></i> Exploration</div>
               <div className="lead-badge"><i className="fa fa-circle"></i> Lead</div>
               <div className="win-badge"><i className="fa fa-circle"></i> Win</div>
              </div>
              <Link to={`${process.env.PUBLIC_URL}/add-new-meeting`}>
              <Btn color="primary" className="plus-button w-110">
              <i className="icon-plus"></i> 
              Add
              </Btn>
              </Link>
            </div>
                <Row> 
                  <DragCalendar />
                </Row>
              </Col>
            </Row>
          </CardBody>
        </Card>
      </Container>
    </>
  );
};

export default CalenderContainer;
