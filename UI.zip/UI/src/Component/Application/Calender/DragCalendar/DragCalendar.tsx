import { Fragment, useEffect, useState } from "react";
import FullCalendar from "@fullcalendar/react";
import { Col, Label } from "reactstrap";
import CalendarEvents from "./CalendarEvents";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin, { Draggable } from "@fullcalendar/interaction";
import { calenderInitialData } from "../../../../Data/Application/Calendar/Calendar";
import { calenderEventClick } from "./CalenderFunction";
import { useAppDispatch, useAppSelector } from "../../../../ReduxToolkit/Hooks";
import { getScheduleInformation } from "../../../../ReduxToolkit/Reducers/AttendanceAction";
import { getOpportunityById } from "../../../../ReduxToolkit/Reducers/OpportunityAction";
import { Dialog, DialogActions, DialogContent, DialogTitle, Typography } from "@mui/material";
import { Typeahead } from "react-bootstrap-typeahead";
import { Btn } from "../../../../AbstractElements";
import { formatIndianNumber } from "../../OpportunityGrid/formatIndianNumber";
import listPlugin from "@fullcalendar/list";

const DragCalendar = () => {
  const [currentView, setCurrentView] = useState('dayGridMonth');
  const dispatch = useAppDispatch();
  const attendanceAction = useAppSelector((state:any)=>state.attendanceAction);
  const scheduleList = attendanceAction.scheduleList;
  const [open, setOpen] = useState(false);

  const opportunityAction = useAppSelector((state:any)=>state.opportunityAction);
  const opportunityDataByIdList = opportunityAction.opportunityDataById ;
  const opportunityDataById = opportunityDataByIdList?.length > 0 && opportunityDataByIdList[0] ;
  
  // console.log("scheduleList",scheduleList);
  function getWindowInnerWidth() {
    return window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
  }

  // Adjust view on window resize
  useEffect(() => {
    function handleResize() {
      setCurrentView(getWindowInnerWidth() < 765 ? 'listWeek' : 'dayGridMonth');
    }

    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  useEffect(()=>{
    dispatch(getScheduleInformation());
  },[])

  const handleClose = () => {
    setOpen(false);
  }

  const state = useState(calenderInitialData)[0];
  useEffect(() => {
    let draggableEl = document.getElementById("external-events") as HTMLElement;
    new Draggable(draggableEl, {
      itemSelector: ".fc-event",
      eventData: function(eventEl) {
        let title = eventEl.getAttribute("title");
        let id = eventEl.getAttribute("data");
        return {
          title: title,
          id: id
        };
      }
    });
  }, []);

  const calenderEventClick = (info: any) => {
    const eventId = info.event.extendedProps.OpportunityGUID;
    // console.log("infoclick",eventId);
    dispatch(getOpportunityById(eventId))
    setOpen(true);
  };

  function getEventClassName(info:any) {
    // console.log("CLASS",info)
    switch (info.event.extendedProps.stage) {
      case 'Exploration':
        return 'exploration-event';
      case 'Lead':
        return 'lead-event';
      case 'Win':
        return 'win-event';
      case 'Lost':
        return 'lost-event';
      default:
        return '';
    }
  }

  const getEventContent = (event:any) => {
    // console.log("event",event)
    // Check moveToStatus from the event object
    const moveToStatus = event?.event?.extendedProps?.moveToStatus;

    // Render different content based on moveToStatus
    return (
      <div>
        {moveToStatus ? (
          <div>
            <span className="icon">
              <i className="fa fa-share-square-o" />
            </span>{' '} 
            <span >{event.timeText}</span>{' '}
            <span >{event.event.title.slice(0, 15)}</span>
          </div>
        ) : (
          <div>
            <span >{event.timeText}</span>{' '}
            <span >{event.event.title.slice(0, 15)}</span>
          </div>
        )}
        {/* <div>
            {event.event.title}
          </div> */}
      </div>
    );
  };

  return (
    <>
    <Fragment>
      <div className="d-none">
        <CalendarEvents />
      </div>

      <Col xl="12" md="12" className="box-col-12">
        <div className="demo-app-calendar" id="mycalendartest">
          <FullCalendar
          initialView={currentView}
            headerToolbar={{
              left: "prev,next today",
              center: "title",
              right: getWindowInnerWidth() < 765 ? 'listDay,listWeek,listMonth' : 'dayGridMonth,timeGridWeek,timeGridDay'
            }}
            rerenderDelay={10}
            eventDurationEditable={false}
            editable={false}
            droppable={false}
            displayEventEnd={false}
            plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin,listPlugin]}
            events = {scheduleList || []}
            views={{
              listDay: { buttonText: 'List Day' },
              listWeek: { buttonText: 'List Week' },
              listMonth: { buttonText: 'List Month' }
            }}
            eventTimeFormat={{
              hour: '2-digit',
              minute: '2-digit',
              hour12: false,
              // meridiem: 'short' // Ensure 'short' is used for 'am'/'pm'
            }}
            // events={state.calendarEvents}
            eventClassNames={getEventClassName}
            eventClick={calenderEventClick}
            eventContent={getEventContent}
          />
        </div>
      </Col>
    </Fragment>

    <Dialog open={open} 
       onClose={handleClose}
       aria-describedby = "alert-dialog-slide-description"
      //  maxWidth="1g"
       PaperProps={{style:{borderRadius : "10px",backgroundColor:'#fffadf'}}}
       >
     
        <DialogTitle style={{display: "flex",justifyContent: "center", color:'#5c61f2'}}>Opportunity Details
          <i
            className="icofont icofont-close"
            aria-label="close"
            onClick={handleClose}
            style={{
              position: 'absolute',
              right: 15,
              top: 15,
              color: '#5e5e5e',
              fontSize:'20px',
              cursor:'pointer'
            }}
          >
          </i>
        </DialogTitle>
        <DialogContent className="dialog-calendar">
          <Typography gutterBottom>
          <p style={{fontSize: "15px",fontWeight: "600",marginBottom: "5px"}}>
            Corporate : <span style={{fontSize: "15px",fontWeight: "400"}}>{opportunityDataById?.CorporateName}</span> </p>
          </Typography>
          <Typography gutterBottom>
          <p style={{fontSize: "15px",fontWeight: "600",marginBottom: "5px"}}>
            Broker : <span style={{fontSize: "15px",fontWeight: "400"}}>{opportunityDataById?.BrokerName}</span> </p>
          </Typography>
          <Typography gutterBottom>
          <p style={{fontSize: "15px",fontWeight: "600",marginBottom: "5px"}}>
            Insurance Company: <span style={{fontSize: "15px",fontWeight: "400"}}> {opportunityDataById?.InsuranceCompanyName}</span> </p>
          </Typography>
          <Typography gutterBottom>
          <p style={{fontSize: "15px",fontWeight: "600",marginBottom: "5px"}}>
            TPA : <span style={{fontSize: "15px",fontWeight: "400"}}>{opportunityDataById?.TPAName}</span> </p>
          </Typography>
          <Typography gutterBottom>
          <p style={{fontSize: "15px",fontWeight: "600",marginBottom: "5px"}}>
            Current Stage : <span style={{fontSize: "15px",fontWeight: "400"}}>{opportunityDataById?.CurrentStage == "Close" ? opportunityDataById?.OpportunityStatus : opportunityDataById?.CurrentStage}</span> </p>
          </Typography>
          <Typography gutterBottom>
          <p style={{fontSize: "15px",fontWeight: "600",marginBottom: "5px"}}>
            Premium: <span style={{fontSize: "15px",fontWeight: "400"}}> {(opportunityDataById?.Premium > 0 ? formatIndianNumber(opportunityDataById?.Premium?.toString()):"") + " (" + (opportunityDataById?.PremiumAmountinWords)+")"}</span> </p>
          </Typography>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default DragCalendar;
