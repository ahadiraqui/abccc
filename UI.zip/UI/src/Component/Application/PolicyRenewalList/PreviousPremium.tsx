import React, { useState } from "react";
import { Col, FormGroup, Input, Label, Row } from "reactstrap";

const PreviousPremium: React.FC = () => {
  const [inputNumber, setInputNumber] = useState<string>("");
  const [amountInWords, setAmountInWords] = useState<string>("");
  const [inputNumber1, setInputNumber1] = useState<string>("");
  const [amountInWords1, setAmountInWords1] = useState<string>("");

  const formatIndianNumber = (number: string) => {
    if (!number.trim()) return "";

    // Otherwise, format the number with Indian style comma separation
    return parseFloat(number.replace(/,/g, "")).toLocaleString("en-IN");
  };

  const numberToWords = (number: string): string => {
    const ones = [
      "",
      "One",
      "Two",
      "Three",
      "Four",
      "Five",
      "Six",
      "Seven",
      "Eight",
      "Nine"
    ];
    const teens = [
      "Ten",
      "Eleven",
      "Twelve",
      "Thirteen",
      "Fourteen",
      "Fifteen",
      "Sixteen",
      "Seventeen",
      "Eighteen",
      "Nineteen"
    ];
    const tens = [
      "",
      "",
      "Twenty",
      "Thirty",
      "Forty",
      "Fifty",
      "Sixty",
      "Seventy",
      "Eighty",
      "Ninety"
    ];

    const num = parseFloat(number.replace(/,/g, ""));
    let numStr = num.toString();

    const getHundreds = (num: number) => {
      let result = "";
      if (num > 99) {
        result += ones[Math.floor(num / 100)] + " Hundred ";
        num %= 100;
      }
      if (num > 19) {
        result += tens[Math.floor(num / 10)] + " ";
        num %= 10;
      }
      if (num > 9 && num < 20) {
        result += teens[num - 10] + " ";
        num = 0;
      }
      if (num > 0) {
        result += ones[num] + " ";
      }
      return result;
    };

    const units = ["", "Thousand", "Lakh", "Crore", "Arab", "Kharab","Padma", "Shankh", "Maha-shankh"];
    let words: string[] = [];

    let chunkCount = 0;
    while (numStr.length > 0) {
      let chunkSize = chunkCount === 0 ? 3 : 2;
      let chunk = numStr.slice(-chunkSize);
      numStr = numStr.slice(0, -chunkSize);
      if (parseInt(chunk, 10) > 0) {
        words.unshift(getHundreds(parseInt(chunk, 10)) + units[chunkCount]);
      }
      chunkCount++;
    }

    return words.join(" ").trim();
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputNumber(value);
    setAmountInWords(numberToWords(value));
  };
  const handleInputChange1 = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputNumber1(value);
    setAmountInWords1(numberToWords(value));
  };
  const calculateTpaFeesAmount = (
    premiumAmount: number,
    percent: number
  ): number => {
    return (premiumAmount * percent) / 100;
  };

  return (
    <>
      <Col md="12" className="mt-2">
        <Row>
          <Col md="6">
            <FormGroup>
              <Label>New Premium</Label>
              <Input
                type="text"
                placeholder="1,000"
                value={formatIndianNumber(inputNumber)}
                onChange={handleInputChange}
                style={{ textAlign: "right" }}
              />
            </FormGroup>
          </Col>
          <Col md="6">
            <div className="mb-2">
              Premium Amounts in words 
              <p style={{ color: "#5c61f2",fontWeight:300 }}> {amountInWords}</p>
            </div>
          </Col>
        </Row>
      </Col>

      <Row>
        <Col md="6">
          <div>
            <FormGroup>
              <Label> TPA Fees %</Label>
              <Input
                type="text"
                placeholder="3"
                style={{ textAlign: "right" }}
              />
              <span
                style={{ position: "absolute", right: "-3px", top: "34px" }}
              >
                %
              </span>
            </FormGroup>
          </div>
        </Col>
      </Row>

      <Col md="12">
        <Row>
          <Col md="6">
            <div className="mb-2">
              <div>TPA Fees Amount  </div>
              <span style={{ fontWeight: 300 }}>6,00,000</span>
            </div>
          </Col>

          <Col md="6">
            <div className="mb-2">
              <div>TPA Fees Amount in words  </div>
              <span
                style={{
                  fontWeight: 300,
                  color: "#5c61f2"
                }}
              >
                Six Lakh
              </span>
            </div>
          </Col>
        </Row>
      </Col>
    </>
  );
};

export default PreviousPremium;
