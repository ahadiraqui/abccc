import React, { useState } from "react";
import { FormGroup, Label } from "reactstrap";
import { Typeahead } from "react-bootstrap-typeahead";
import "react-bootstrap-typeahead/css/Typeahead.css";


const IcData = ["Abc Capital Inc", "PTC India", "Ic Insurance", "TYA Broking Inc"];


const ICNamesList = () => {
  const [selected, setSelected] = useState<string[]>([]);

  const handleSelectedChange = (selectedOptions: any[]) => {
    const selectedNames = selectedOptions.map(option => option.name);
    setSelected(selectedNames);
  };

  return (
    <FormGroup>
      <Label>Insurance Company</Label>
      <Typeahead
        id="state-autocomplete"
        options={IcData.map(name => ({ name }))}
        labelKey="name"
        placeholder="Insurance Company"
        selected={selected.map(name => ({ name }))}
        onChange={handleSelectedChange}
      />
    </FormGroup>
  );
};

export default ICNamesList;
