import { useState } from "react";

import { Btn } from "../../../AbstractElements";
import {
  Card,
  CardBody,
  CardFooter,
  Col,
  Form,
  FormGroup,
  Input,
  Label,
  Row,
  TabContent,
  TabPane
} from "reactstrap";
import dayjs from "dayjs";

import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import "./style.scss";
import BrokerNames from "./BrokerNames";
import ICNamesList from "./ICNames";
import PreviousPremium from "./PreviousPremium";
import ServiceBranchLocation from "./ServiceBranchLocation";

export const Renew = () => {
  const [activeTab, setActiveTab] = useState("1");
  const toggle = tab => {
    if (activeTab !== tab) setActiveTab(tab);
  };

  const [selectedDate, setSelectedDate] = useState(dayjs());

  const handleDateChange = date => {
    setSelectedDate(date);
  };

  const formatDate = date => {
    if (!date) return "";
    return dayjs(date).format("ddd, DD MMM YYYY");
  };

  return (
    <div className="page-body">
      <div className="d-flex justify-content-between mt-4 mb-1 align-items-center pt-1 pt-1">
        <div className="ps-0 col-sm-6">
          <h3 className="screen-title">Renewal</h3>
        </div>
      </div>

      <Row>
        <Col lg="3" className="d-none d-lg-block"></Col>
        <Col lg="6">
          <Form>
            <Card>
              <CardBody>
                <Row>
                  <Col md="12 mt-1">
                    <Row>
                      <Col md="3">
                        <div>Date </div>
                      </Col>
                      <Col md="9">
                        <span style={{ fontWeight: 300, marginLeft: "15px" }}>
                          Sat, 01 Apr 2024{" "}
                        </span>
                      </Col>
                    </Row>
                  </Col>
                  <Col md="12" className="mt-2">
                    <Row>
                      <Col md="3">
                        <div>Previus Policy </div>
                      </Col>
                      <Col md="9">
                        <span style={{ fontWeight: 300, marginLeft: "15px" }}>
                          762901/34230400000033
                        </span>
                      </Col>
                    </Row>
                  </Col>

                  <Col md="12" className="mt-2">
                    <FormGroup>
                      <Label>Policy No</Label>
                      <Input type="text" placeholder="Policy No" />
                    </FormGroup>
                  </Col>
                  <Col md="12" className="">
                  <Row>
                      <Col md="3">
                        <div>Corporate </div>
                      </Col>
                      <Col md="9">
                      <span style={{ fontWeight: 300, marginLeft: "15px" }}>
                        Abc capital Inc
                      </span>
                      </Col>
                    </Row>
                 
                  </Col>
                  <div className="d-flex gap-3 tab-mobile flex-wrap mt-3">
                    <div>
                      <span style={{minWidth:'150px'}}
                        className={
                          activeTab === "1"
                            ? "active btn btn-outline-primary"
                            : "btn btn-outline-primary"
                        }
                        onClick={() => {
                          toggle("1");
                        }}
                      >
                        Broker
                      </span>
                    </div>
                    <div>
                      <span style={{minWidth:'150px'}}

                        className={
                          activeTab === "2"
                            ? "active btn btn-outline-primary"
                            : "btn btn-outline-primary"
                        }
                        onClick={() => {
                          toggle("2");
                        }}
                      >
                        Direct
                      </span>
                    </div>
                  </div>
                  <TabContent activeTab={activeTab} className="mt-3">
                    <TabPane tabId="1">
                      <BrokerNames />
                    </TabPane>
                  </TabContent>

                  <Col md="12">
                    <div className="mb-3">
                      <ICNamesList />
                    </div>
                  </Col>
                  <Col md="12">
                    <Row>
                      <Col xs="6">
                        <div className="mb-2">
                          <div>Previus Premium  </div>
                          <span style={{ fontWeight: 300 }}>2,00,00,000</span>
                        </div>
                      </Col>

                      <Col xs="6">
                        <div className="mb-2">
                          <div>In words  </div>
                          <span style={{ fontWeight: 300, color: "#5c61f2" }}>
                            Two Crore
                          </span>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                  <Col md="12">
                    <PreviousPremium />
                  </Col>

                  <Col md="12" className="mt-2">
                    <ServiceBranchLocation />
                  </Col>

                  <Col md="12">
                    <Label>Remarks</Label>
                    <textarea
                      className="form-control"
                      rows={3}
                      placeholder=""
                    />
                  </Col>
                </Row>
              </CardBody>
              <CardFooter className="text-end">
                <Btn color="primary" type="submit">
                  Save
                </Btn>
                <Btn
                  className="btn btn-light"
                  type="reset"
                  style={{ marginLeft: "10px" }}
                >
                  Cancel
                </Btn>
              </CardFooter>
            </Card>
          </Form>
        </Col>
      </Row>
    </div>
  );
};
