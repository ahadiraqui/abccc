import { useEffect, useState } from "react";
import AgGridTable from "../../../CommonElements/AgGridTable";

// import "./style.css";
import { Btn } from "../../../AbstractElements";
import { Link } from "react-router-dom";
import "./style.scss";
import { useAppDispatch, useAppSelector } from "../../../ReduxToolkit/Hooks";
import { GetPolicyRenewalListofCurrentFinancialYear, UpdatePolicyNotRenewed } from "../../../ReduxToolkit/Reducers/PolicyAction";
import { formatIndianNumber } from "../OpportunityGrid/formatIndianNumber";
import { Dialog, DialogActions, DialogContent, DialogTitle } from "@mui/material";
import { Label } from "reactstrap";

export const PolicyRenewalList = () => {
  const dispatch = useAppDispatch();
  const policyAction = useAppSelector((state:any)=>state.policyAction);
  const policyRenewalListOfCurrentFinancialYear = policyAction.policyRenewalListOfCurrentFinancialYear;

  const [open,setOpen] = useState(false);
  const [policyRegisterId,setPolicyRegisterId] = useState(null);

  useEffect(()=>{
    dispatch(GetPolicyRenewalListofCurrentFinancialYear());
  },[])

  const columnDefs = [
    {
      headerName: "Date",
      field: "DueDate",   
      minWidth: 120,
      width: 120,
      headerClass: "right-align wrap-text",
      cellClass: ["justify-content-end"],
      cellRenderer : (params:any) => {
        if (params?.value) {
          const dates = params?.value.split("T");
          return dates[0];
        } else {
          return "";
        }
      }
    },
    {
      headerName: "Policy",
      field: "PolicyNumber",
      sortable: true,
      filter: false,
      minWidth: 170,
      width: 170,
      cellStyle: function(params:any) {
        return { "whiteSpace": "normal" };
      },
      autoHeight: true,
    },
    {
      headerName: "Corporate",
      field: "CorporateName",
      sortable: true, filter: true, filterParams: { buttons: ["reset"]},
      minWidth: 170,
      width: 170,
     
      // cellStyle: { whiteSpace: "pre" },
      cellStyle: function(params:any) {
        return { "whiteSpace": "normal" };
      },
      autoHeight: true,
    },
    {
      headerName: "Broker",
      field: "Broker",
      sortable: true, filter: true, filterParams: { buttons: ["reset"]},
      minWidth: 160,
      width: 160,
      // cellStyle: { whiteSpace: "pre" }
      cellStyle: function(params:any) {
        return { "whiteSpace": "normal" };
      },
      autoHeight: true,
    },
    {
      headerName: "Insurance Company",
      field: "InsuranceCompany",
      sortable: true, filter: true, filterParams: { buttons: ["reset"]},
      minWidth: 140,
      width: 140,
      headerClass: "wrap-text",
      // cellStyle: { whiteSpace: "pre" }
      cellStyle: function(params:any) {
        return { "whiteSpace": "normal" };
      },
      autoHeight: true,
    },
    {
      headerName: "Premium",
      headerComponentParams: { template: '<span class="outer-span"><span class="amt-col">Premium</span><span class="icon-span">(<i class="fa fa-rupee"></i>)</span>'},
      field: "premium",
      sortable: true,
      filter: 'agNumberColumnFilter',
      filterParams: {
        buttons: ["reset"]
      },
      minWidth: 110,
      width: 110,
      headerClass: "right-align wrap-text",
      cellClass: ["justify-content-end"],
      cellStyle: { whiteSpace: "pre" },
      cellRenderer : (params:any) => {
        if(params?.value) {
          return formatIndianNumber(params?.value.toString());
        }else{
          return ""
        }
      }
    },

    {
      headerName: "TPA Fee %",
      field: "TPAFeePercent",
      sortable: true,     
      minWidth: 110,
      width: 110,
      headerClass: "right-align wrap-text text-right-side",
      cellClass: ["justify-content-end"],
      filter: 'agNumberColumnFilter',
      filterParams: {
        buttons: ["reset"]
      },
    },
    {
      headerName: "TPA Fee In Amount",
      headerComponentParams: { template: '<span class="outer-span"><span class="amt-col">TPA Fee In Amount</span><span class="icon-span">(<i class="fa fa-rupee"></i>)</span>'},
      field: "TPAFee",
      filter: 'agNumberColumnFilter',
      filterParams: {
        buttons: ["reset"]
      },
      minWidth: 130,
      width: 130,
      headerClass: "right-align wrap-text text-right-side",
      cellClass: ["justify-content-end"],
      cellRenderer : (params:any) => {
        if(params?.value) {
          return formatIndianNumber(params?.value.toString());
        }else{
          return ""
        }
      }
    },
    
    {
      headerName: "Renewal",
      field: "Renewal",
      sortable: true,
      filter: false,
      minWidth: 135,
      width: 135,
      cellRenderer: (params: any) => {
        return (
          <div className="d-flex gap-2">
            {/* <Link className="renew" to={`${process.env.PUBLIC_URL}/renewal`}>
              Renew
            </Link> */}
            {/* <Link className="lost" to={`${process.env.PUBLIC_URL}/lost`}>
              Lost
            </Link> */}
            <Btn className="lost" onClick={()=>{
              setOpen(true);
              setPolicyRegisterId(params?.data?.PolicyRegisterId);
            }}>
              Lost
            </Btn>
          </div>
        );
      }
    }
  ];

  const style = {
    height: "calc(100vh - 140px)",
    width: "100%",
    margin: "0 auto"
  };
  // const getRowHeight = () => 90;
  const getRowHeight = (params: any) => {
    const status = params.data ? params.data.status : ""; // Accessing status property from params.data

    if (status === "Working") {
      return 90; // Return 90 if status is 'Working'
    } else {
      return 35; // Return 20 for other statuses or if status is not available
    }
  };

  const handleSubmit = () =>{
    //3830
    dispatch(UpdatePolicyNotRenewed(policyRegisterId));
    setOpen(false);
    dispatch(GetPolicyRenewalListofCurrentFinancialYear());
  }

  const handleClose = ()=>{
    setOpen(false);
  }

  return (
    <>
    <div className="page-body attandence-list">
      <div className="m-block center-block-meeting-policy-ren-list d-flex justify-content-between mt-4 mb-1 align-items-center pt-1 pt-1">
        <div className="ps-0 col-sm-6">
          <h3 className="screen-title">Policy Renewal List</h3>
        </div>
      </div>

      {/* <p>AG Grid Table Test</p> */}
      <AgGridTable
        rowData={policyRenewalListOfCurrentFinancialYear}
        className="center-block-policy-ren-list"
        columnDefs={columnDefs}
        Style={style}
        getRowHeight={getRowHeight}
        pagination={true}
        paginationPageSize={15}
      />
    </div>

    <Dialog open={open} 
       onClose={handleClose}
       aria-describedby = "alert-dialog-slide-description"
      //  maxWidth="1g"
       PaperProps={{style:{borderRadius : "10px"}}}
       >
        <DialogTitle>Policy Renewal Status</DialogTitle>
        <DialogContent >
          <>
            <p>Are you sure want to confirm?</p>
          </>
        </DialogContent>
        <DialogActions>
          <Btn onClick={handleSubmit} color="primary" >
            Yes
          </Btn>
          <Btn onClick={handleClose} color="light">
            No
          </Btn>
        </DialogActions>
      </Dialog>
    </>
  );
};
