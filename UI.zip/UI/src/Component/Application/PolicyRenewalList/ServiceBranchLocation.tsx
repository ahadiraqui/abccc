import React, { useState } from "react";
import { FormGroup, Label } from "reactstrap";
import { Typeahead } from "react-bootstrap-typeahead";
import "react-bootstrap-typeahead/css/Typeahead.css";


const IcData = ["Mumbai", "Pune", "Nashik", "Thane"];


const ServiceBranchLocation = () => {
  const [selected, setSelected] = useState<string[]>([]);

  const handleSelectedChange = (selectedOptions: any[]) => {
    const selectedNames = selectedOptions.map(option => option.name);
    setSelected(selectedNames);
  };

  return (
    <FormGroup>
      <Label>Service Branch</Label>
      <Typeahead
        id="state-autocomplete"
        options={IcData.map(name => ({ name }))}
        labelKey="name"
        placeholder="Service Branch"
        selected={selected.map(name => ({ name }))}
        onChange={handleSelectedChange}
      />
    </FormGroup>
  );
};

export default ServiceBranchLocation;
