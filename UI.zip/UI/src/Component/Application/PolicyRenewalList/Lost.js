import { useState } from "react";

import { Btn } from "../../../AbstractElements";
import {
  Card,
  CardBody,
  CardFooter,
  Col,
  Form,
  FormGroup,
  Input,
  Label,
  Row,
  TabContent,
  TabPane
} from "reactstrap";
import dayjs from "dayjs";

import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import "./style.scss";
import BrokerNames from "./BrokerNames";
import ICNamesList from "./ICNames";
import PreviousPremium from "./PreviousPremium";
import ServiceBranchLocation from "./ServiceBranchLocation";
import NewTPA from "./NewTPA";
import PreviousPremiumLost from "./PreviousPremiumLost";

export const Lost = () => {
  const [activeTab, setActiveTab] = useState("1");
  const toggle = tab => {
    if (activeTab !== tab) setActiveTab(tab);
  };

  const [selectedDate, setSelectedDate] = useState(dayjs());

  const handleDateChange = date => {
    setSelectedDate(date);
  };

  const formatDate = date => {
    if (!date) return "";
    return dayjs(date).format("ddd, DD MMM YYYY");
  };

  return (
    <div className="page-body">
      <div className="d-flex justify-content-between mt-4 mb-1 align-items-center pt-1 pt-1">
        <div className="ps-0 col-sm-6">
          <h3 className="screen-title">Lost</h3>
        </div>
      </div>

      <Row>
        <Col lg="3" className="d-none d-lg-block"></Col>
        <Col lg="6">
          <Form>
            <Card>
              <CardBody>
                <Row>
                  <Col md="12">
                    <Row>
                      <Col md="6">
                        <div className="mb-2">
                          <div>Policy  </div>
                          <span style={{ fontWeight: 300 }}>525487454715</span>
                        </div>
                      </Col>

                      <Col md="6">
                        <div className="mb-2">
                          <div>Corporate </div>
                          <span style={{ fontWeight: 300 }}>
                            Abc Industry Inc
                          </span>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                  <Col md="12">
                    <Row>
                      <Col md="6">
                        <div className="mb-2">
                          <div>Broker  </div>
                          <span style={{ fontWeight: 300 }}>
                            Abc Industry Inc
                          </span>
                        </div>
                      </Col>

                      <Col md="6">
                        <div className="mb-2">
                          <div>Insurance Company  </div>
                          <span style={{ fontWeight: 300 }}>
                            MD Finance Inc
                          </span>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                  <Col md="12">
                    <Row>
                      <Col md="6">
                        <div className="mb-2">
                          <div>Premium  </div>
                          <span style={{ fontWeight: 300,color: "#5c61f2" }}>2,00,00,000</span>
                        </div>
                      </Col>
                      <Col md="6">
                        <div className="mb-2">
                          <div>Premium Amount (In Words) </div>
                          <span style={{ fontWeight: 300, color: "#5c61f2" }}>Two Crore </span>
                        </div>
                      </Col>
                      <Col md="6">
                        <div className="mb-2">
                          <div>TPA Fee %  </div>
                          <span style={{ fontWeight: 300 }}>3</span>
                        </div>
                      </Col>

                    </Row>
                  </Col>

                  <Col md="12">
                    <Row>
                      <Col md="6">
                        <div className="mb-2">
                          <div>TPA Fees Amount  </div>
                          <span style={{ fontWeight: 300,color: "#5c61f2" }}>6,00,000</span>
                        </div>
                      </Col>
                      <Col xs="6">
                        <div className="mb-2">
                          <div>TPA Fees Amount In words  </div>
                          <span style={{ fontWeight: 300, color: "#5c61f2" }}>
                           Six Lakh
                          </span>
                        </div>
                      </Col>

                  
                    </Row>
                  </Col>
                  <Col md="12">
                    <NewTPA />
                  </Col>
                  <Col md="12">
                    <BrokerNames />
                  </Col>
                  <Col md="12">
                    <div className="mb-3">
                      <ICNamesList />
                    </div>
                  </Col>
                  <Col md="12">
                    <PreviousPremiumLost />
                  </Col>
                  <Col md="12">
                    <Label>Remarks</Label>
                    <textarea
                      className="form-control"
                      rows={3}
                      placeholder=""
                    />
                  </Col>
                </Row>
              </CardBody>
              <CardFooter className="text-end">
                <Btn color="primary" type="submit">
                  Save
                </Btn>
                <Btn
                  className="btn btn-light"
                  type="reset"
                  style={{ marginLeft: "10px" }}
                >
                  Cancel
                </Btn>
              </CardFooter>
            </Card>
          </Form>
        </Col>
      </Row>
    </div>
  );
};
