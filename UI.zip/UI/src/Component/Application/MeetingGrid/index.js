import { useEffect, useState } from "react";
// import DatePicker, { DateObject } from 'react-multi-date-picker';
import AgGridTable from "../../../CommonElements/AgGridTable";
// import dayjs from 'dayjs';
import dayjs from "dayjs";

import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import "./style.scss";
import { Btn } from "../../../AbstractElements";
import { Link, useNavigate } from "react-router-dom";
import { useAppDispatch,useAppSelector } from "../../../ReduxToolkit/Hooks";
import { getMeetingData, setEditMeetingFlag, setEditMeetingID, setMeetingDataById } from "../../../ReduxToolkit/Reducers/MeetingAction";
import { setCityFlag } from "../../../ReduxToolkit/Reducers/CommonSlice";

export const MeetingGrid = () => {
  const [selectedDate, setSelectedDate] = useState(dayjs());
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const state = useAppSelector((state)=>state.meetingAction);
  const meetingGridData = state?.meetingGridData;

  useEffect(()=>{
    //format - MM-DD-YYYY
    dispatch(getMeetingData(selectedDate.format('MM-DD-YYYY')))
  },[])

  const gridOptions = {
    // Other grid options...
    rowClassRules: {
      // Apply 'even-row' class to even-numbered rows
      "even-row": params => params.node.rowIndex % 2 === 0,
      // Apply 'odd-row' class to odd-numbered rows
      "odd-row": params => params.node.rowIndex % 2 !== 0
    }
  };
  // Column definitions for AG-Grid
  const columnDefs = [
    { headerName: "Edit", field: "Edit", sortable: false, filter: false, minWidth: 66, width: 66,   
      cellRenderer:(params) => {
      return (
        <>
          <i className="icon-pencil-alt" style={{color: '#5b60ef',
            fontSize: '15px',cursor:'pointer'}}
            onClick = {()=>{
              dispatch(setMeetingDataById([]));dispatch(setCityFlag(1));
              dispatch(setEditMeetingFlag(true)); dispatch(setEditMeetingID(params?.data?.MeetingId)); navigate(`${process.env.PUBLIC_URL}/editMeeting`)}}
            >
          </i>
        </>);
        }
    },
    // { headerName: "ID", field: "id", minWidth: 60, width: 60,
    //   headerClass: "right-align",     
    //   cellClass: ["justify-content-end"]
    // },
    { headerName: "Location", field: "MeetingAt", minWidth: 215, width: 215 },
    { headerName: "Time", field: "Time", minWidth: 150, width: 150,
      cellRenderer: params => {
        const startTime = dayjs(params?.data?.MeetingStartTime).format('hh:mm A');
        const endTime = dayjs(params?.data?.MeetingDueTime).format('hh:mm A');
        return `${startTime}-${endTime}`;
      }
    },
    { headerName: "Duration", field: "MeetingDuration", minWidth: 92, width: 92 },
    { headerName: "Mode", field: "Mode", minWidth: 120, width: 120 },

    { headerName: "Retention", field: "Retention", minWidth: 145, width: 145,
      cellRenderer : (params)=>{
        const count = params?.data?.Retention || 0;
        return(
          <>
            <div className="d-flex">
              <button className="meetingAdd">Add</button>
              {count>0 && <><span>|</span>
              <button className="meetingView">View <span style={{fontWeight:600,paddingLeft:"1px"}}>({count})</span></button></>}
            </div>
          </>
        )
      }
    },
    {
      headerName: "Exploration",
      field: "Exploration",
      minWidth: 145,
      width: 145,
      cellRenderer : (params)=>{
        const count = params?.data?.Exploration || 0;
        return(
          <>
            <div className="d-flex">
              <button className="meetingAdd">Add</button>
              {count>0 && <><span>|</span>
              <button className="meetingView">View <span style={{fontWeight:600,paddingLeft:"1px"}}>({count})</span></button></>}
            </div>
          </>
        )
      }
    },
    { headerName: "Lead", field: "Lead", minWidth: 145, width: 145,
      cellRenderer : (params)=>{
        const count = params?.data?.Lead || 0;
        return(
          <>
            <div className="d-flex">
              <button className="meetingAdd">Add</button>
              {count>0 && <><span>|</span>
              <button className="meetingView">View <span style={{fontWeight:600,paddingLeft:"1px"}}>({count})</span></button></>}
            </div>
          </>
        )
      }
    },
    { headerName: "Win", field: "Win", minWidth: 145, width: 145,
      cellRenderer : (params)=>{
        const count = params?.data?.Win || 0;
        return(
          <>
            <div className="d-flex">
              <button className="meetingAdd">Add</button>
              {count>0 && <><span>|</span>
              <button className="meetingView">View <span style={{fontWeight:600,paddingLeft:"1px"}}>({count})</span></button></>}
            </div>
          </>
        )
      }
    },
    { headerName: "Lost", field: "Lost", minWidth: 145, width: 145,
      cellRenderer : (params)=>{
        const count = params?.data?.Lost || 0;
        return(
          <>
            <div className="d-flex">
              <button className="meetingAdd">Add</button>
              {count>0 && <><span>|</span>
              <button className="meetingView">View <span style={{fontWeight:600,paddingLeft:"1px"}}>({count})</span></button></>}
            </div>
          </>
        )
      }
    },
  ];

  const style = { height: "calc(100vh - 140px)", width: "100%" };
  const getRowHeight = () => 30;

  const handleDateChange = date => {
    setSelectedDate(date);
    dispatch(getMeetingData(date.format('MM-DD-YYYY')))
  };

  const formatDate = date => {
    if (!date) return "";
    return dayjs(date).format("ddd, DD MMM YYYY");
  };

  // const [value, setValue] = useState([new DateObject()]);
  // const onChange = ()=>{
  //     console.log("DatePicker",new DateObject())
  // }
  return (
    <div className="page-body">
      <div className="m-block center-block-meeting d-flex justify-content-between mt-4 mb-1 align-items-center pt-1 pt-1">
        <div className="ps-0 col-sm-6">
          <h3 className="screen-title">Meeting</h3>
        </div>
        <div>
          <div className="d-flex gap-3 mt-2">
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                className="custom-date"
                value={selectedDate}
                onChange={handleDateChange}
                renderInput={props => (
                  <input {...props} variant="standard" fullWidth />
                )}
                format="ddd, DD MMM YYYY" // Format for the displayed date
              />
            </LocalizationProvider>
            <div className="text-end">
            <Link to={`${process.env.PUBLIC_URL}/add-meeting`}>
              <Btn color="primary" block className="w-100">
                Add
              </Btn>
              </Link>
              
            </div>
          </div>
        </div>
      </div>

      {/* <p>AG Grid Table Test</p> */}
      <AgGridTable
        rowData={meetingGridData}
        columnDefs={columnDefs}
        Style={style}
        getRowHeight={getRowHeight}
        pagination={true}
        paginationPageSize={15} className="center-block-meeting-grid"
      />
    </div>
  );
};
