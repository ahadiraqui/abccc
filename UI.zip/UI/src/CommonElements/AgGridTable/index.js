import { AgGridReact } from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import './styles.css'
import { useRef } from "react";

function AgGridTable({
  rowData,
  columnDefs,
  Style,
  getRowHeight,
  ...props
}) {
  const gridApiRef = useRef(null);
  const onGridReady = (params) => {
    gridApiRef.current = params.api;
    if (gridApiRef?.current) {
      gridApiRef?.current?.autoSizeColumns();
    }
  };

  return (
    <div className="ag-theme-alpine" style={Style}>
      <AgGridReact
        rowData={rowData}
        columnDefs={columnDefs}
        pagination={false}
        // onGridReady={onGridReady}
        getRowHeight={getRowHeight}
        {...props}
      />
    </div>
  );
}

export default AgGridTable;
