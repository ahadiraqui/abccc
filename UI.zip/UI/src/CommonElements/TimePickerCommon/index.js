import React, { useRef, useEffect } from 'react';
import flatpickr from 'flatpickr';
import 'flatpickr/dist/flatpickr.min.css';
import { Label } from 'reactstrap';
import { FormGroup } from '@mui/material';

const TimePickerCommon = ({ setTimeValues }) => {
  const startTimeRef = useRef(null); // Ref for start time input
  const endTimeRef = useRef(null); // Ref for end time input

  useEffect(() => {
    const startOptions = {
      enableTime: true,
      noCalendar: true,
      dateFormat: "H:i",
      time_24hr: true,
      onChange: (selectedDates, dateStr) => {
        setTimeValues('startTime', dateStr); // Call handleValues with endTime and the updated value
        // onChange(selectedDates, dateStr, instance); // Call the onChange prop, if provided
      },
    };

    const endOptions = {
      enableTime: true,
      noCalendar: true,
      dateFormat: "H:i",
      time_24hr: true,
      onChange: (selectedDates, dateStr) => {
        setTimeValues('endTime', dateStr); // Call handleValues with endTime and the updated value
        // onChange(selectedDates, dateStr, instance); // Call the onChange prop, if provided
      },
    };

    flatpickr(startTimeRef.current, startOptions);
    flatpickr(endTimeRef.current, endOptions);
  }, [setTimeValues]);

  return (
    <>
    <FormGroup>
      <Label>Start Time (24 Hours Format)</Label>
      <div>
      <input className="form-control" ref={startTimeRef} />
      </div>
    </FormGroup>
    <FormGroup>
      <Label>End Time (24 Hours Format)</Label>
      <div>
      <input className="form-control" ref={endTimeRef} />
      </div>
    </FormGroup>
  </>);
};

export default TimePickerCommon;
