import React, { useState } from "react";
import { FormGroup, Label } from "reactstrap";
import { Typeahead } from "react-bootstrap-typeahead";
import "react-bootstrap-typeahead/css/Typeahead.css";
import "./style.css";

const Belong = ["Abc Inc", "Abb insurance Ltd", "Marsh inc", "TSS Broking Inc"];

const AutoCompleteBelongs = () => {
  const [selected, setSelected] = useState<string[]>([]);

  const handleSelectedChange = (selectedOptions: any[]) => {
    const selectedNames = selectedOptions.map(option => option.name);
    setSelected(selectedNames);
  };

  return (
    <FormGroup>
      <Label>
        Contact Belongs to
        <span
          style={{
            fontSize: "12px",
            color: "gray",
            paddingLeft: "10px"
          }}
        >
          (Name of the company)
        </span>
      </Label>
      <Typeahead
        id="state-autocomplete"
        options={Belong.map(name => ({ name }))}
        labelKey="name"
        placeholder="Select..."
        selected={selected.map(name => ({ name }))}
        onChange={handleSelectedChange}
      />
    </FormGroup>
  );
};

export default AutoCompleteBelongs;
