import React, { useState } from "react";
import { FormGroup, Label } from "reactstrap";
import { Typeahead } from "react-bootstrap-typeahead";
import "react-bootstrap-typeahead/css/Typeahead.css";
import "./style.css";

const statesInIndia = [
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chhattisgarh",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttar Pradesh",
  "Uttarakhand",
  "West Bengal"
];

const AutocompleteSelect = () => {
  const [selected, setSelected] = useState<string[]>([]);

  const handleSelectedChange = (selectedOptions: any[]) => {
    const selectedNames = selectedOptions.map(option => option.name);
    setSelected(selectedNames);
  };

  return (
    <FormGroup>
      <Label>State</Label>
      <Typeahead
        id="state-autocomplete"
        options={statesInIndia.map(name => ({ name }))}
        labelKey="name"
        placeholder="Select state..."
        selected={selected.map(name => ({ name }))}
        onChange={handleSelectedChange}
      />
    </FormGroup>
  );
};

export default AutocompleteSelect;
