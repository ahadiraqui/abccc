const api = `${process.env.PUBLIC_URL}/api`;

export const chatMemberApi = `${api}/chatMember.json`;
export const chatApi = `${api}/chats.json`;