// import api from "apiServices";
import api from 'axios';

const getHeadersForFileUpload = () => {
  return {
    headers: {
      "Content-Type": "multipart/form-data",
      ...(getAccessToken() && {
        authorization: `Bearer ${getAccessToken()}`,
      }),
    },
  };
};

function getAccessToken() {
  return localStorage.getItem("accessToken");
}

export const getHeaders = () => {
  return {
    headers: {
      "ngrok-skip-browser-warning": true,
      ...(getAccessToken() && {
        authorization: `Bearer ${getAccessToken()}`,
      }),
    },
  };
};

const createFormData = (body) => {
  const apiFormData = new FormData();
  Object.keys(body).forEach((key) => {
    if (body[key]) {
      if (body[key] instanceof Array) {
        apiFormData.append(key, JSON.stringify(body[key]));
      } else {
        apiFormData.append(key, body[key]);
      }
    }
  });
  return apiFormData;
};

export const postFormData = (path, formData) => {
  return new Promise((resolve, reject) => {
    api
      .post(
        `${process.env.REACT_APP_BASEURL}${path}`,
        createFormData(formData),
        getHeadersForFileUpload()
      )
      .then((response) => {
        resolve(response?.data);
      })
      .catch((error) => {});
  });
};

export const postTempURLFormData = (path, formData) => {
  return new Promise((resolve, reject) => {
    api
      .post(
        `${process.env.REACT_APP_BASEURL}${path}`,
        createFormData(formData),
        getHeadersForFileUpload()
      )
      .then((response) => {
        resolve(response?.data);
      })
      .catch((error) => {});
  });
};

const createMultipleFormData = (body) => {
  const apiFormData = new FormData();
  Object.keys(body).forEach((key) => {
    if (body[key]) {
      if (body[key] instanceof Array) {
        body[key]?.forEach((i) => {
          apiFormData.append(key, i);
        });
      } else {
        apiFormData.append(key, body[key]);
      }
    }
  });
  return apiFormData;
};

export const postMultipleFormData = (path, formData) => {
  return new Promise((resolve, reject) => {
    api
      .post(
        `${process.env.REACT_APP_BASEURL}${path}`,
        createMultipleFormData(formData),
        getHeadersForFileUpload()
      )
      .then((response) => {
        resolve(response?.data);
      })
      .catch((error) => {});
  });
};

export const getApiCall = (path, data) => {
  return new Promise((resolve, reject) => {
    api
      .get(`${process.env.REACT_APP_BASEURL}${path}`, getHeaders())
      .then((response) => {
        resolve(response?.data);
      })
      .catch((error) => {});
  });
};

export const postDataApi = (path, data) => {
  return new Promise((resolve, reject) => {
    api
      .post(`${process.env.REACT_APP_BASEURL}${path}`, data, getHeaders())
      .then((response) => {
        resolve(response?.data);
      })
      .catch((error) => {});
  });
};
export const deleteTempDataApi = (path) => {
  return new Promise((resolve, reject) => {
    api
      .delete(`${process.env.REACT_APP_BASEURL}${path}`, getHeaders())
      .then((response) => {
        resolve(response?.data);
      })
      .catch((error) => {});
  });
};

//The below changes are temp as login Base URL is different 
export const postTempBaseUrlDataApi = (path, data) => {
  return new Promise((resolve, reject) => {
    api
      .post(`${process.env.REACT_APP_BASEURL}${path}`, data, getHeaders())
      .then((response) => {
        resolve(response?.data);
      })
      .catch((error) => {});
  });
};

export const putTempBaseUrlDataApi = (path, data) => {
  return new Promise((resolve, reject) => {
    api
      .put(`${process.env.REACT_APP_BASEURL}${path}`, data, getHeaders())
      .then((response) => {
        resolve(response?.data);
      })
      .catch((error) => {});
  });
};

export const getTempBaseUrlDataApi = (path, data) => {
  return new Promise((resolve, reject) => {
    api
      .get(`${process.env.REACT_APP_BASEURL}${path}`, getHeaders())
      .then((response) => {
        resolve(response?.data);
      })
      .catch((error) => {});
  });
};

export const getTempBaseUrlDataApiWithoutToken = (path, data) => {
  return new Promise((resolve, reject) => {
    api
      .get(`${process.env.REACT_APP_BASEURL}${path}`)
      .then((response) => {
        resolve(response?.data);
      })
      .catch((error) => {});
  });
};

export const getApiCallLogin = (path, data) => {
  return new Promise((resolve, reject) => {
    api
      .get(`${process.env.REACT_APP_BASEURL}${path}`, getHeaders())
      .then((response) => {
        resolve(response?.data);
      })
      .catch((error) => {});
  });
};

export const postDataApiLogin = (path, data) => {
  return new Promise((resolve, reject) => {
    api
      .post(`${process.env.REACT_APP_BASEURL}${path}`, data, getHeaders())
      .then((response) => {
        resolve(response?.data);
      })
      .catch((error) => {});
  });
};